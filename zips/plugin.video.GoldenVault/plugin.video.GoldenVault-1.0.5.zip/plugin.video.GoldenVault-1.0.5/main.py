import sys
import os

ADDON_ROOT = os.path.dirname(__file__)
LIB_PATH = os.path.join(ADDON_ROOT, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from movies import *
import series

if __name__ == '__main__':
    params = get_params()
    action = params.get('action')

    log(f"Main Router: Action received: {action}, Params: {params}", level=xbmc.LOGINFO)

    # ==================== MOVIE & SERIES PLAYBACK ROUTING ====================
    if action == 'play':
        title = params.get('title', '')
        url = params.get('url', '')

        if title and url:
            play_movie(title, url)
            sys.exit()
        else:
            xbmcgui.Dialog().notification(
                "Error",
                "Title or URL is missing for movie playback.",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'play_series':
        title = params.get('title', '')
        url = params.get('url', '')

        if title and url:
            series.play_series(title, url)
            sys.exit()
        else:
            xbmcgui.Dialog().notification(
                "Error",
                "Title or URL is missing for series playback.",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.endOfDirectory(addon_handle)

    # ==================== MAIN HOME ENTRY MENU ====================
    elif action is None:
        check_update_popup()
        
        movies_folder_item = xbmcgui.ListItem('[COLOR white]One[/COLOR][COLOR FFD4AF37]Click Movies[/COLOR]')
        movies_folder_item.setArt({
            'icon': os.path.join(ICONS_PATH, 'movie.png'),
            'fanart': FANART_PATH
        })

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=show_movies",
            movies_folder_item,
            isFolder=True
        )

        series_folder_item = xbmcgui.ListItem('[COLOR white]One[/COLOR][COLOR FFD4AF37]Click Series[/COLOR]')
        series_folder_item.setArt({
            'icon': os.path.join(ICONS_PATH, 'tv_shows.png'),
            'fanart': FANART_PATH
        })

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=show_series",
            series_folder_item,
            isFolder=True
        )

        xbmcplugin.endOfDirectory(addon_handle)

    # ==================== SHOW SUB-MENUS ====================
    elif action == 'show_movies':
        all_movies_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]All Movies[/COLOR]')
        all_movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'allmovie.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_movies&page=1", all_movies_folder_item, isFolder=True)

        fourk_movies_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]4K Movies[/COLOR]')
        fourk_movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, '4k.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_4k_movies&page=1", fourk_movies_folder_item, isFolder=True)

        categories_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]Categories[/COLOR]')
        categories_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_categories&page=1", categories_folder_item, isFolder=True)

        search_item = xbmcgui.ListItem('[COLOR FFD4AF37]Search[/COLOR]')
        search_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=gv_search_menu", search_item, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)
        
        xbmcplugin.endOfDirectory(addon_handle)
    # ====================SHOW SUB-MENUS SERIES ====================
    elif action == 'show_series':
        all_series_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]All Series[/COLOR]')
        all_series_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'allmovie.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_series&page=1", all_series_folder_item, isFolder=True)

        categories_series_item = xbmcgui.ListItem('[COLOR FFD4AF37]Categories[/COLOR]')
        categories_series_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_series_categories&page=1", categories_series_item, isFolder=True)

        search_series_item = xbmcgui.ListItem('[COLOR FFD4AF37]Search[/COLOR]')
        search_series_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=gv_series_search_menu", search_series_item, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)
        
        xbmcplugin.endOfDirectory(addon_handle)

        # ==================== MOVIES LISTINGS ====================
    elif action == 'list_movies':
        movie_titles = read_movie_list(file_path)
        genre = params.get('genre')
        category = params.get('category')
        page = int(params.get('page', 1))
        list_movies(movie_titles, genre, page, category)

    elif action == 'list_4k_movies':
        page = int(params.get('page', 1))
        list_4k_movies(page)

    elif action == 'list_categories':
        page = int(params.get('page', 1))
        list_categories(page)

    elif action == 'list_movies_by_category':
        category = params.get('category')
        page = int(params.get('page', 1))

        if category:
            list_movies_by_category(category, page)
        else:
            xbmcgui.Dialog().notification("Error", "No category specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_genres':
        page = int(params.get('page', 1))
        list_genres(page)

    elif action == 'list_movies_by_genre':
        genre = params.get('genre')
        page = int(params.get('page', 1))

        if genre:
            list_movies_by_genre(genre, page)
        else:
            xbmcgui.Dialog().notification("Error", "No genre specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_years':
        page = int(params.get('page', 1))
        list_years(page)

    elif action == 'list_movies_by_year':
        year = params.get('year')
        page = int(params.get('page', 1))

        if year:
            list_movies_by_year(year, page)
        else:
            xbmcgui.Dialog().notification("Error", "No year specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)


    # ==================== SERIES LISTINGS ====================
    elif action == 'list_series':
        series_titles = series.read_series_list(series.file_path)
        category = params.get('category')
        page = int(params.get('page', 1))
        series.list_series(series_titles, page=page, category=category)

    elif action == 'list_series_categories':
        page = int(params.get('page', 1))
        series.list_series_categories(page)

    elif action == 'list_series_by_category':
        category = params.get('category')
        page = int(params.get('page', 1))

        if category:
            series.list_series_by_category(category, page)
        else:
            xbmcgui.Dialog().notification("Error", "No category specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_series_seasons':
        series_title = params.get('series_title', '')

        if series_title:
            series.list_series_seasons(series_title)
        else:
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_series_episodes':
        series_title = params.get('series_title', '')
        season = params.get('season', 1)

        if series_title:
            series.list_series_episodes(series_title, season)
        else:
            xbmcplugin.endOfDirectory(addon_handle)
            
        # ==================== SEARCH MANAGEMENT ====================
    elif action == 'list_search_menu':
        list_search_menu()

    # ---------- Movie Search ----------
    elif action == 'gv_search_menu':
        gv_search_menu()

    elif action == 'gv_clear_history':
        clear_search_history()

    elif action == 'gv_search_keyboard':
        gv_search_keyboard()

    elif action == 'gv_search_results':
        search_text = params.get('q', '')
        page = int(params.get('page', 1))
        gv_search_results(search_text, page)

    # ---------- Series Search ----------
    elif action in ('gv_search_series_menu', 'gv_series_search_menu'):
        series.gv_search_series_menu()

    elif action in ('gv_clear_series_history', 'gv_series_clear_history'):
        series.clear_series_search_history()

    elif action in ('gv_search_series_keyboard', 'gv_series_search_keyboard'):
        series.gv_search_series_keyboard()

    elif action in ('gv_search_series_results', 'gv_series_search_results'):
        search_text = params.get('q', '')
        page = int(params.get('page', 1))
        fresh = params.get('fresh', '')
        series.gv_search_series_results(search_text, page, fresh)

    # ---------- Back ----------
    elif action == 'gv_go_back':
        xbmc.executebuiltin("Action(Back)")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

    # ==================== SOURCE LINK HANDLERS ====================
    elif action == 'play_sources':
        title = params.get('title', '')
        sources = params.get('sources', '')

        if title and sources:
            play_movie_sources(title, sources)
            sys.exit()
        else:
            xbmcgui.Dialog().notification(
                "Error",
                "Missing source list.",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'play_series_sources':
        title = params.get('title', '')
        sources = params.get('sources', '')

        if title and sources:
            series.play_series_sources(title, sources)
            sys.exit()
        else:
            xbmcgui.Dialog().notification(
                "Error",
                "Missing source list.",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.endOfDirectory(addon_handle)
        
    else:
        log(f"Main Router: Unhandled action or initial entry point. Action: '{action}'", level=xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(addon_handle)