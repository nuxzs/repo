import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import urllib.parse
import requests
import sys
import os
import re
import json
import time
import threading

# Addon info
addon_handle = int(sys.argv[1])
addon_id = 'plugin.video.GoldenVault'

# Configuration options
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
EXTRA_HEADERS = {}
PROXY = None
REMOTE_ADDONS_XML = "https://raw.githubusercontent.com/nuxzs/repo/refs/heads/main/addons.xml"
DEFAULT_TMDB_API_KEY = 'a0bf207c5ff6c0caabac0327e39b1cd2'
TMDB_RUNTIME_CACHE = {}

SERIES_YEAR_OVERRIDES = {
    "one piece": "1999",
}

# --- PHYSICAL FILE CACHE SETTINGS ---
CACHE_FILE_LIMIT = 1000
CACHE_DIR = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CACHE_FILE_PATH = os.path.join(CACHE_DIR, 'tmdb_series_cache.json')
if not os.path.exists(CACHE_DIR):
    try:
        os.makedirs(CACHE_DIR)
    except Exception:
        pass

ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
file_path = os.path.join(ADDON_ROOT, 'resources', 'series_list.json')
ICONS_PATH = os.path.join(ADDON_ROOT, 'resources', 'images', 'icons')
FANART_PATH = os.path.join(ADDON_ROOT, 'resources', 'images', 'fanart.jpg')

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f'[{addon_id}] {message}', level=level)

def safe_int(value, default=1):
    try:
        return int(value)
    except Exception:
        return default

def version_tuple(v):
    try:
        return tuple(int(x) for x in str(v).split('.') if str(x).isdigit())
    except Exception:
        return (0, 0, 0)

def load_local_cache():
    if os.path.exists(CACHE_FILE_PATH):
        try:
            with open(CACHE_FILE_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
        except Exception:
            return {}
    return {}

def save_local_cache(cache_data):
    try:
        while len(cache_data) > CACHE_FILE_LIMIT:
            oldest_key = next(iter(cache_data))
            cache_data.pop(oldest_key, None)

        with open(CACHE_FILE_PATH, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        log(f"Failed to write series cache file: {e}", level=xbmc.LOGWARNING)

def get_tmdb_api_key():
    try:
        addon = xbmcaddon.Addon()
        setting_key = addon.getSetting('tmdb_api_key')
        return setting_key or DEFAULT_TMDB_API_KEY
    except Exception as e:
        print(f"Error getting TMDB API key: {e}")
        return DEFAULT_TMDB_API_KEY

TMDB_API_KEY = get_tmdb_api_key()

def get_series_category(series_data):
    category = (
        series_data.get('category')
        or series_data.get('group-title')
        or series_data.get('group_title')
        or series_data.get('group')
        or ''
    )

    category = str(category).strip()

    return category

def get_series_base_title(series_data):
    """Return the real show name for TMDB and grouping, not the SxxExx title."""
    base = (
        series_data.get('series_title')
        or series_data.get('show_title')
        or series_data.get('show')
        or series_data.get('name')
        or ''
    )

    if base:
        return str(base).strip()
        
    title = str(series_data.get('title', '')).strip()
    # Example: black mirror S01E01 -> black mirror
    title = re.sub(r'\bS\d{1,2}\s*E\d{1,3}\b', '', title, flags=re.IGNORECASE).strip()
    title = re.sub(r'\b\d{1,2}x\d{1,3}\b', '', title, flags=re.IGNORECASE).strip()
    title = re.sub(r'\s+', ' ', title).strip(' -._')
    return title

def get_episode_title(series_data):
    title = str(series_data.get('title', '')).strip()
    return title

def get_episode_sort_key(series_data):
    season = safe_int(series_data.get('season'), 0)
    episode = safe_int(series_data.get('episode'), 0)
    title = get_episode_title(series_data).lower()
    return (get_series_base_title(series_data).lower(), season, episode, title)

def format_episode_label(series_data):
    title = get_episode_title(series_data)
    base = get_series_base_title(series_data)
    season = series_data.get('season')
    episode = series_data.get('episode')

    if season is not None and episode is not None:
        try:
            sxex = f"S{int(season):02d}E{int(episode):02d}"
            # If title already contains SxxExx, do not duplicate it.
            if re.search(r'\bS\d{1,2}\s*E\d{1,3}\b', title, flags=re.IGNORECASE):
                return title
            return f"{base} {sxex}".strip()
        except Exception:
            pass

    return title or base or 'Untitled Episode'

def read_series_list(file_path):
    """Reads flat series episodes from JSON without overwriting duplicate names.

    Supported JSON:
    {
      "series": [
        {"title":"black mirror S01E01", "series_title":"black mirror", "season":1, "episode":1, "url":"..."}
      ]
    }
    """
    series_titles = {}
    try:
        log(f"Reading series list from: {file_path}", level=xbmc.LOGDEBUG)
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        if isinstance(data, dict):
            raw_items = data.get('series') or data.get('episodes') or data.get('shows') or []
        elif isinstance(data, list):
            raw_items = data
        else:
            raw_items = []

        if not isinstance(raw_items, list):
            log(f"Warning: series JSON is not a list: {file_path}", level=xbmc.LOGWARNING)
            return {}

        for index, item in enumerate(raw_items):
            if not isinstance(item, dict):
                continue

            title = str(item.get('title', '')).strip()
            url = str(item.get('url', '')).strip()

            if not title or not url:
                log(f"Skipping series entry with missing title or URL: {item}", level=xbmc.LOGWARNING)
                continue

            normalized = dict(item)
            normalized['title'] = title
            normalized['url'] = url

            # Make sure these fields exist for your JSON style.
            base_title = get_series_base_title(normalized)
            if base_title:
                normalized['series_title'] = base_title

            category = get_series_category(normalized)
            normalized['category'] = category

            season = normalized.get('season')
            episode = normalized.get('episode')
            unique_key = f"{title}_||_{base_title}_||_{season}_||_{episode}_||_{category}_||_{index}"
            series_titles[unique_key] = normalized

    except Exception as e:
        log(f"Error reading series file: {e}", level=xbmc.LOGERROR)
        return {}

    log(f"Read {len(series_titles)} series episodes from file.", level=xbmc.LOGDEBUG)
    return series_titles

def get_series_details(title, year=None):
    """Fetches TV Show metadata from TMDB using the clean show title."""
    title = str(title or '').strip()
    
    override_year = SERIES_YEAR_OVERRIDES.get(title.lower())

    if override_year and not year:
        year = override_year
        
    if not title:
        return {}

    cache_key = title.lower()

    if cache_key in TMDB_RUNTIME_CACHE:
        return TMDB_RUNTIME_CACHE[cache_key]

    cache = load_local_cache()
    if cache_key in cache:
        cached = cache[cache_key]

        if cached.get('runtime'):
            TMDB_RUNTIME_CACHE[cache_key] = cached
            return cached

    api_key = get_tmdb_api_key()
    if not api_key:
        return {}

    search_url = f"https://api.themoviedb.org/3/search/tv?api_key={api_key}&query={urllib.parse.quote_plus(title)}"

    if year:
        search_url += f"&first_air_date_year={year}"

    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json"
    }

    try:
        response = requests.get(search_url, headers=headers, timeout=7)

        if response.status_code == 429:
            log(f"TMDB TV rate limited for: {title}", level=xbmc.LOGWARNING)
            TMDB_RUNTIME_CACHE[cache_key] = {}
            return {}

        if response.status_code != 200 or not response.text.strip():
            TMDB_RUNTIME_CACHE[cache_key] = {}
            return {}

        data = response.json()

        if data.get('results'):
            series_info = data['results'][0]
            runtime = 0
            genres = []

            series_id = series_info.get('id')

            if series_id:
                details_url = f"https://api.themoviedb.org/3/tv/{series_id}?api_key={api_key}"

                try:
                    details_response = requests.get(details_url, headers=headers, timeout=7)

                    if details_response.status_code == 200 and details_response.text.strip():
                        details_data = details_response.json()

                        run_times = details_data.get('episode_run_time', [])
                        if isinstance(run_times, list) and run_times:
                            try:
                                runtime = int(run_times[0])
                            except Exception:
                                runtime = 0

                        if not runtime:
                            try:
                                last_ep = details_data.get('last_episode_to_air', {})
                                runtime = int(last_ep.get('runtime', 0) or 0)
                            except Exception:
                                runtime = 0

                        if not runtime:
                            runtime = 45

                        raw_genres = details_data.get('genres', [])
                        if isinstance(raw_genres, list):
                            genres = [
                                g.get('name')
                                for g in raw_genres
                                if isinstance(g, dict) and g.get('name')
                            ]

                except Exception as e:
                    log(f"TMDB TV details failed for '{title}': {e}", level=xbmc.LOGWARNING)

            metadata = {
                'poster_path': series_info.get('poster_path', ''),
                'backdrop_path': series_info.get('backdrop_path', ''),
                'overview': series_info.get('overview', ''),
                'release_date': series_info.get('first_air_date', ''),
                'vote_average': series_info.get('vote_average', 0),
                'year': series_info.get('first_air_date', '').split('-')[0] if series_info.get('first_air_date') else '',
                'tmdb_title': series_info.get('name', title),
                'runtime': runtime,
                'genres': genres
            }

            cache = load_local_cache()
            cache[cache_key] = metadata
            save_local_cache(cache)
            TMDB_RUNTIME_CACHE[cache_key] = metadata
            return metadata

    except Exception as e:
        log(f"TMDB TV request failed for '{title}': {e}", level=xbmc.LOGERROR)

    TMDB_RUNTIME_CACHE[cache_key] = {}
    return {}

def is_series_4k(series_details):
    return bool(series_details.get('is_4k', False))

def build_sources_by_title(series_list):
    """Build duplicate-source popup groups by episode title, not only show title."""
    sources_by_title = {}

    for series in series_list:
        title = get_episode_title(series)
        url = str(series.get('url', '')).strip()

        if not title or not url:
            continue

        key = title.strip().lower()

        if key not in sources_by_title:
            sources_by_title[key] = []

        sources_by_title[key].append({
            'title': title,
            'url': url,
            'category': get_series_category(series),
            'is_4k': series.get('is_4k', False),
            'series_title': get_series_base_title(series),
            'season': series.get('season'),
            'episode': series.get('episode')
        })

    return sources_by_title

def play_series_sources(title, sources_json):
    try:
        sources = json.loads(urllib.parse.unquote_plus(sources_json))
    except Exception:
        sources = []

    if not sources:
        xbmcgui.Dialog().notification("Error", "No links found.", xbmcgui.NOTIFICATION_ERROR)
        return

    if len(sources) == 1:
        play_series(title, sources[0].get('url', ''))
        return

    options = []
    for i, src in enumerate(sources, 1):
        cat = str(src.get('category') or '').strip()
        if not cat or cat.lower() in ('none', 'null', 'other', 'others'):
            cat = 'All Series'
        season = src.get('season')
        episode = src.get('episode')
        extra = ""
        if season is not None and episode is not None:
            try:
                extra = f"  |  [COLOR white]S{int(season):02d}E{int(episode):02d}[/COLOR]"
            except Exception:
                extra = ""
        options.append(f"[COLOR white]{i}.[/COLOR] Version  |  Category: [COLOR FFB89D4B]{cat}[/COLOR]{extra}")

    choice = xbmcgui.Dialog().select(f"Choose Version - {title}", options)

    if choice == -1:
        return

    play_series(title, sources[choice].get('url', ''))
    
def make_series_list_item(title, series_details):
    list_item = xbmcgui.ListItem(title)

    poster_path = series_details.get('poster_path')
    backdrop_path = series_details.get('backdrop_path')

    if poster_path:
        poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
        fanart_to_use = f"https://image.tmdb.org/t/p/original/{backdrop_path}" if backdrop_path else FANART_PATH
        list_item.setArt({
            'thumb': poster_url,
            'poster': poster_url,
            'banner': poster_url,
            'clearart': poster_url,
            'clearlogo': poster_url,
            'landscape': poster_url,
            'fanart': fanart_to_use
        })
    else:
        default_poster_path = os.path.join(ICONS_PATH, 'DefaultVideo.png')
        list_item.setArt({'thumb': default_poster_path, 'poster': default_poster_path, 'fanart': FANART_PATH})

    video_info = list_item.getVideoInfoTag()
    video_info.setPlot(series_details.get('overview', ''))

    release_date = series_details.get('release_date')
    try:
        if release_date and len(release_date) >= 4:
            video_info.setYear(int(release_date.split('-')[0]))
        elif series_details.get('year'):
            video_info.setYear(int(series_details.get('year')))
    except Exception:
        pass

    try:
        video_info.setRating(float(series_details.get('vote_average', 0)))
    except Exception:
        pass

    raw_genres = series_details.get('genres', [])
    genres = []
    if isinstance(raw_genres, list):
        for g in raw_genres:
            if isinstance(g, dict) and 'name' in g:
                genres.append(g['name'])
            elif isinstance(g, str):
                genres.append(g)

    video_info.setGenres(genres)
    video_info.setTitle(series_details.get('episode_display_title', title))
    video_info.setMediaType('episode')
    try:
        runtime_minutes = int(series_details.get('runtime', 0) or 0)
        if runtime_minutes > 0:
            video_info.setDuration(runtime_minutes * 60)
    except Exception:
        pass

    try:
        if series_details.get('season') is not None:
            video_info.setSeason(int(series_details.get('season')))
        if series_details.get('episode') is not None:
            video_info.setEpisode(int(series_details.get('episode')))
    except Exception:
        pass

    list_item.setInfo('video', video_info)
    list_item.setProperty('genre', ", ".join(genres))
    list_item.setProperty('plot', series_details.get('overview', ''))
    list_item.setProperty('category', get_series_category(series_details))
    list_item.setProperty('IsPlayable', 'true')

    return list_item
   
def list_series(series_titles, genre=None, page=1, category=None, only_4k=False):
    """Show TV shows as folders grouped by series_title."""
    xbmcplugin.setContent(addon_handle, 'tvshows')

    page = safe_int(page, 1)
    if page < 1:
        page = 1

    items_per_page = 50
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page

    if not isinstance(series_titles, dict):
        series_titles = {}

    all_series_data = list(series_titles.values())

    if category:
        category_lower = str(category).lower()
        all_series_data = [
            s for s in all_series_data
            if get_series_category(s).lower() == category_lower
        ]

    shows = {}
    for s in all_series_data:
        show_title = str(s.get('series_title') or get_series_base_title(s)).strip()
        if not show_title:
            continue

        key = show_title.lower()

        if key not in shows:
            shows[key] = {
                'title': show_title,
                'item': s,
                'episodes': 0,
                'seasons': set()
            }

        shows[key]['episodes'] += 1

        season_num = safe_int(s.get('season'), 0)
        if season_num > 0:
            shows[key]['seasons'].add(season_num)

    show_list = sorted(shows.values(), key=lambda x: x['title'].lower())

    total_shows = len(show_list)
    paged_shows = show_list[start_index:end_index]

    for show in paged_shows:
        show_title = show['title']
        item_data = show['item']
        episode_count = show['episodes']
        season_count = len(show['seasons'])

        tmdb_details = get_series_details(show_title)

        display_data = item_data.copy()
        if tmdb_details:
            display_data.update(tmdb_details)

        year_text = ""
        first_air_date = display_data.get('first_air_date') or display_data.get('release_date') or ""
        if first_air_date and len(first_air_date) >= 4:
            year_text = f" [COLOR grey]({first_air_date[:4]})[/COLOR]"

        season_label = "Season" if season_count == 1 else "Seasons"
        episode_label = "Episode" if episode_count == 1 else "Episodes"

        display_title = f"{show_title}{year_text}"

        list_item = make_series_list_item(display_title, display_data)

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_series_seasons&series_title={urllib.parse.quote_plus(show_title)}",
            list_item,
            isFolder=True
        )

    total_pages = (total_shows + items_per_page - 1) // items_per_page

    if page > 1:
        prev_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]<< Previous Page[/COLOR]")
        prev_page_item.setArt({
            'icon': os.path.join(ICONS_PATH, 'previous.png'),
            'fanart': FANART_PATH
        })
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=gv_go_back",
            prev_page_item,
            isFolder=False
        )

    if page < total_pages:
        next_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_item.setArt({
            'icon': os.path.join(ICONS_PATH, 'next.png'),
            'fanart': FANART_PATH
        })

        if category:
            next_url = (
                f"{sys.argv[0]}?action=list_series_by_category"
                f"&category={urllib.parse.quote_plus(category)}"
                f"&page={page + 1}"
            )
        else:
            next_url = (
                f"{sys.argv[0]}?action=list_series"
                f"&page={page + 1}"
            )

        xbmcplugin.addDirectoryItem(
            addon_handle,
            next_url,
            next_item,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(addon_handle)
    
def list_series_seasons(series_title):
    """Show seasons for one series."""
    xbmcplugin.setContent(addon_handle, 'seasons')

    series_titles = read_series_list(file_path)
    seasons = set()
    poster_data = None

    for s in series_titles.values():
        if str(s.get('series_title', '')).strip().lower() == series_title.strip().lower():
            season = safe_int(s.get('season'), 0)
            if season > 0:
                seasons.add(season)

            if poster_data is None:
                poster_data = s.copy()

    tmdb_details = get_series_details(series_title)

    display_data = poster_data.copy() if poster_data else {}
    if tmdb_details:
        display_data.update(tmdb_details)

    for season in sorted(seasons):
        list_item = make_series_list_item(f"Season {season}", display_data)
        list_item.setProperty('IsPlayable', 'false')

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_series_episodes&series_title={urllib.parse.quote_plus(series_title)}&season={season}",
            list_item,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(addon_handle)

def list_series_episodes(series_title, season):
    """Show playable episodes for selected series season."""
    xbmcplugin.setContent(addon_handle, 'episodes')

    season = safe_int(season, 1)
    series_titles = read_series_list(file_path)

    episodes = []

    for s in series_titles.values():
        if str(s.get('series_title', '')).strip().lower() == series_title.strip().lower():
            if safe_int(s.get('season'), 0) == season:
                episodes.append(s)

    episodes = sorted(episodes, key=lambda x: safe_int(x.get('episode'), 0))

    sources_by_episode = {}
    for s in episodes:
        ep_num = safe_int(s.get('episode'), 0)
        url = str(s.get('url', '')).strip()

        if ep_num <= 0 or not url:
            continue

        key = str(ep_num)

        if key not in sources_by_episode:
            sources_by_episode[key] = []

        sources_by_episode[key].append({
            'title': get_episode_title(s),
            'url': url,
            'category': get_series_category(s),
            'is_4k': s.get('is_4k', False),
            'series_title': get_series_base_title(s),
            'season': s.get('season'),
            'episode': s.get('episode')
        })
    tmdb_details = get_series_details(series_title) 
    seen_episodes = set()

    for s in episodes:
        ep_num = safe_int(s.get('episode'), 0)
        url = str(s.get('url', '')).strip()

        if ep_num <= 0 or not url:
            continue

        title_key = str(ep_num)

        if title_key in seen_episodes:
            continue
         
        seen_episodes.add(title_key)

        sources = sources_by_episode.get(title_key, [])

        display_title = f"S{season:02d}E{ep_num:02d}  [COLOR gray]•[/COLOR]  Episode {ep_num:02d}"
        if len(sources) > 1:
            display_title += " [COLOR FFD4AF37][Multi][/COLOR]"

        display_data = s.copy()
        if tmdb_details:
            display_data.update(tmdb_details)

        display_data['episode_display_title'] = display_title

        list_item = make_series_list_item(display_title, display_data)
        list_item.setProperty('IsPlayable', 'true')

        if len(sources) > 1:
            sources_json = urllib.parse.quote_plus(json.dumps(sources, ensure_ascii=False))
            play_url = f"{sys.argv[0]}?action=play_series_sources&title={urllib.parse.quote_plus(series_title + ' S' + str(season).zfill(2) + 'E' + str(ep_num).zfill(2))}&sources={sources_json}"
        else:
            play_url = f"{sys.argv[0]}?action=play_series&title={urllib.parse.quote_plus(series_title + ' S' + str(season).zfill(2) + 'E' + str(ep_num).zfill(2))}&url={urllib.parse.quote_plus(url)}"

        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)
    
def list_series_categories(page=1):
    xbmcplugin.setContent(addon_handle, 'files')

    page = safe_int(page, 1)
    if page < 1:
        page = 1

    items_per_page = 50
    start_index = (page - 1) * items_per_page

    all_series_data = read_series_list(file_path)

    unique_categories = set()

    for s in all_series_data.values():
        category = get_series_category(s)

        if category and str(category).strip():
            unique_categories.add(category)

    sorted_categories = sorted(list(unique_categories), key=str.lower)
    total_categories = len(sorted_categories)
    paged_categories_slice = sorted_categories[start_index:start_index + items_per_page]

    for category in paged_categories_slice:
        show_names = set()

        for s in all_series_data.values():
            if get_series_category(s).lower() == category.lower():
                show_title = str(s.get('series_title') or get_series_base_title(s)).strip().lower()
                if show_title:
                    show_names.add(show_title)

        count = len(show_names)

        list_item = xbmcgui.ListItem(f"[COLOR FFD4AF37]{category}[/COLOR] [COLOR grey]({count})[/COLOR]")
        list_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_series_by_category&category={urllib.parse.quote_plus(category)}&page=1",
            list_item,
            isFolder=True
        )

    total_pages = (total_categories + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_series_categories&page={page + 1}",
            next_page_item,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(addon_handle)

def list_series_by_category(category, page=1):
    series_titles = read_series_list(file_path)
    list_series(series_titles, genre=None, page=safe_int(page, 1), category=category)

def get_series_history_file_path():
    """Returns a separate search history file for TV Shows."""
    try:
        addon = xbmcaddon.Addon()
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        if not os.path.exists(profile_path):
            os.makedirs(profile_path)
        return os.path.join(profile_path, 'series_search_history.json')
    except Exception as e:
        log(f"Error creating series history folder path: {e}", level=xbmc.LOGERROR)
        return ""

def load_series_search_history():
    path = get_series_history_file_path()
    if path and os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except Exception:
            return []
    return []

def save_series_search_history(history_list):
    path = get_series_history_file_path()
    if path:
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(history_list, f, ensure_ascii=False, indent=4)
        except Exception as e:
            log(f"Failed to write series search history file: {e}", level=xbmc.LOGERROR)

def add_series_term_to_history(term):
    term = str(term or '').strip()
    if not term:
        return
    history = load_series_search_history()
    if term in history:
        history.remove(term)
    history.insert(0, term)
    history = history[:20]
    save_series_search_history(history)

def clear_series_search_history():
    save_series_search_history([])
    xbmcgui.Dialog().notification("Search History", "Series history cleared.", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=gv_search_series_menu,replace)")

def gv_search_series_menu():
    xbmcplugin.setContent(addon_handle, 'files')

    new_search_item = xbmcgui.ListItem("[COLOR FFD4AF37][B][ New Series Search... ][/B][/COLOR]")
    new_search_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=gv_search_series_keyboard", new_search_item, isFolder=False)

    history = load_series_search_history()

    if history:
        for index, term in enumerate(history):
            history_item = xbmcgui.ListItem(f"[COLOR white]{term}[/COLOR]")
            history_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
            fresh = int(time.time()) + index
            search_url = f"{sys.argv[0]}?action=gv_search_series_results&q={urllib.parse.quote_plus(term)}&page=1&fresh={fresh}"
            xbmcplugin.addDirectoryItem(addon_handle, search_url, history_item, isFolder=True)

        clear_item = xbmcgui.ListItem("[COLOR grey][ Clear Search History ][/COLOR]")
        clear_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=gv_clear_series_history", clear_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def gv_search_series_keyboard():
    kb = xbmc.Keyboard('', 'Search GoldenVault Series', False)
    kb.doModal()

    if kb.isConfirmed():
        text = kb.getText().strip()

        if text:
            add_series_term_to_history(text)
            fresh = int(time.time())
            search_url = f"{sys.argv[0]}?action=gv_search_series_results&q={urllib.parse.quote_plus(text)}&page=1&fresh={fresh}"
            xbmc.executebuiltin(f"Container.Update({search_url})")
        else:
            xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=gv_search_series_menu,replace)")
    else:
        xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=gv_search_series_menu,replace)")

    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)


def gv_search_series_results(search_text, page=1, fresh=''):
    try:
        xbmcplugin.setContent(addon_handle, 'tvshows')
        search_text = urllib.parse.unquote_plus(str(search_text or '')).strip()

        if not search_text:
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

        page = safe_int(page, 1)
        if page < 1:
            page = 1

        items_per_page = 50
        start_index = (page - 1) * items_per_page
        end_index = start_index + items_per_page

        series_titles = read_series_list(file_path)
        all_series = list(series_titles.values())

        matched = []
        search_lower = search_text.lower()

        for s_data in all_series:
            show_title = str(s_data.get('series_title') or get_series_base_title(s_data)).strip()
            category = get_series_category(s_data).lower()

            if search_lower in show_title.lower() or search_lower in category:
                matched.append(s_data)

        shows = {}

        for s_data in matched:
            show_title = str(s_data.get('series_title') or get_series_base_title(s_data)).strip()

            if not show_title:
                continue

            key = show_title.lower()

            if key not in shows:
                shows[key] = {
                    'title': show_title,
                    'item': s_data,
                    'episodes': 0,
                    'seasons': set()
                }

            shows[key]['episodes'] += 1

            season_num = safe_int(s_data.get('season'), 0)
            if season_num > 0:
                shows[key]['seasons'].add(season_num)

        show_list = sorted(shows.values(), key=lambda x: x['title'].lower())

        if not show_list:
            xbmcgui.Dialog().ok("No Results", f"No series found for '{search_text}'")
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

        paged_shows = show_list[start_index:end_index]

        for show in paged_shows:
            show_title = show['title']
            item_data = show['item']
            episode_count = show['episodes']
            season_count = len(show['seasons'])

            tmdb_details = get_series_details(show_title)

            display_data = item_data.copy()
            if tmdb_details:
                display_data.update(tmdb_details)

            year_text = ""
            first_air_date = display_data.get('first_air_date') or display_data.get('release_date') or ""

            if first_air_date and len(first_air_date) >= 4:
                year_text = f" [COLOR grey]({first_air_date[:4]})[/COLOR]"

            display_title = f"{show_title}{year_text}"

            list_item = make_series_list_item(display_title, display_data)

            xbmcplugin.addDirectoryItem(
                addon_handle,
                f"{sys.argv[0]}?action=list_series_seasons&series_title={urllib.parse.quote_plus(show_title)}",
                list_item,
                isFolder=True
            )

        total_pages = (len(show_list) + items_per_page - 1) // items_per_page

        if page > 1:
            prev_item = xbmcgui.ListItem("[COLOR FFD4AF37]<< Previous Page[/COLOR]")
            prev_item.setArt({'icon': os.path.join(ICONS_PATH, 'previous.png'), 'fanart': FANART_PATH})
            xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=gv_series_go_back", prev_item, isFolder=False)

        if page < total_pages:
            next_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
            next_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png'), 'fanart': FANART_PATH})
            xbmcplugin.addDirectoryItem(
                addon_handle,
                f"{sys.argv[0]}?action=gv_search_series_results&q={urllib.parse.quote_plus(search_text)}&page={page + 1}&fresh={fresh}",
                next_item,
                isFolder=True
            )

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log(f"GoldenVault series search error: {e}", level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

def play_series(title, url):
    """Resolve and play a series episode URL."""
    try:
        log("=== GOLDVAULT SERIES PLAYBACK ===", level=xbmc.LOGINFO)
        log(f"Series Target: {title}", level=xbmc.LOGINFO)

        if not url:
            raise Exception("Null URL execution bypass.")

        playable_url = urllib.parse.unquote_plus(url).strip()

        if '?' in playable_url:
            url_path, token_query = playable_url.split('?', 1)
            url_path = url_path.replace(" ", "%20")
            playable_url = f"{url_path}?{token_query}"
        else:
            playable_url = playable_url.replace(" ", "%20")

        headers = {
            "User-Agent": USER_AGENT,
            "Accept": "*/*",
            "Connection": "keep-alive"
        }
        header_string = urllib.parse.urlencode(headers)

        if "|" not in playable_url:
            final_kodi_path = f"{playable_url}|{header_string}"
        else:
            final_kodi_path = playable_url

        list_item = xbmcgui.ListItem(title, path=final_kodi_path)
        list_item.setProperty("IsPlayable", "true")

        clean_extension_check = playable_url.split("?")[0].lower()
        if clean_extension_check.endswith(".mp4"):
            list_item.setMimeType("video/mp4")
        elif clean_extension_check.endswith(".mkv"):
            list_item.setMimeType("video/x-matroska")
        elif clean_extension_check.endswith(".m3u8"):
            list_item.setMimeType("application/vnd.apple.mpegurl")
        else:
            list_item.setMimeType("video/*")

        try:
            response_check = requests.get(playable_url, headers=headers, stream=True, timeout=5)

            if response_check.status_code >= 400:
                raise Exception(f"Server returned failure status: {response_check.status_code}")

            response_check.close()

        except Exception as network_error:
            log(f"Series pre-check confirmed dead link: {network_error}", level=xbmc.LOGWARNING)
            raise Exception("Series link failed verification.")

        log("Launching Kodi series player...", level=xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(addon_handle, True, list_item)

    except Exception as e:
        log(f"Series playback error handler: {e}", level=xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

        title_color = "FFD4AF37"
        accent_color = "FFD4AF37"
        version_text = "FFB8B8B8"
        desc_text_color = "FFFFFFFF"

        try:
            addon = xbmcaddon.Addon()
            current_version = addon.getAddonInfo("version")
            remote_version = current_version

            r = requests.get(REMOTE_ADDONS_XML, timeout=4)
            if r.status_code == 200:
                match = re.search(
                    r'<addon\s+id="' + re.escape(addon_id) + r'"[^>]*version="([^"]+)"',
                    r.text
                )
                if match:
                    remote_version = match.group(1)

            if version_tuple(current_version) < version_tuple(remote_version):
                message = (
                    f"[B][COLOR {accent_color}]A Newer GoldenVault Version Is Now Available- v{remote_version}[/COLOR][/B]\n"
                    f"[B][COLOR {version_text}]Your Current Version: v{current_version}[/COLOR][/B]\n\n"
                    f"[COLOR {desc_text_color}]Stream failed to load. Some series streams may occasionally change over time.[/COLOR]\n"
                    f"[COLOR {desc_text_color}]Please try again later or select a different stream while links update.[/COLOR]"
                )
                xbmcgui.Dialog().ok(f"[B][COLOR {title_color}]GoldenVault Notice[/COLOR][/B]", message)
                return

            message = (
                f"[B][COLOR {accent_color}]Stream Failed To Load[/COLOR][/B]\n\n"
                f"[COLOR {desc_text_color}]Some series streams may occasionally change or become unavailable over time.[/COLOR]\n"
                f"[COLOR {desc_text_color}]Please try again later or select a different stream while links update.[/COLOR]"
            )
            xbmcgui.Dialog().ok(f"[B][COLOR {title_color}]GoldenVault Notice[/COLOR][/B]", message)

        except Exception as debug_error:
            log(f"Series debug helper failed: {debug_error}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Playback Error", "The series list is updating.\nPlease try again later.")