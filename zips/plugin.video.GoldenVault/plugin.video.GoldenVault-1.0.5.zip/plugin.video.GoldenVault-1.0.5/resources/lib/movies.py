import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import urllib.parse
import requests
import requests
import sys
import os
import re
import json  # Import the json module
# import tv_functions
import time
import threading # Import threading for search

# Addon info
addon_handle = int(sys.argv[1])
addon_id = 'plugin.video.GoldenVault'  # Change this to your addon's ID

# Configuration options
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
EXTRA_HEADERS = {}
PROXY = None
# write your addons.xml file here. 
REMOTE_ADDONS_XML = "https://raw.githubusercontent.com/nuxzs/repo/refs/heads/main/addons.xml"
# Write your TMDB key only once here. Kodi settings can override it if you add a tmdb_api_key setting later.
DEFAULT_TMDB_API_KEY = 'a0bf207c5ff6c0caabac0327e39b1cd2'
# Declare a global runtime memory cache for TMDB results
TMDB_RUNTIME_CACHE = {}

# --- PHYSICAL FILE CACHE SETTINGS ---
CACHE_FILE_LIMIT = 1000  # Wipes and resets when it hits 200 movies
CACHE_DIR = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CACHE_FILE_PATH = os.path.join(CACHE_DIR, 'tmdb_cache.json')
if not os.path.exists(CACHE_DIR):
    try:
        os.makedirs(CACHE_DIR)
    except Exception:
        pass

def load_local_cache():
    """Loads the movie cache from local storage file."""
    if os.path.exists(CACHE_FILE_PATH):
        try:
            with open(CACHE_FILE_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_local_cache(cache_data):
    """Saves cache safely. Automatically drops the oldest single item when full instead of wiping everything."""
    try:
        # If we exceed our headroom limit, gently drop items until we fit
        while len(cache_data) > CACHE_FILE_LIMIT:
            # Pop out the first/oldest item in the cache dictionary to make room
            oldest_key = next(iter(cache_data))
            cache_data.pop(oldest_key, None)
            
        with open(CACHE_FILE_PATH, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        xbmc.log(f"[plugin.video.GoldenVault] Failed to write cache file: {e}", xbmc.LOGWARNING)

def get_tmdb_api_key():
    """Gets the TMDB API key from addon settings or uses the single fallback above."""
    try:
        addon = xbmcaddon.Addon()
        setting_key = addon.getSetting('tmdb_api_key')
        return setting_key or DEFAULT_TMDB_API_KEY
    except Exception as e:
        print(f"Error getting TMDB API key: {e}")
        return DEFAULT_TMDB_API_KEY

TMDB_API_KEY = get_tmdb_api_key()
# Path to your text file.  Make sure this is correct!
# UPDATED: GENRES_FILE_PATH to point to the 'resources' folder
ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
file_path = os.path.join(ADDON_ROOT, 'resources', 'movie_list.json')
# Path to the icons folder
ICONS_PATH = os.path.join(ADDON_ROOT, 'resources', 'images', 'icons')
FANART_PATH = os.path.join(ADDON_ROOT, 'resources', 'images', 'fanart.jpg') #added fanart path
# Declare the cache variable globally and initialize it


def log(message, level=xbmc.LOGINFO):
    """Logs messages to the Kodi log file."""
    xbmc.log(f'[{addon_id}] {message}', level=level)
    
def safe_int(value, default=1):
    try:
        return int(value)
    except Exception:
        return default

def read_movie_list(file_path):
    """Reads movie titles and URLs from JSON without overwriting duplicate names."""
    movie_titles = {}
    try:
        log(f"Reading movie list from: {file_path}", level=xbmc.LOGDEBUG)
        with open(file_path, 'r', encoding='utf-8') as f:
            movie_data = json.load(f)

        if "movies" in movie_data:
            for index, movie in enumerate(movie_data["movies"]):
                if "title" in movie and "url" in movie:
                    title = str(movie["title"]).strip()
                    category = get_movie_category(movie)

                    unique_key = f"{title}_||_{category}_||_{index}"

                    movie_titles[unique_key] = movie
                else:
                    log(f"Skipping movie with missing title or URL: {movie}", level=xbmc.LOGWARNING)
        else:
            log(f"Warning: 'movies' key not found in JSON file: {file_path}", level=xbmc.LOGWARNING)

    except Exception as e:
        log(f"Error reading file: {e}", level=xbmc.LOGERROR)
        return {}

    log(f"Read {len(movie_titles)} movies from file.", level=xbmc.LOGDEBUG)
    return movie_titles
    
def get_movie_details(title):
    """Fetches movie metadata safely using your reliable requests setup with a file-cache shield."""
    if not title:
        return {}
        
    # 1. Read from local storage file instantly (0ms loading time!)
    cache = load_local_cache()
    if title in cache:
        cached = cache[title]
    # Old cache did not have runtime/genres.
    # Force refresh only old/incomplete cache items.
        if cached.get('runtime') and cached.get('genres'):
            return cached

    # 2. Grab your working API key safely
    api_key = get_tmdb_api_key()

    url = f"https://api.themoviedb.org/3/search/movie?api_key={api_key}&query={urllib.parse.quote_plus(title)}"
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/json"
    }

    try:
        # The exact requests setup you confirmed is working perfectly
        response = requests.get(url, headers=headers, timeout=5)
        
        if response.status_code == 429:
            xbmc.log(f"[plugin.video.GoldenVault] TMDB Rate Limited (429) for: {title}", xbmc.LOGWARNING)
            return {}
            
        if response.status_code != 200:
            return {}

        if not response.text or not response.text.strip():
            return {}

        data = response.json()
        
        if data.get('results'):
            
            movie_info = data['results'][0]
            tmdb_id = movie_info.get('id')
            runtime = 0
            genres = []
            
            if tmdb_id:
                details_url = f"https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={api_key}"

                try:
                    details_response = requests.get(details_url, headers=headers, timeout=5)

                    if details_response.status_code == 200 and details_response.text.strip():
                        details_data = details_response.json()
                        runtime = details_data.get('runtime', 0)

                        raw_genres = details_data.get('genres', [])
                        if isinstance(raw_genres, list):
                            genres = [g.get('name') for g in raw_genres if isinstance(g, dict) and g.get('name')]

                except Exception as e:
                    xbmc.log(f"[plugin.video.GoldenVault] TMDB details request failed for '{title}': {e}", xbmc.LOGWARNING)
            
            metadata = {
                'tmdb_id': tmdb_id,
                'poster_path': movie_info.get('poster_path', ''),
                'backdrop_path': movie_info.get('backdrop_path', ''),
                'overview': movie_info.get('overview', ''),
                'release_date': movie_info.get('release_date', ''),
                'vote_average': movie_info.get('vote_average', 0),
                'year': movie_info.get('release_date', '').split('-')[0] if movie_info.get('release_date') else '',
                'runtime': runtime,
                'genres': genres
            }
            
            # 3. Save new movie information back to your storage file
            cache = load_local_cache()
            cache[title] = metadata
            save_local_cache(cache)
            
            return metadata

    except Exception as e:
        xbmc.log(f"[plugin.video.GoldenVault] TMDB Request failed for '{title}': {e}", xbmc.LOGERROR)

    return {}
    
def get_movie_category(movie_data):
    """Returns the category/group from movie_list.json."""
    category = (
        movie_data.get('category')
        or movie_data.get('group-title')
        or movie_data.get('group_title')
        or movie_data.get('group')
        or 'Other'
    )
    category = str(category).strip()
    return category if category else 'Other'

def is_movie_4k(movie_details):
    """Determines if a movie is 4K based on the 'is_4k' field."""
    return movie_details.get('is_4k', False)

def play_movie_sources(title, sources_json):
    try:
        sources = json.loads(urllib.parse.unquote_plus(sources_json))
    except Exception:
        sources = []

    if not sources:
        xbmcgui.Dialog().notification("Error", "No links found.", xbmcgui.NOTIFICATION_ERROR)
        return

    if len(sources) == 1:
        play_movie(title, sources[0].get('url', ''))
        return
    sources = sorted(sources, key=lambda x: not x.get('is_4k', False))
    
    options = []
    for i, src in enumerate(sources, 1):
        cat = src.get('category', 'Other')
        quality = "[COLOR FFF2D66D][B]4K UHD[/B][/COLOR]" if src.get('is_4k') else "[COLOR white][B]HD/SD  [/B][/COLOR]"
        options.append(f"[COLOR white]{i}.[/COLOR] Quality: {quality}  |  Category: [COLOR FFB89D4B]{cat}[/COLOR]")

    choice = xbmcgui.Dialog().select(f"Choose Quality / Sources - {title}", options)

    if choice == -1:
        return

    play_movie(title, sources[choice].get('url', ''))

def build_sources_by_title(movie_list):
    sources_by_title = {}

    for movie in movie_list:
        title = movie.get('title', '').strip()
        url = movie.get('url', '').strip()

        if not title or not url:
            continue

        key = title.lower()

        if key not in sources_by_title:
            sources_by_title[key] = []

        sources_by_title[key].append({
            'title': title,
            'url': url,
            'category': get_movie_category(movie),
            'is_4k': movie.get('is_4k', False)
        })

    return sources_by_title
    
def list_movies(movie_titles, genre=None, page=1, category=None, only_4k=False):
    """Lists the movies in Kodi with pagination and optional genre/category filtering."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page

    all_local_movies_data = sorted(movie_titles.values(), key=lambda x: x.get('title', '').lower())

    filtered_movies = all_local_movies_data
    
    if only_4k:
        filtered_movies = [
            movie_data for movie_data in filtered_movies
            if movie_data.get('is_4k', False)
    ]
 
    if genre:
        temp_filtered = []
        for movie_data in filtered_movies:
            movie_genres = movie_data.get('genres', [])
            if isinstance(movie_genres, list):
                if genre.lower() in [g.lower() for g in movie_genres if isinstance(g, str)]:
                    temp_filtered.append(movie_data)
        filtered_movies = temp_filtered

    if category:
        category_lower = category.lower()
        filtered_movies = [
            movie_data for movie_data in filtered_movies
            if get_movie_category(movie_data).lower() == category_lower
        ]
    all_sources_by_title = build_sources_by_title(all_local_movies_data)
    sources_by_title = build_sources_by_title(filtered_movies)

    unique_movies = []
    seen_titles = set()

    for movie_data in filtered_movies:
        title_key = movie_data.get('title', '').strip().lower()

        if title_key and title_key not in seen_titles:
            seen_titles.add(title_key)
            unique_movies.append(movie_data)

    filtered_movies = unique_movies

                     
    total_movies_for_pagination = len(filtered_movies)
    paged_local_movies_slice = filtered_movies[start_index:end_index]
    
    # --- SPEED BOOST & PROTECTION WITH PERSISTENT CACHE ---
    cache = load_local_cache()  # Reads your local storage file once
    threads = []
    for movie_data in paged_local_movies_slice:
        title = movie_data.get('title')
        if title:
            clean_title = title.split('_||_')[0]
            
            # --- THIS IS THE NEW FIX ---
            # It checks if the movie is already saved. If it is, it skips the 0.4 second wait!
            if clean_title not in cache:
                t = threading.Thread(target=get_movie_details, args=(clean_title,))
                threads.append(t)
                t.start()
                time.sleep(0.4)  # Only waits for BRAND NEW movies!
            
    movies_to_display = []
    for movie_data in paged_local_movies_slice:
        title = movie_data.get('title')
        url = movie_data.get('url')

        if not title or not url:
            log(f"Skipping malformed movie entry in local list: {movie_data}", level=xbmc.LOGWARNING)
            continue

        tmdb_details = get_movie_details(title)

        movie_details_for_display = movie_data.copy()
        if tmdb_details:
            movie_details_for_display.update(tmdb_details)

        movies_to_display.append((title, url, movie_details_for_display))

    for title, url, movie_details in movies_to_display:
        display_title = title

        release_date = movie_details.get('release_date')
        year_val = movie_details.get('year')

        if release_date and len(release_date) >= 4:
            year_val = release_date.split('-')[0]

        if year_val:
            display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]"

        sources = all_sources_by_title.get(title.strip().lower(), sources_by_title.get(title.strip().lower(), []))

        has_4k_source = is_movie_4k(movie_details) or any(src.get('is_4k') for src in sources)

        if has_4k_source:
            display_title += " [COLOR FFD4AF37]4K[/COLOR]"

        if len(sources) > 1:
            display_title += " [COLORFFA9B2C3][Multi][/COLOR]"   

        list_item = xbmcgui.ListItem(display_title)
        
        video_info = list_item.getVideoInfoTag()

        clean_meta_title = movie_details.get('title', title)

        video_info.setTitle(clean_meta_title)
        video_info.setOriginalTitle(clean_meta_title)
        video_info.setSortTitle(clean_meta_title)
        video_info.setMediaType('movie')
        if release_date:
            try:
                video_info.setPremiered(release_date)
            except Exception:
                pass

            try:
                video_info.setFirstAired(release_date)
            except Exception:
                pass

        if year_val:
            try:
                video_info.setYear(int(year_val))
            except Exception:
                pass

        poster_path = movie_details.get('poster_path')
        backdrop_path = movie_details.get('backdrop_path')

        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            fanart_to_use = f"https://image.tmdb.org/t/p/original/{backdrop_path}" if backdrop_path else FANART_PATH
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'icon': poster_url,
                'fanart': fanart_to_use,
                'landscape': fanart_to_use,
                'banner': fanart_to_use
            })
        else:
            default_poster_path = os.path.join(ICONS_PATH, 'DefaultVideo.png')
            list_item.setArt({
                'thumb': default_poster_path,
                'poster': default_poster_path,
                'fanart': FANART_PATH
            })

        
        video_info.setPlot(movie_details.get('overview', ''))
        video_info.setTagLine(movie_details.get('overview', '')[:120])

        try:
            if release_date and len(release_date) >= 4:
                video_info.setYear(int(release_date.split('-')[0]))
            elif movie_details.get('year'):
                video_info.setYear(int(movie_details.get('year')))
        except Exception:
            pass

        try:
            video_info.setRating(float(movie_details.get('vote_average', 0)))
        except Exception:
            pass

        raw_genres = movie_details.get('genres', [])
        genres = []
        if isinstance(raw_genres, list):
            for g in raw_genres:
                if isinstance(g, dict) and 'name' in g:
                    genres.append(g['name'])
                elif isinstance(g, str):
                    genres.append(g)

        video_info.setGenres(genres)
        clean_meta_title = movie_details.get('title', title)

        video_info.setTitle(clean_meta_title)
        video_info.setOriginalTitle(clean_meta_title)
        video_info.setSortTitle(clean_meta_title)
        video_info.setMediaType('movie')
        
        runtime_minutes = movie_details.get('runtime', 0)
        try:
            video_info.setDuration(int(runtime_minutes) * 60 if runtime_minutes else 0)
        except Exception:
            pass

        list_item.setInfo('video', video_info)

        plot = movie_details.get('overview', '')
        genre_str = ", ".join(genres)
        list_item.setProperty('genre', genre_str)
        list_item.setProperty('plot', plot)
        list_item.setProperty('is_4k', 'true' if movie_details.get('is_4k', False) else 'false')
        list_item.setProperty('category', get_movie_category(movie_details))
        
        # FIX: Explicitly notify Kodi core this selection executes dynamic link resolution
        list_item.setProperty('IsPlayable', 'true')

        sources = all_sources_by_title.get(title.strip().lower(), sources_by_title.get(title.strip().lower(), []))

        if len(sources) > 1:
            sources_json = urllib.parse.quote_plus(json.dumps(sources, ensure_ascii=False))
            play_url = f"{sys.argv[0]}?action=play_sources&title={urllib.parse.quote_plus(title)}&sources={sources_json}"
        else:
            play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"

        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_movies_for_pagination + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_icon = os.path.join(ICONS_PATH, 'next.png')
        
        next_page_item.setArt({
            'icon': next_icon,
            'thumb': next_icon,
            'poster': next_icon,
            'fanart': FANART_PATH
        })
        next_url = (
            f"{sys.argv[0]}?action=list_movies"
            f"&genre={urllib.parse.quote_plus(str(genre) if genre else '')}"
            f"&category={urllib.parse.quote_plus(str(category) if category else '')}"
            f"&page={page + 1}"
        )
        xbmcplugin.addDirectoryItem(
            addon_handle,
            next_url,
            next_page_item,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(addon_handle)
 
    
def list_movies_by_genre(genre, page=1):
    """Lists movies belonging to a specific genre with pagination."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    all_movies_data = read_movie_list(file_path)
    filtered_movies_by_genre = []

    for movie_data in all_movies_data.values():
        movie_genres = movie_data.get('genres', [])
        if isinstance(movie_genres, list):
            if genre.lower() in [g.lower() for g in movie_genres if isinstance(g, str)]:
                filtered_movies_by_genre.append(movie_data)

    sorted_movies = sorted(filtered_movies_by_genre, key=lambda x: x.get('title', '').lower())
    total_movies_in_genre = len(sorted_movies)
    paged_movies_slice = sorted_movies[start_index:start_index + items_per_page]

    for movie_data in paged_movies_slice:
        title = movie_data.get('title')
        url = movie_data.get('url')

        if not title or not url:
            continue

        tmdb_details = get_movie_details(title)

        movie_details = movie_data.copy()
        if tmdb_details:
            movie_details.update(tmdb_details)

        display_title = title

        year_val = movie_details.get('year')
        release_date = movie_details.get('release_date')
        if release_date and len(release_date) >= 4:
            year_val = release_date.split('-')[0]

        if year_val:
            display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]"

        if movie_details.get('is_4k', False):
            display_title += " [COLOR FFD4AF37]4K[/COLOR]"

        list_item = xbmcgui.ListItem(display_title)

        poster_path = movie_details.get('poster_path')
        backdrop_path = movie_details.get('backdrop_path')

        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            fanart_to_use = f"https://image.tmdb.org/t/p/original/{backdrop_path}" if backdrop_path else FANART_PATH
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'banner': poster_url,
                'clearart': poster_url,
                'clearlogo': poster_url,
                'landscape': poster_url,
                'fanart': fanart_to_use
            })
        else:
            list_item.setArt({
                'thumb': os.path.join(ICONS_PATH, 'DefaultVideo.png'),
                'poster': os.path.join(ICONS_PATH, 'DefaultVideo.png'),
                'fanart': FANART_PATH
            })

        video_info = list_item.getVideoInfoTag()
        clean_meta_title = movie_details.get('title', title)

        video_info.setTitle(clean_meta_title)
        video_info.setOriginalTitle(clean_meta_title)
        video_info.setSortTitle(clean_meta_title)
        video_info.setMediaType('movie')
        video_info.setPlot(movie_details.get('overview', ''))
        video_info.setTagLine(movie_details.get('overview', '')[:120])

        try:
            video_info.setRating(float(movie_details.get('vote_average', 0)))
        except Exception:
            pass

        raw_genres = movie_details.get('genres', [])
        genres = []
        if isinstance(raw_genres, list):
            for g in raw_genres:
                if isinstance(g, dict) and 'name' in g:
                    genres.append(g['name'])
                elif isinstance(g, str):
                    genres.append(g)

        video_info.setGenres(genres)
        runtime_minutes = movie_details.get('runtime', 0)
        try:
            video_info.setDuration(int(runtime_minutes) * 60 if runtime_minutes else 0)
        except Exception:
            pass

        list_item.setInfo('video', video_info)
        list_item.setProperty('genre', ", ".join(genres))
        list_item.setProperty('plot', movie_details.get('overview', ''))
        list_item.setProperty('is_4k', 'true' if movie_details.get('is_4k', False) else 'false')
        
        # FIX: Explicitly notify Kodi core this selection executes dynamic link resolution
        list_item.setProperty('IsPlayable', 'true')

        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_movies_in_genre + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_movies_by_genre&genre={urllib.parse.quote_plus(genre)}&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_genres(page=1):
    """Lists available movie genres with pagination, reading from movie_list.json."""
    xbmcplugin.setContent(addon_handle, 'genres')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    all_movies_data = read_movie_list(file_path)

    unique_genres = set()
    for movie_data in all_movies_data.values():
        genres = movie_data.get('genres', [])
        if isinstance(genres, list):
            for genre_name in genres:
                if genre_name and isinstance(genre_name, str):
                    unique_genres.add(genre_name)

    sorted_genres = sorted(list(unique_genres), key=str.lower)
    total_genres = len(sorted_genres)

    paged_genres_slice = sorted_genres[start_index:start_index + items_per_page]

    for genre in paged_genres_slice:
        list_item = xbmcgui.ListItem(f"[COLOR FFD4AF37]{genre}[/COLOR]")

        icon_name = f"genre_{genre.lower().replace(' ', '_')}.png"
        genre_icon_path = os.path.join(ICONS_PATH, icon_name)

        if os.path.exists(genre_icon_path):
            icon_to_use = genre_icon_path
        else:
            icon_to_use = os.path.join(ICONS_PATH, 'DefaultFolder.png')

        list_item.setArt({'icon': icon_to_use, 'fanart': FANART_PATH})

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies_by_genre&genre={urllib.parse.quote_plus(genre)}&page=1",
            list_item,
            isFolder=True
        )

    total_pages = (total_genres + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_genres&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_categories(page=1):
    """Lists categories from the 'category' field in movie_list.json."""
    xbmcplugin.setContent(addon_handle, 'files')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    all_movies_data = read_movie_list(file_path)

    unique_categories = set()
    for movie_data in all_movies_data.values():
        unique_categories.add(get_movie_category(movie_data))

    sorted_categories = sorted(list(unique_categories), key=str.lower)
    total_categories = len(sorted_categories)
    paged_categories_slice = sorted_categories[start_index:start_index + items_per_page]

    for category in paged_categories_slice:
        count = sum(1 for movie_data in all_movies_data.values() if get_movie_category(movie_data).lower() == category.lower())
        list_item = xbmcgui.ListItem(f"[COLOR FFD4AF37]{category}[/COLOR] [COLOR grey]({count})[/COLOR]")
        list_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies_by_category&category={urllib.parse.quote_plus(category)}&page=1",
            list_item,
            isFolder=True
        )

    total_pages = (total_categories + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_categories&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_movies_by_category(category, page=1):
    """Lists movies/series for a specific category from movie_list.json."""
    movie_titles = read_movie_list(file_path)
    list_movies(movie_titles, genre=None, page=page, category=category)

def list_4k_movies(page=1):
    movie_titles = read_movie_list(file_path)
    list_movies(movie_titles, page=page, only_4k=True)
    
def list_movies_by_year(year, page=1):
    """Lists movies for a specific year with pagination."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    try:
        requested_year_int = int(year)
    except ValueError:
        xbmcgui.Dialog().notification("Error", "Invalid year specified.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    all_movies_data = read_movie_list(file_path)
    filtered_movies = []

    for movie_data in all_movies_data.values():
        movie_year = movie_data.get('year')
        try:
            if movie_year is not None and int(movie_year) == requested_year_int:
                filtered_movies.append(movie_data)
        except (ValueError, TypeError):
            pass

    sorted_movies = sorted(filtered_movies, key=lambda x: x.get('title', '').lower())
    total_movies_in_year = len(sorted_movies)
    paged_movies_slice = sorted_movies[start_index:start_index + items_per_page]

    for movie_data in paged_movies_slice:
        title = movie_data.get('title')
        url = movie_data.get('url')

        if not title or not url:
            continue

        tmdb_details = get_movie_details(title)

        movie_details = movie_data.copy()
        if tmdb_details:
            movie_details.update(tmdb_details)

        display_title = title

        year_val = movie_details.get('year')
        release_date = movie_details.get('release_date')
        if release_date and len(release_date) >= 4:
            year_val = release_date.split('-')[0]

        if year_val:
            display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]"
            
        if movie_details.get('is_4k', False):
            display_title += " [COLOR FFD4AF37]4K[/COLOR]"

        list_item = xbmcgui.ListItem(display_title)

        poster_path = movie_details.get('poster_path')
        backdrop_path = movie_details.get('backdrop_path')

        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            fanart_to_use = f"https://image.tmdb.org/t/p/original/{backdrop_path}" if backdrop_path else FANART_PATH
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'icon': poster_url,
                'fanart': fanart_to_use,
                'landscape': fanart_to_use,
                'banner': fanart_to_use
            })
        else:
            list_item.setArt({
                'thumb': os.path.join(ICONS_PATH, 'DefaultVideo.png'),
                'poster': os.path.join(ICONS_PATH, 'DefaultVideo.png'),
                'fanart': FANART_PATH
            })

        video_info = list_item.getVideoInfoTag()
        
        video_info.setPlot(movie_details.get('overview', ''))
        video_info.setTagLine(movie_details.get('overview', '')[:120])

        try:
            if release_date and len(release_date) >= 4:
                video_info.setYear(int(release_date.split('-')[0]))
            elif movie_details.get('year'):
                video_info.setYear(int(movie_details.get('year')))
        except Exception:
            pass

        try:
            video_info.setRating(float(movie_details.get('vote_average', 0)))
        except Exception:
            pass

        raw_genres = movie_details.get('genres', [])
        genres = []
        if isinstance(raw_genres, list):
            for g in raw_genres:
                if isinstance(g, dict) and 'name' in g:
                    genres.append(g['name'])
                elif isinstance(g, str):
                    genres.append(g)

        video_info.setGenres(genres)
        runtime_minutes = movie_details.get('runtime', 0)
        try:
            video_info.setDuration(int(runtime_minutes) * 60 if runtime_minutes else 0)
        except Exception:
            pass

        list_item.setInfo('video', video_info)
        list_item.setProperty('genre', ", ".join(genres))
        list_item.setProperty('plot', movie_details.get('overview', ''))
        list_item.setProperty('is_4k', 'true' if movie_details.get('is_4k', False) else 'false')
        
        # FIX: Explicitly notify Kodi core this selection executes dynamic link resolution
        list_item.setProperty('IsPlayable', 'true')

        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_movies_in_year + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_movies_by_year&year={year}&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_years(page=1):
    """Lists all available movie release years from movie_list.json."""
    xbmcplugin.setContent(addon_handle, 'years')

    all_movies_data = read_movie_list(file_path)

    unique_years = set()
    for movie_data in all_movies_data.values():
        year = movie_data.get('year')
        if year is not None:
            try:
                unique_years.add(int(year))
            except (ValueError, TypeError):
                pass

    sorted_years = sorted(list(unique_years), reverse=True)

    for year_val in sorted_years:
        list_item = xbmcgui.ListItem(f"[COLOR FFD4AF37]{year_val}[/COLOR]")
        list_item.setArt({'icon': os.path.join(ICONS_PATH, 'years.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies_by_year&year={year_val}&page=1",
            list_item,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(addon_handle)

def get_params():
    paramstring = sys.argv[2]

    if paramstring.startswith('?'):
        paramstring = paramstring[1:]

    return dict(urllib.parse.parse_qsl(paramstring))
 
def list_search_menu():
    """Builds a clean search menu matching professional addon routing architectures."""
    xbmcplugin.setContent(addon_handle, 'files')
    
    new_search_item = xbmcgui.ListItem('[COLOR FFD4AF37][ New Search... ][/COLOR]')
    new_search_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
    
    # Standard clean plugin parameter URL, exactly how The Crew structures it
    url = f"{sys.argv[0]}?action=gv_search_keyboard"
    
    # Set as isFolder=False so clicking it executes the action right here
    xbmcplugin.addDirectoryItem(addon_handle, url, new_search_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def get_history_file_path():
    """Returns a safe, writable path in the addon's data folder to store search history."""
    try:
        addon = xbmcaddon.Addon()
        # FIX: Changed xbmc.translatePath to xbmcvfs.translatePath for newer Kodi versions
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        if not os.path.exists(profile_path):
            os.makedirs(profile_path)
        return os.path.join(profile_path, 'search_history.json')
    except Exception as e:
        log(f"Error creating history folder path: {e}", level=xbmc.LOGERROR)
        return ""
        
def load_search_history():
    """Loads past search terms safely."""
    path = get_history_file_path()
    if path and os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return []
    return []

def save_search_history(history_list):
    """Saves search terms to the file database safely."""
    path = get_history_file_path()
    if path:
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(history_list, f, ensure_ascii=False, indent=4)
        except Exception as e:
            log(f"Failed to write search history file: {e}", level=xbmc.LOGERROR)

def add_term_to_history(term):
    """Adds a new term to the top of history, removing duplicates, keeping a max of 20 items."""
    if not term:
        return
    history = load_search_history()
    if term in history:
        history.remove(term) # Remove old position to bump it to the absolute top
    history.insert(0, term)
    history = history[:20] # Keep last 20 queries like premium add-ons do
    save_search_history(history)

def clear_search_history():
    """Wipes out all history items entirely."""
    save_search_history([])
    xbmcgui.Dialog().notification("Search History", "History cleared completely.", xbmcgui.NOTIFICATION_INFO, 2000)
    # Refresh container smoothly back into the fresh search menu
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=gv_search_menu,replace)")

def gv_search_menu():
    """Displays the Search Menu landing page matching professional add-on styles."""
    xbmcplugin.setContent(addon_handle, 'files')
    
    # 1. New Search Button (Always First at the Top)
    new_search_item = xbmcgui.ListItem("[COLOR FFD4AF37][B][ New Search... ][/B][/COLOR]")
    new_search_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=gv_search_keyboard", new_search_item, isFolder=False)
    
    # Load history terms to populate underneath dynamically
    history = load_search_history()
    
    # 2. Dynamic History Items List (In the Middle)
    if history:
        for index, term in enumerate(history):
            history_item = xbmcgui.ListItem(f"[COLOR white]{term}[/COLOR]")
            history_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
            
            fresh = int(time.time()) + index
            search_url = f"{sys.argv[0]}?action=gv_search_results&q={urllib.parse.quote_plus(term)}&page=1&fresh={fresh}"
            
            xbmcplugin.addDirectoryItem(addon_handle, search_url, history_item, isFolder=True)

    # 3. Clear History Button (MOVED HERE: Always forced to the absolute bottom)
    if history:
        clear_item = xbmcgui.ListItem("[COLOR grey][ Clear Search History ][/COLOR]")
        clear_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=gv_clear_history", clear_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def gv_search_keyboard():
    """Launches keyboard completely blank, saves terms safely, and updates layers correctly."""
    kb = xbmc.Keyboard('', 'Search GoldenVault Movies', False)
    kb.doModal()

    if kb.isConfirmed():
        text = kb.getText().strip()

        if text:
            # Inject history item into storage file safely
            add_term_to_history(text)
            
            fresh = int(time.time())
            # We push onto the stack without ',replace' so backing out returns perfectly to the search history selection panel
            search_url = f"{sys.argv[0]}?action=gv_search_results&q={urllib.parse.quote_plus(text)}&page=1&fresh={fresh}"
            xbmc.executebuiltin(f"Container.Update({search_url})")
        else:
            # If empty string, stay inside search landing selection framework gracefully
            xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=gv_search_menu,replace)")
    else:
        # Handled cleanly on cancel
        xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=gv_search_menu,replace)")

    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            
def gv_search_results(search_text, page=1, fresh=''):
    try:
        xbmcplugin.setContent(addon_handle, 'movies')
        search_text = urllib.parse.unquote_plus(str(search_text or '')).strip()

        if not search_text:
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

        page = safe_int(page, 1)
        if page < 1:
            page = 1

        items_per_page = 50
        start_index = (page - 1) * items_per_page
        end_index = start_index + items_per_page

        movie_titles = read_movie_list(file_path)
        all_sources_by_title = build_sources_by_title(movie_titles.values())

        matched_movies = []
        search_lower = search_text.lower()

        for title, movie_data in movie_titles.items():
            category = str(movie_data.get('category', '')).lower()

            if search_lower in title.lower() or search_lower in category:
                matched_movies.append(movie_data)

        unique_movies = []
        seen_titles = set()

        for movie_data in matched_movies:
            title_key = movie_data.get('title', '').strip().lower()

            if title_key and title_key not in seen_titles:
                seen_titles.add(title_key)
                unique_movies.append(movie_data)

        matched_movies = sorted(unique_movies, key=lambda x: x.get('title', '').lower())

        if not matched_movies:
            xbmcgui.Dialog().ok("No Results", f"No movies found for '{search_text}'")
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
            return

        paged_movies = matched_movies[start_index:end_index]

        for movie_data in paged_movies:
            title = movie_data.get('title', '')
            url = movie_data.get('url', '')

            if not title or not url:
                continue

            movie_details = movie_data.copy()
            tmdb_details = get_movie_details(title)

            if tmdb_details:
                movie_details.update(tmdb_details)

            display_title = title

            release_date = movie_details.get('release_date')
            year_val = movie_details.get('year')

            if release_date and len(release_date) >= 4:
                year_val = release_date.split('-')[0]

            if year_val:
                display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]"

            sources = all_sources_by_title.get(title.strip().lower(), [])

            has_4k_source = is_movie_4k(movie_details) or any(src.get('is_4k') for src in sources)

            if has_4k_source:
                display_title += " [COLOR FFD4AF37]4K[/COLOR]"

            if len(sources) > 1:
                display_title += " [COLORFFA9B2C3][Multi][/COLOR]"

            list_item = xbmcgui.ListItem(display_title)

            poster_path = movie_details.get('poster_path')
            backdrop_path = movie_details.get('backdrop_path')

            if poster_path:
                poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
                fanart_to_use = f"https://image.tmdb.org/t/p/original/{backdrop_path}" if backdrop_path else FANART_PATH

                list_item.setArt({
                    'thumb': poster_url,
                    'poster': poster_url,
                    'icon': poster_url,
                    'fanart': fanart_to_use,
                    'landscape': fanart_to_use,
                    'banner': fanart_to_use
                })
            else:
                default_poster = os.path.join(ICONS_PATH, 'DefaultVideo.png')
                list_item.setArt({
                    'thumb': default_poster,
                    'poster': default_poster,
                    'icon': default_poster,
                    'fanart': FANART_PATH
                })

            video_info = list_item.getVideoInfoTag()
            clean_meta_title = movie_details.get('title', title)

            video_info.setTitle(clean_meta_title)
            video_info.setOriginalTitle(clean_meta_title)
            video_info.setSortTitle(clean_meta_title)
            video_info.setMediaType('movie')
            video_info.setPlot(movie_details.get('overview', ''))

            if release_date:
                try:
                    video_info.setPremiered(release_date)
                except Exception:
                    pass

                try:
                    video_info.setFirstAired(release_date)
                except Exception:
                    pass

            if year_val:
                try:
                    video_info.setYear(int(year_val))
                except Exception:
                    pass

            try:
                runtime_minutes = int(movie_details.get('runtime', 0) or 0)
                if runtime_minutes > 0:
                    video_info.setDuration(runtime_minutes * 60)
            except Exception:
                pass

            genres = movie_details.get('genres', [])
            if isinstance(genres, list) and genres:
                try:
                    video_info.setGenres(genres)
                except Exception:
                    pass

            try:
                video_info.setRating(float(movie_details.get('vote_average', 0)))
            except Exception:
                pass

            list_item.setProperty('IsPlayable', 'true')

            if len(sources) > 1:
                sources_json = urllib.parse.quote_plus(json.dumps(sources, ensure_ascii=False))
                play_url = f"{sys.argv[0]}?action=play_sources&title={urllib.parse.quote_plus(title)}&sources={sources_json}"
            else:
                play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"

            xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

        total_pages = (len(matched_movies) + items_per_page - 1) // items_per_page

        if page < total_pages:
            next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
            next_icon = os.path.join(ICONS_PATH, 'next.png')

            next_page_item.setArt({
                'icon': next_icon,
                'thumb': next_icon,
                'poster': next_icon,
                'fanart': FANART_PATH
            })

            next_url = (
                f"{sys.argv[0]}?action=gv_search_results"
                f"&q={urllib.parse.quote_plus(search_text)}"
                f"&page={page + 1}"
            )

            xbmcplugin.addDirectoryItem(
                addon_handle,
                next_url,
                next_page_item,
                isFolder=True
            )

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log(f"GoldenVault search error: {e}", level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        
def play_movie(title, url):
    """Pre-checks the stream link validity using a streaming GET request before sending to Kodi."""
    try:
        log(f"=== GOLDVAULT PLAYBACK VERIFICATION ===", level=xbmc.LOGINFO)
        log(f"Movie Target: {title}", level=xbmc.LOGINFO)
        log(f"Incoming URL: {url}", level=xbmc.LOGINFO)

        if not url:
            log("Playback halted: Incoming stream path is null.", level=xbmc.LOGERROR)
            raise Exception("Null URL execution bypass.")

        # Clean trailing spaces and normalize unquoted string components safely
        playable_url = urllib.parse.unquote_plus(url).strip()

        # Separator split to guarantee spaces are replaced inside paths without altering token params
        if '?' in playable_url:
            url_path, token_query = playable_url.split('?', 1)
            url_path = url_path.replace(" ", "%20")
            playable_url = f"{url_path}?{token_query}"
        else:
            playable_url = playable_url.replace(" ", "%20")

        # Compile connection properties for network headers
        headers = {
            "User-Agent": USER_AGENT,
            "Accept": "*/*",
            "Connection": "keep-alive"
        }
        header_string = urllib.parse.urlencode(headers)

        if "|" not in playable_url:
            final_kodi_path = f"{playable_url}|{header_string}"
        else:
            final_kodi_path = playable_url

        log(f"Resolved video path string: {final_kodi_path}", level=xbmc.LOGINFO)

        # Create the definitive item containing your video path
        list_item = xbmcgui.ListItem(title, path=final_kodi_path)
        list_item.setProperty("IsPlayable", "true")
        list_item.setContentLookup(False)

        # Build metadata elements for the Player OSD display
        tmdb_details = get_movie_details(title)
        if tmdb_details:
            poster_path = tmdb_details.get('poster_path')
            if poster_path:
                poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
                list_item.setArt({'thumb': poster_url, 'poster': poster_url, 'fanart': FANART_PATH})
            
            video_info = list_item.getVideoInfoTag()
            video_info.setTitle(tmdb_details.get('title', title))
            video_info.setPlot(tmdb_details.get('overview', ''))
            video_info.setMediaType('movie')
            if tmdb_details.get('release_date'):
                try:
                    video_info.setYear(int(tmdb_details.get('release_date').split('-')[0]))
                except:
                    pass
            list_item.setInfo('video', video_info)

        # Isolate true file extensions by avoiding token strings
        clean_extension_check = playable_url.split("?")[0].lower()

        if clean_extension_check.endswith(".mp4"):
            list_item.setMimeType("video/mp4")
        elif clean_extension_check.endswith(".mkv"):
            list_item.setMimeType("video/x-matroska")
        elif clean_extension_check.endswith(".m3u8"):
            list_item.setMimeType("application/vnd.apple.mpegurl")
        else:
            list_item.setMimeType("video/*")

        # PRE-CHECK: FORCED GET STREAM CHECK
        try:
            # Using GET with stream=True looks at the real file status without downloading data
            response_check = requests.get(playable_url, headers=headers, stream=True, timeout=5)
            
            # If the server responds with a 404 or any error code, break immediately inside Python!
            if response_check.status_code >= 400:
                raise Exception(f"Server returned failure status: {response_check.status_code}")
                
            # Cleanly close the stream connection before giving it to Kodi
            response_check.close()
            
        except Exception as network_error:
            log(f"Pre-check confirmed dead link: {network_error}", level=xbmc.LOGWARNING)
            raise Exception("Link failed verification.")

        # If everything passes, hand over to Kodi safely
        log("Link verified successfully! Launching core player context...", level=xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(addon_handle, True, list_item)

    except Exception as e:
        log(f"Playback intercepted by custom error handler: {e}", level=xbmc.LOGERROR)
        
        # Kill Kodi's default loading sequence so the native error popup window never triggers
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        # ============================================================
        title_color      = "FFD4AF37"  # Golden title
        accent_color     = "FFD4AF37"  # Golden headers
        version_text     = "FFB8B8B8"  # Soft gray
        desc_text_color  = "FFFFFFFF"  # White text
        # ============================================================
        # --- SMART ERROR DEBUG ENGAGED ---
        try:
            addon = xbmcaddon.Addon()
            current_version = addon.getAddonInfo("version")
            
            r = requests.get(REMOTE_ADDONS_XML, timeout=4)
            if r.status_code == 200:
                match = re.search(
                    r'<addon\s+id="' + re.escape(addon_id) + r'"[^>]*version="([^"]+)"',
                    r.text
                )
                
                if match:
                    remote_version = match.group(1)
                    
                    # CASE A: User is on an OLD version
                    if version_tuple(current_version) < version_tuple(remote_version):
                        message = (
                            f"[B][COLOR {accent_color}]New addon update available: v{remote_version}[/COLOR][/B]\n"
                            f"[B][COLOR {version_text}]Current version: v{current_version}[/COLOR][/B]\n\n"
                            f"[COLOR {desc_text_color}]Stream Failed To Load. Some movie streams may occasionally change over time.[/COLOR]\n"
                            f"[COLOR {desc_text_color}]Please try again later or select a different stream while links refresh.[/COLOR]"
                        )

                        xbmcgui.Dialog().ok(
                            f"[B][COLOR {title_color}]GoldenVault Notice[/COLOR][/B]",
                            message
                        )

                        return
            
                    # CASE B: User is on the LATEST version
                    else:
                        
                        message = (
                            f"[B][COLOR {accent_color}]Stream Failed To Load[/COLOR][/B]\n\n"
                            f"[COLOR {desc_text_color}]Some movie streams may occasionally change or become unavailable over time.[/COLOR]\n"
                            f"[COLOR {desc_text_color}]Please try again later or select a different stream while links refresh.[/COLOR]"
                        )

                        xbmcgui.Dialog().ok(
                            f"[B][COLOR {title_color}]GoldenVault Notice[/COLOR][/B]",
                            message
                        )
        
        except Exception as debug_error:
            log(f"Debug helper failed: {debug_error}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Playback Error", "The movie list is updating.\nPlease try again later.")
            
def version_tuple(v):
    """Helper function to compare version strings accurately."""
    try:
        return tuple(map(int, (v.split("."))))
    except Exception:
        return (0, 0, 0)

def check_update_popup():
    """Checks GitHub for an update and opens it in the native Kodi dialog skin."""
    try:
        addon = xbmcaddon.Addon()
        current_version = addon.getAddonInfo("version")
        addon_id = 'plugin.video.GoldenVault'

        r = requests.get(REMOTE_ADDONS_XML, timeout=10)
        if r.status_code != 200:
            return

        match = re.search(
            r'<addon\s+id="' + re.escape(addon_id) + r'"[^>]*version="([^"]+)"',
            r.text
        )

        if not match:
            return

        remote_version = match.group(1)

        if version_tuple(remote_version) <= version_tuple(current_version):
            return

        # 'DialogTextViewer.xml' uses the native Kodi text viewer layout
        dialog = ElegantUpdateDialog('DialogTextViewer.xml', addon.getAddonInfo('path'), 'Default', 
                                    current_ver=current_version, remote_ver=remote_version)
        dialog.doModal()

    except Exception as e:
        log(f"Update notifier error: {e}", level=xbmc.LOGERROR)


def check_update_popup():
    """Checks GitHub for an update and notifies the user with an easily customizable native OK dialog."""
    try:
        addon = xbmcaddon.Addon()
        current_version = addon.getAddonInfo("version")
        addon_id = 'plugin.video.GoldenVault'  

        r = requests.get(REMOTE_ADDONS_XML, timeout=10)
        if r.status_code != 200:
            return

        match = re.search(
            r'<addon\s+id="' + re.escape(addon_id) + r'"[^>]*version="([^"]+)"',
            r.text
        )

        if not match:
            return

        remote_version = match.group(1)

        # Exit silently if the local version is already up to date
        if version_tuple(remote_version) <= version_tuple(current_version):
            return

        title_color      = "FFD4AF37"  # Title header color (Gold)
        latest_ver_color = "FFD4AF37"  # 'Latest Version' line color (Gold)
        your_ver_color   = "FFB8B8B8"  # 'Your Installed Version' line color (Gold)
        desc_text_color  = "FFFFFFFF"  # Bottom message description color (White)
        
        # Everything is fully bolded and uses your custom color keys
        message = (
            f"[B][COLOR {latest_ver_color}]Latest Version Available: v{remote_version}[/COLOR][/B]\n"
            f"[B][COLOR {your_ver_color}]Your Installed Version: v{current_version}[/COLOR][/B]\n\n"
            f"[COLOR {desc_text_color}]Please Update GoldenVault from the Repository to enjoy[/COLOR]\n"
            f"[COLOR {desc_text_color}]The latest Features And Performance Improvements.[/COLOR]"
        )

        # Native OK Box layout using the custom title color key
        xbmcgui.Dialog().ok(
            f"[B][COLOR {title_color}]GoldVault Update[/COLOR][/B]",
            message
        )

    except Exception as e:
        log(f"Update notifier error: {e}", level=xbmc.LOGERROR)