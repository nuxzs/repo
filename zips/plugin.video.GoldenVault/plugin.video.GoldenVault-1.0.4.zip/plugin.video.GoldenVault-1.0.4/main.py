import sys
import os

ADDON_ROOT = os.path.dirname(__file__)
LIB_PATH = os.path.join(ADDON_ROOT, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from movies import *

if __name__ == '__main__':
    params = get_params()
    action = params.get('action')

    log(f"Main Router: Action received: {action}, Params: {params}", level=xbmc.LOGINFO)

    if action == 'play':
        title = params.get('title', '')
        url = params.get('url', '')

        if title and url:
            play_movie(title, url)
            sys.exit()
        else:
            xbmcgui.Dialog().notification(
                "Error",
                "Title or URL is missing for movie playback.",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.endOfDirectory(addon_handle)

    elif action is None:
        check_update_popup()
        
        movies_folder_item = xbmcgui.ListItem('[COLOR white]One[/COLOR][COLOR FFD4AF37]Click Movies[/COLOR]')
        movies_folder_item.setArt({
            'icon': os.path.join(ICONS_PATH, 'movie.png'),
            'fanart': FANART_PATH
        })

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=show_movies",
            movies_folder_item,
            isFolder=True
        )

        xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'show_movies':
        all_movies_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]All Movies[/COLOR]')
        all_movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'allmovie.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_movies&page=1", all_movies_folder_item, isFolder=True)

        fourk_movies_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]4K Movies[/COLOR]')
        fourk_movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, '4k.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_4k_movies&page=1", fourk_movies_folder_item, isFolder=True)

        categories_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]Categories[/COLOR]')
        categories_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_categories&page=1", categories_folder_item, isFolder=True)

        # --- UPDATED: Points to the clean Search Sub-Menu layout ---
        search_item = xbmcgui.ListItem('[COLOR FFD4AF37]Search[/COLOR]')
        search_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
        # CHANGED HERE: Points to the clean history menu layout panel first
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=gv_search_menu", search_item, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)
        
        xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_movies':
        movie_titles = read_movie_list(file_path)
        genre = params.get('genre')
        category = params.get('category')
        page = int(params.get('page', 1))
        list_movies(movie_titles, genre, page, category)

    elif action == 'list_years':
        page = int(params.get('page', 1))
        list_years(page)
   
    elif action == 'list_movies_by_year':
        year = params.get('year')
        page = int(params.get('page', 1))
        if year:
            list_movies_by_year(year, page)
        else:
            xbmcgui.Dialog().notification("Error", "No year specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_genres':
        page = int(params.get('page', 1))
        list_genres(page)

    elif action == 'list_categories':
        page = int(params.get('page', 1))
        list_categories(page)

    elif action == 'list_movies_by_category':
        category = params.get('category')
        page = int(params.get('page', 1))
        if category:
            list_movies_by_category(category, page)
        else:
            xbmcgui.Dialog().notification("Error", "No category specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_movies_by_genre':
        genre = params.get('genre')
        page = int(params.get('page', 1))
        if genre:
            list_movies_by_genre(genre, page)
        else:
            xbmcgui.Dialog().notification("Error", "No genre specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_4k_movies':
        page = int(params.get('page', 1))
        list_4k_movies(page)
        
    elif action == 'list_search_menu':
        list_search_menu()
        
    elif action == 'gv_search_menu':
        gv_search_menu()
     
    elif action == 'gv_clear_history':
        clear_search_history()
     
    elif action == 'gv_search_keyboard':
        gv_search_keyboard()
        # CRITICAL: Instantly shuts down the background script thread 
        # This blocks Kodi's media player engine from throwing a playback error!
        
    elif action == 'gv_go_back':
        # Instantly executes the native back skin action
        xbmc.executebuiltin("Action(Back)")
        # Cleanly shut down the directory listing handle so Kodi doesn't wait for a response
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

    elif action == 'gv_search_results':
        search_text = params.get('q', '')
        page = int(params.get('page', 1))
        gv_search_results(search_text, page)

    elif action == 'play_sources':
        title = params.get('title', '')
        sources = params.get('sources', '')

        if title and sources:
            play_movie_sources(title, sources)
            sys.exit()
        else:
            xbmcgui.Dialog().notification(
                "Error",
                "Missing source list.",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.endOfDirectory(addon_handle)
        
    else:
        log(f"Main Router: Unhandled action or initial entry point. Action: '{action}'", level=xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(addon_handle) 