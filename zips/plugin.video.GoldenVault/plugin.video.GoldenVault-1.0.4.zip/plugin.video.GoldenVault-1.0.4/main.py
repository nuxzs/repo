import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import urllib.parse
import requests
import sys
import os
import re
import json  # Import the json module
# import tv_functions
import time
import threading # Import threading for search

# Addon info
addon_handle = int(sys.argv[1])
addon_id = 'plugin.video.GoldenVault'  # Change this to your addon's ID

# Configuration options
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
EXTRA_HEADERS = {}
PROXY = None

# Write your TMDB key only once here. Kodi settings can override it if you add a tmdb_api_key setting later.
DEFAULT_TMDB_API_KEY = 'f0bbe0dc0bd0742a6ff38a7d6106f128' 

def get_tmdb_api_key():
    """Gets the TMDB API key from addon settings or uses the single fallback above."""
    try:
        addon = xbmcaddon.Addon()
        setting_key = addon.getSetting('tmdb_api_key')
        return setting_key or DEFAULT_TMDB_API_KEY
    except Exception as e:
        print(f"Error getting TMDB API key: {e}")
        return DEFAULT_TMDB_API_KEY

TMDB_API_KEY = get_tmdb_api_key()
# Path to your text file.  Make sure this is correct!
# UPDATED: GENRES_FILE_PATH to point to the 'resources' folder
file_path = os.path.join(os.path.dirname(__file__), 'resources', 'movie_list.json')
# Path to the icons folder
ICONS_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'images', 'icons')
FANART_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'images', 'fanart.jpg') #added fanart path
# Declare the cache variable globally and initialize it


def log(message, level=xbmc.LOGINFO):
    """Logs messages to the Kodi log file."""
    xbmc.log(f'[{addon_id}] {message}', level=level)

def read_movie_list(file_path):
    """Reads movie titles and URLs from a JSON file."""
    movie_titles = {} # This will store {title: full_movie_dict}
    try:
        log(f"Reading movie list from: {file_path}", level=xbmc.LOGDEBUG)
        with open(file_path, 'r', encoding='utf-8') as f:
            movie_data = json.load(f)  # Load the entire JSON structure

        if "movies" in movie_data:
            for movie in movie_data["movies"]:
                if "title" in movie and "url" in movie:
                    # Store the entire movie dictionary, including 'is_4k'
                    movie_titles[movie["title"]] = movie
                    log(f"Found movie: Title: {movie['title']}, URL: {movie['url']}, is_4k: {movie.get('is_4k', False)}", level=xbmc.LOGDEBUG)
                else:
                    log(f"Skipping movie with missing title or URL: {movie}", level=xbmc.LOGWARNING)
        else:
            log(f"Warning: 'movies' key not found in JSON file: {file_path}", level=xbmc.LOGWARNING)

    except FileNotFoundError:
        error_message = f"File not found. Check path:"
        log(error_message, level=xbmc.LOGERROR)
        return {}
    except json.JSONDecodeError:
        error_message = f"Error decoding JSON.  Invalid JSON format: {file_path}"
        log(error_message, level=xbmc.LOGERROR)
        return {}
    except Exception as e:
        error_message = f"Error reading file: {e}"
        log(error_message, level=xbmc.LOGERROR)
        return {}
    log(f"Read {len(movie_titles)} movies from file.", level=xbmc.LOGDEBUG)
    return movie_titles


def get_movie_details(title):
    """Fetches movie details from TMDB using the title."""
    if not TMDB_API_KEY:
        log("TMDB API key is missing.  Please configure it in the addon settings.", level=xbmc.LOGERROR)
        return {}

    search_url = f"https://api.themoviedb.org/3/search/movie?api_key={TMDB_API_KEY}&query={urllib.parse.quote_plus(title)}"
    try:
        start_time = time.time()
        log(f"Fetching TMDB search url: {search_url}", level=xbmc.LOGDEBUG) #DEBUG
        response = requests.get(search_url)
        response.raise_for_status()  # Raise an exception for bad status codes
        end_time = time.time()
        log(f"TMDB search response status: {response.status_code}, time taken: {end_time - start_time:.2f} seconds", level=xbmc.LOGDEBUG) #DEBUG
        data = response.json()
        log(f"TMDB search response data: {data}", level=xbmc.LOGDEBUG) #DEBUG

        if data and data['results']:
            movie_id = data['results'][0]['id']
            details_url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key={TMDB_API_KEY}"
            start_time = time.time()
            log(f"Fetching TMDB details url: {details_url}", level=xbmc.LOGDEBUG) #DEBUG
            details_response = requests.get(details_url)
            details_response.raise_for_status()
            end_time = time.time()
            log(f"TMDB details response status: {details_response.status_code}, time taken: {end_time - start_time:.2f} seconds", level=xbmc.LOGDEBUG) #DEBUG
            movie_details = details_response.json()
            log(f"TMDB details response data: {movie_details}", level=xbmc.LOGDEBUG) #DEBUG
            return movie_details
        else:
            log(f"Movie not found on TMDB: {title}", level=xbmc.LOGWARNING)
            return {}

    except requests.exceptions.RequestException as e:
        log(f"TMDB API error: {e}", level=xbmc.LOGERROR)
        return None
    except json.JSONDecodeError:
        log("Error decoding JSON from TMDB API", level=xbmc.LOGERROR)
        return None
    except KeyError as e:
        log(f"KeyError: {e}.  Check the TMDB API response format.", level=xbmc.LOGERROR)
        return None
    except Exception as e:
        log(f"An unexpected error occurred: {e}", level=xbmc.LOGERROR)
        return None
    
def get_movie_category(movie_data):
    """Returns the category/group from movie_list.json."""
    category = (
        movie_data.get('category')
        or movie_data.get('group-title')
        or movie_data.get('group_title')
        or movie_data.get('group')
        or 'Other'
    )
    category = str(category).strip()
    return category if category else 'Other'

def is_movie_4k(movie_details):
    """Determines if a movie is 4K based on the 'is_4k' field."""
    return movie_details.get('is_4k', False)

def list_movies(movie_titles, genre=None, page=1, category=None):
    """Lists the movies in Kodi with pagination and optional genre/category filtering."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page

    all_local_movies_data = sorted(movie_titles.values(), key=lambda x: x.get('title', '').lower())

    filtered_movies = all_local_movies_data

    if genre:
        temp_filtered = []
        for movie_data in filtered_movies:
            movie_genres = movie_data.get('genres', [])
            if isinstance(movie_genres, list):
                if genre.lower() in [g.lower() for g in movie_genres if isinstance(g, str)]:
                    temp_filtered.append(movie_data)
        filtered_movies = temp_filtered

    if category:
        category_lower = category.lower()
        filtered_movies = [
            movie_data for movie_data in filtered_movies
            if get_movie_category(movie_data).lower() == category_lower
        ]

    total_movies_for_pagination = len(filtered_movies)
    paged_local_movies_slice = filtered_movies[start_index:end_index]

    movies_to_display = []
    for movie_data in paged_local_movies_slice:
        title = movie_data.get('title')
        url = movie_data.get('url')

        if not title or not url:
            log(f"Skipping malformed movie entry in local list: {movie_data}", level=xbmc.LOGWARNING)
            continue

        tmdb_details = get_movie_details(title)

        movie_details_for_display = movie_data.copy()
        if tmdb_details:
            movie_details_for_display.update(tmdb_details)

        movies_to_display.append((title, url, movie_details_for_display))

    for title, url, movie_details in movies_to_display:
        display_title = title

        release_date = movie_details.get('release_date')
        year_val = movie_details.get('year')

        if release_date and len(release_date) >= 4:
            year_val = release_date.split('-')[0]

        if year_val:
            display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]"

        if is_movie_4k(movie_details):
            display_title += " [COLOR FFD4AF37]4K[/COLOR]"

        list_item = xbmcgui.ListItem(display_title)

        poster_path = movie_details.get('poster_path')
        backdrop_path = movie_details.get('backdrop_path')

        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            fanart_to_use = f"https://image.tmdb.org/t/p/original/{backdrop_path}" if backdrop_path else FANART_PATH
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'banner': poster_url,
                'clearart': poster_url,
                'clearlogo': poster_url,
                'landscape': poster_url,
                'fanart': fanart_to_use
            })
        else:
            default_poster_path = os.path.join(ICONS_PATH, 'DefaultVideo.png')
            list_item.setArt({
                'thumb': default_poster_path,
                'poster': default_poster_path,
                'fanart': FANART_PATH
            })

        video_info = list_item.getVideoInfoTag()
        video_info.setPlot(movie_details.get('overview', ''))

        try:
            if release_date and len(release_date) >= 4:
                video_info.setYear(int(release_date.split('-')[0]))
            elif movie_details.get('year'):
                video_info.setYear(int(movie_details.get('year')))
        except Exception:
            pass

        try:
            video_info.setRating(float(movie_details.get('vote_average', 0)))
        except Exception:
            pass

        raw_genres = movie_details.get('genres', [])
        genres = []
        if isinstance(raw_genres, list):
            for g in raw_genres:
                if isinstance(g, dict) and 'name' in g:
                    genres.append(g['name'])
                elif isinstance(g, str):
                    genres.append(g)

        video_info.setGenres(genres)
        video_info.setTitle(movie_details.get('title', title))
        video_info.setMediaType('movie')

        runtime_minutes = movie_details.get('runtime', 0)
        try:
            video_info.setDuration(int(runtime_minutes) * 60 if runtime_minutes else 0)
        except Exception:
            pass

        list_item.setInfo('video', video_info)

        plot = movie_details.get('overview', '')
        genre_str = ", ".join(genres)
        list_item.setProperty('genre', genre_str)
        list_item.setProperty('plot', plot)
        list_item.setProperty('is_4k', 'true' if movie_details.get('is_4k', False) else 'false')
        list_item.setProperty('category', get_movie_category(movie_details))
        
        # FIX: Explicitly notify Kodi core this selection executes dynamic link resolution
        list_item.setProperty('IsPlayable', 'true')

        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_movies_for_pagination + items_per_page - 1) // items_per_page

    if page > 1:
        prev_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Previous Page >>[/COLOR]")
        prev_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'previous.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies&genre={urllib.parse.quote_plus(str(genre) if genre else '')}&category={urllib.parse.quote_plus(str(category) if category else '')}&page={page - 1}",
            prev_page_item,
            isFolder=True,
        )

    if page < total_pages:
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies&genre={urllib.parse.quote_plus(str(genre) if genre else '')}&category={urllib.parse.quote_plus(str(category) if category else '')}&page={page + 1}",
            next_page_item,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(addon_handle)

def list_movies_by_genre(genre, page=1):
    """Lists movies belonging to a specific genre with pagination."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    all_movies_data = read_movie_list(file_path)
    filtered_movies_by_genre = []

    for movie_data in all_movies_data.values():
        movie_genres = movie_data.get('genres', [])
        if isinstance(movie_genres, list):
            if genre.lower() in [g.lower() for g in movie_genres if isinstance(g, str)]:
                filtered_movies_by_genre.append(movie_data)

    sorted_movies = sorted(filtered_movies_by_genre, key=lambda x: x.get('title', '').lower())
    total_movies_in_genre = len(sorted_movies)
    paged_movies_slice = sorted_movies[start_index:start_index + items_per_page]

    for movie_data in paged_movies_slice:
        title = movie_data.get('title')
        url = movie_data.get('url')

        if not title or not url:
            continue

        tmdb_details = get_movie_details(title)

        movie_details = movie_data.copy()
        if tmdb_details:
            movie_details.update(tmdb_details)

        display_title = title

        year_val = movie_details.get('year')
        release_date = movie_details.get('release_date')
        if release_date and len(release_date) >= 4:
            year_val = release_date.split('-')[0]

        if year_val:
            display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]"

        if movie_details.get('is_4k', False):
            display_title += " [COLOR FFD4AF37]4K[/COLOR]"

        list_item = xbmcgui.ListItem(display_title)

        poster_path = movie_details.get('poster_path')
        backdrop_path = movie_details.get('backdrop_path')

        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            fanart_to_use = f"https://image.tmdb.org/t/p/original/{backdrop_path}" if backdrop_path else FANART_PATH
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'banner': poster_url,
                'clearart': poster_url,
                'clearlogo': poster_url,
                'landscape': poster_url,
                'fanart': fanart_to_use
            })
        else:
            list_item.setArt({
                'thumb': os.path.join(ICONS_PATH, 'DefaultVideo.png'),
                'poster': os.path.join(ICONS_PATH, 'DefaultVideo.png'),
                'fanart': FANART_PATH
            })

        video_info = list_item.getVideoInfoTag()
        video_info.setTitle(movie_details.get('title', title))
        video_info.setMediaType('movie')
        video_info.setPlot(movie_details.get('overview', ''))

        try:
            if release_date and len(release_date) >= 4:
                video_info.setYear(int(release_date.split('-')[0]))
            elif movie_details.get('year'):
                video_info.setYear(int(movie_details.get('year')))
        except Exception:
            pass

        try:
            video_info.setRating(float(movie_details.get('vote_average', 0)))
        except Exception:
            pass

        raw_genres = movie_details.get('genres', [])
        genres = []
        if isinstance(raw_genres, list):
            for g in raw_genres:
                if isinstance(g, dict) and 'name' in g:
                    genres.append(g['name'])
                elif isinstance(g, str):
                    genres.append(g)

        video_info.setGenres(genres)
        runtime_minutes = movie_details.get('runtime', 0)
        try:
            video_info.setDuration(int(runtime_minutes) * 60 if runtime_minutes else 0)
        except Exception:
            pass

        list_item.setInfo('video', video_info)
        list_item.setProperty('genre', ", ".join(genres))
        list_item.setProperty('plot', movie_details.get('overview', ''))
        list_item.setProperty('is_4k', 'true' if movie_details.get('is_4k', False) else 'false')
        
        # FIX: Explicitly notify Kodi core this selection executes dynamic link resolution
        list_item.setProperty('IsPlayable', 'true')

        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_movies_in_genre + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_movies_by_genre&genre={urllib.parse.quote_plus(genre)}&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_genres(page=1):
    """Lists available movie genres with pagination, reading from movie_list.json."""
    xbmcplugin.setContent(addon_handle, 'genres')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    all_movies_data = read_movie_list(file_path)

    unique_genres = set()
    for movie_data in all_movies_data.values():
        genres = movie_data.get('genres', [])
        if isinstance(genres, list):
            for genre_name in genres:
                if genre_name and isinstance(genre_name, str):
                    unique_genres.add(genre_name)

    sorted_genres = sorted(list(unique_genres), key=str.lower)
    total_genres = len(sorted_genres)

    paged_genres_slice = sorted_genres[start_index:start_index + items_per_page]

    for genre in paged_genres_slice:
        list_item = xbmcgui.ListItem(f"[COLOR FFD4AF37]{genre}[/COLOR]")

        icon_name = f"genre_{genre.lower().replace(' ', '_')}.png"
        genre_icon_path = os.path.join(ICONS_PATH, icon_name)

        if os.path.exists(genre_icon_path):
            icon_to_use = genre_icon_path
        else:
            icon_to_use = os.path.join(ICONS_PATH, 'DefaultFolder.png')

        list_item.setArt({'icon': icon_to_use, 'fanart': FANART_PATH})

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies_by_genre&genre={urllib.parse.quote_plus(genre)}&page=1",
            list_item,
            isFolder=True
        )

    total_pages = (total_genres + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_genres&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_categories(page=1):
    """Lists categories from the 'category' field in movie_list.json."""
    xbmcplugin.setContent(addon_handle, 'files')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    all_movies_data = read_movie_list(file_path)

    unique_categories = set()
    for movie_data in all_movies_data.values():
        unique_categories.add(get_movie_category(movie_data))

    sorted_categories = sorted(list(unique_categories), key=str.lower)
    total_categories = len(sorted_categories)
    paged_categories_slice = sorted_categories[start_index:start_index + items_per_page]

    for category in paged_categories_slice:
        count = sum(1 for movie_data in all_movies_data.values() if get_movie_category(movie_data).lower() == category.lower())
        list_item = xbmcgui.ListItem(f"[COLOR FFD4AF37]{category}[/COLOR] [COLOR grey]({count})[/COLOR]")
        list_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies_by_category&category={urllib.parse.quote_plus(category)}&page=1",
            list_item,
            isFolder=True
        )

    total_pages = (total_categories + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_categories&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_movies_by_category(category, page=1):
    """Lists movies/series for a specific category from movie_list.json."""
    movie_titles = read_movie_list(file_path)
    list_movies(movie_titles, genre=None, page=page, category=category)

def list_4k_movies(page=1):
    """Lists only 4K movies in Kodi with pagination."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page

    log(f"list_4k_movies: Calling read_movie_list from {file_path}", level=xbmc.LOGDEBUG)
    all_movies_from_file = read_movie_list(file_path)
    
    filtered_4k_movies_titles = []
    for title, movie_data in all_movies_from_file.items():
        if is_movie_4k(movie_data):
            filtered_4k_movies_titles.append(title)
    
    filtered_4k_movies_titles.sort()
    total_4k_movies = len(filtered_4k_movies_titles)
    paged_4k_movie_titles_slice = filtered_4k_movies_titles[start_index:end_index]

    for title in paged_4k_movie_titles_slice:
        tmdb_details = get_movie_details(title)
        
        movie_details = all_movies_from_file.get(title, {}).copy()
        if tmdb_details:
            movie_details.update(tmdb_details)

        if not movie_details:
            continue
        display_title = title
        release_date = movie_details.get('release_date')
        if release_date and len(release_date) >= 4:
            year = release_date.split('-')[0]
            display_title = f"{display_title} [COLOR grey]({year})[/COLOR]"
           
        display_title += " [COLOR FFD4AF37]4K[/COLOR]"    
        list_item = xbmcgui.ListItem(display_title)

        poster_path = movie_details.get('poster_path')
        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'banner': poster_url,
                'clearart': poster_url,
                'clearlogo': poster_url,
                'landscape': poster_url,
            })
        else:
            default_poster_path = os.path.join(ICONS_PATH, 'DefaultVideo.png')
            list_item.setArt({'thumb': default_poster_path, 'poster': default_poster_path})

        video_info = list_item.getVideoInfoTag()
        video_info.setPlot(movie_details.get('overview', ''))
        video_info.setYear(int(movie_details.get('release_date', '').split('-')[0]) if movie_details.get('release_date') else 0)
        video_info.setRating(float(movie_details.get('vote_average', 0)))
        raw_genres = movie_details.get('genres', [])
        genres = []
        if isinstance(raw_genres, list):
            for g in raw_genres:
                if isinstance(g, dict) and 'name' in g:
                   genres.append(g['name'])
                elif isinstance(g, str):
                  genres.append(g)
        video_info.setGenres(genres)
        video_info.setTitle(movie_details.get('title', ''))
        video_info.setMediaType('movie')

        runtime_minutes = movie_details.get('runtime', 0)
        total_seconds = runtime_minutes * 60
        video_info.setDuration(total_seconds)

        list_item.setInfo('video', video_info)

        plot = movie_details.get('overview', '')
        genre_str = ", ".join(genres)
        list_item.setProperty('genre', genre_str)
        list_item.setProperty('plot', plot)
        
        # FIX: Explicitly notify Kodi core this selection executes dynamic link resolution
        list_item.setProperty('IsPlayable', 'true')

        url_from_file = all_movies_from_file.get(title, {}).get('url', '')
        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url_from_file)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_4k_movies + items_per_page - 1) // items_per_page
    
    if page > 1:
        prev_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Previous Page >>[/COLOR]")
        prev_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'previous.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_4k_movies&page={page - 1}",
            prev_page_item,
            isFolder=True,
        )

    if page < total_pages:
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_4k_movies&page={page + 1}",
            next_page_item,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(addon_handle)

def list_movies_by_year(year, page=1):
    """Lists movies for a specific year with pagination."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    try:
        requested_year_int = int(year)
    except ValueError:
        xbmcgui.Dialog().notification("Error", "Invalid year specified.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    all_movies_data = read_movie_list(file_path)
    filtered_movies = []

    for movie_data in all_movies_data.values():
        movie_year = movie_data.get('year')
        try:
            if movie_year is not None and int(movie_year) == requested_year_int:
                filtered_movies.append(movie_data)
        except (ValueError, TypeError):
            pass

    sorted_movies = sorted(filtered_movies, key=lambda x: x.get('title', '').lower())
    total_movies_in_year = len(sorted_movies)
    paged_movies_slice = sorted_movies[start_index:start_index + items_per_page]

    for movie_data in paged_movies_slice:
        title = movie_data.get('title')
        url = movie_data.get('url')

        if not title or not url:
            continue

        tmdb_details = get_movie_details(title)

        movie_details = movie_data.copy()
        if tmdb_details:
            movie_details.update(tmdb_details)

        display_title = title

        year_val = movie_details.get('year')
        release_date = movie_details.get('release_date')
        if release_date and len(release_date) >= 4:
            year_val = release_date.split('-')[0]

        if year_val:
            display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]"

        if movie_details.get('is_4k', False):
            display_title += " [COLOR FFD4AF37]4K[/COLOR]"

        list_item = xbmcgui.ListItem(display_title)

        poster_path = movie_details.get('poster_path')
        backdrop_path = movie_details.get('backdrop_path')

        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            fanart_to_use = f"https://image.tmdb.org/t/p/original/{backdrop_path}" if backdrop_path else FANART_PATH
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'banner': poster_url,
                'clearart': poster_url,
                'clearlogo': poster_url,
                'landscape': poster_url,
                'fanart': fanart_to_use
            })
        else:
            list_item.setArt({
                'thumb': os.path.join(ICONS_PATH, 'DefaultVideo.png'),
                'poster': os.path.join(ICONS_PATH, 'DefaultVideo.png'),
                'fanart': FANART_PATH
            })

        video_info = list_item.getVideoInfoTag()
        video_info.setTitle(movie_details.get('title', title))
        video_info.setMediaType('movie')
        video_info.setPlot(movie_details.get('overview', ''))

        try:
            if release_date and len(release_date) >= 4:
                video_info.setYear(int(release_date.split('-')[0]))
            elif movie_details.get('year'):
                video_info.setYear(int(movie_details.get('year')))
        except Exception:
            pass

        try:
            video_info.setRating(float(movie_details.get('vote_average', 0)))
        except Exception:
            pass

        raw_genres = movie_details.get('genres', [])
        genres = []
        if isinstance(raw_genres, list):
            for g in raw_genres:
                if isinstance(g, dict) and 'name' in g:
                    genres.append(g['name'])
                elif isinstance(g, str):
                    genres.append(g)

        video_info.setGenres(genres)
        runtime_minutes = movie_details.get('runtime', 0)
        try:
            video_info.setDuration(int(runtime_minutes) * 60 if runtime_minutes else 0)
        except Exception:
            pass

        list_item.setInfo('video', video_info)
        list_item.setProperty('genre', ", ".join(genres))
        list_item.setProperty('plot', movie_details.get('overview', ''))
        list_item.setProperty('is_4k', 'true' if movie_details.get('is_4k', False) else 'false')
        
        # FIX: Explicitly notify Kodi core this selection executes dynamic link resolution
        list_item.setProperty('IsPlayable', 'true')

        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_movies_in_year + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_movies_by_year&year={year}&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_years(page=1):
    """Lists all available movie release years from movie_list.json."""
    xbmcplugin.setContent(addon_handle, 'years')

    all_movies_data = read_movie_list(file_path)

    unique_years = set()
    for movie_data in all_movies_data.values():
        year = movie_data.get('year')
        if year is not None:
            try:
                unique_years.add(int(year))
            except (ValueError, TypeError):
                pass

    sorted_years = sorted(list(unique_years), reverse=True)

    for year_val in sorted_years:
        list_item = xbmcgui.ListItem(f"[COLOR FFD4AF37]{year_val}[/COLOR]")
        list_item.setArt({'icon': os.path.join(ICONS_PATH, 'years.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies_by_year&year={year_val}&page=1",
            list_item,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(addon_handle)

def get_params():
    paramstring = sys.argv[2]

    if paramstring.startswith('?'):
        paramstring = paramstring[1:]

    return dict(urllib.parse.parse_qsl(paramstring))

##search function 
def get_user_input():
    kb = xbmc.Keyboard('', 'Search for Movies', False)
    kb.doModal()
    
    if kb.isConfirmed():
        return kb.getText()
    else:
        return None

def list_search(search_term, dialog, page=1):
    try:
        xbmc.log(f"Listing search results for: {search_term} (with dialog), Page: {page}", level=xbmc.LOGINFO)

        items_per_page = 50
        start_index = (page - 1) * items_per_page

        movie_titles = read_movie_list(file_path)
        
        all_matched_movies_data = []
        for title, movie_data in movie_titles.items():
            if search_term.lower() in title.lower():
                all_matched_movies_data.append(movie_data)
        
        all_matched_movies_data = sorted(all_matched_movies_data, key=lambda x: x.get('title', ''))
        total_matched_movies = len(all_matched_movies_data)

        paged_matched_movies_slice = all_matched_movies_data[start_index : start_index + items_per_page]

        if not paged_matched_movies_slice and page == 1:
            dialog.close()
            xbmcgui.Dialog().notification("No Results", f"No movies found for '{search_term}'", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=show_movies)")
            return
        elif not paged_matched_movies_slice and page > 1:
            dialog.close()
            xbmcplugin.endOfDirectory(addon_handle)
            return
        
        xbmcplugin.setContent(addon_handle, 'movies')

        count = 0
        progress_step = 100 // len(paged_matched_movies_slice) if len(paged_matched_movies_slice) > 0 else 100

        for movie_data in paged_matched_movies_slice:
            if dialog.iscanceled():
                break

            title = movie_data.get('title')
            url = movie_data.get('url')

            tmdb_details = get_movie_details(title)
            movie_details_for_display = movie_data.copy()
            if tmdb_details:
                movie_details_for_display.update(tmdb_details)
            display_title = title
            release_date = movie_details_for_display.get('release_date')
            if release_date and len(release_date) >= 4:
                year = release_date.split('-')[0]
                display_title = f"{display_title} [COLOR grey]({year})[/COLOR]"

            if is_movie_4k(movie_details_for_display):
                display_title += " [COLOR FFD4AF37]4K[/COLOR]"

            list_item = xbmcgui.ListItem(display_title)

            if movie_details_for_display:
                poster_path = movie_details_for_display.get('poster_path')
                if poster_path:
                    poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
                    list_item.setArt({'thumb': poster_url, 'poster': poster_url})
                else:
                    default_poster_path = os.path.join(ICONS_PATH, 'DefaultVideo.png')
                    list_item.setArt({'thumb': default_poster_path, 'poster': default_poster_path})

                video_info = list_item.getVideoInfoTag()
                video_info.setPlot(movie_details_for_display.get('overview', ''))
                video_info.setYear(int(movie_details_for_display.get('release_date', '').split('-')[0]) if movie_details_for_display.get('release_date') else 0)
                video_info.setRating(float(movie_details_for_display.get('vote_average', 0)))
                raw_genres = movie_details_for_display.get('genres', [])
                genres = []
                if isinstance(raw_genres, list):
                     for g in raw_genres:
                         if isinstance(g, dict) and 'name' in g:
                             genres.append(g['name'])
                         elif isinstance(g, str):
                              genres.append(g)
                video_info.setGenres(genres)
                video_info.setTitle(movie_details_for_display.get('title', ''))
                video_info.setMediaType('movie')
                runtime_minutes = movie_details_for_display.get('runtime', 0)
                video_info.setDuration(int(runtime_minutes) * 60 if runtime_minutes else 0)

                list_item.setInfo('video', video_info)

            # FIX: Explicitly notify Kodi core this selection executes dynamic link resolution
            list_item.setProperty('IsPlayable', 'true')

            play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
            xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

            count += 1
            dialog.update(min(100, count * progress_step), message=f"Found {count}/{len(paged_matched_movies_slice)} on page {page}")

        dialog.close()

        total_pages = (total_matched_movies + items_per_page - 1) // items_per_page
        
        if page > 1:
            prev_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Previous Page >>[/COLOR]")
            prev_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'previous.png')})
            xbmcplugin.addDirectoryItem(
                addon_handle,
                f"{sys.argv[0]}?action=list_search&search_term={urllib.parse.quote_plus(search_term)}&page={page - 1}",
                prev_page_item,
                isFolder=True,
            )

        if page < total_pages:
            next_page_item = xbmcgui.ListItem("[COLOR FFD4AF37]Next Page >>[/COLOR]")
            next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
            xbmcplugin.addDirectoryItem(
                addon_handle,
                f"{sys.argv[0]}?action=list_search&search_term={urllib.parse.quote_plus(search_term)}&page={page + 1}",
                next_page_item,
                isFolder=True,
            )

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log(f"Error in list_search: {e}", level=xbmc.LOGERROR)
        dialog.close()
        xbmcplugin.endOfDirectory(addon_handle)

def play_movie(title, url):
    """Play movie URL in Kodi supporting queries and token handshakes."""
    try:
        log(f"=== GOLDVAULT PLAYBACK VERIFICATION ===", level=xbmc.LOGINFO)
        log(f"Movie Target: {title}", level=xbmc.LOGINFO)
        log(f"Incoming URL: {url}", level=xbmc.LOGINFO)

        if not url:
            log("Playback halted: Incoming stream path is null.", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Playback Error", "Empty stream link", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        # Clean trailing spaces and normalize unquoted string components safely
        playable_url = urllib.parse.unquote_plus(url).strip()

        # Separator split to guarantee spaces are replaced inside paths without altering token params
        if '?' in playable_url:
            url_path, token_query = playable_url.split('?', 1)
            url_path = url_path.replace(" ", "%20")
            playable_url = f"{url_path}?{token_query}"
        else:
            playable_url = playable_url.replace(" ", "%20")

        # Compile connection properties for network headers
        headers = {
            "User-Agent": USER_AGENT,
            "Accept": "*/*",
            "Connection": "keep-alive"
        }
        header_string = urllib.parse.urlencode(headers)

        if "|" not in playable_url:
            final_kodi_path = f"{playable_url}|{header_string}"
        else:
            final_kodi_path = playable_url

        log(f"Resolved video path string: {final_kodi_path}", level=xbmc.LOGINFO)

        # Create the definitive item containing your video path
        list_item = xbmcgui.ListItem(title, path=final_kodi_path)
        list_item.setProperty("IsPlayable", "true")
        list_item.setContentLookup(False)

        # Build metadata elements for the Player OSD display
        tmdb_details = get_movie_details(title)
        if tmdb_details:
            poster_path = tmdb_details.get('poster_path')
            if poster_path:
                poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
                list_item.setArt({'thumb': poster_url, 'poster': poster_url, 'fanart': FANART_PATH})
            
            video_info = list_item.getVideoInfoTag()
            video_info.setTitle(tmdb_details.get('title', title))
            video_info.setPlot(tmdb_details.get('overview', ''))
            video_info.setMediaType('movie')
            if tmdb_details.get('release_date'):
                try:
                    video_info.setYear(int(tmdb_details.get('release_date').split('-')[0]))
                except:
                    pass
            list_item.setInfo('video', video_info)

        # Isolate true file extensions by avoiding token strings
        clean_extension_check = playable_url.split("?")[0].lower()

        if clean_extension_check.endswith(".mp4"):
            list_item.setMimeType("video/mp4")
        elif clean_extension_check.endswith(".mkv"):
            list_item.setMimeType("video/x-matroska")
        elif clean_extension_check.endswith(".m3u8"):
            list_item.setMimeType("application/vnd.apple.mpegurl")
        else:
            list_item.setMimeType("video/*")

        log("Delivering True status resolution callback directly to Kodi core player.", level=xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(addon_handle, True, list_item)

    except Exception as e:
        log(f"Playback exception encountered: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Playback Error", f"Exception context: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())


if __name__ == '__main__':
    params = get_params()
    action = params.get('action')

    log(f"Main Router: Action received: {action}, Params: {params}", level=xbmc.LOGINFO)

    if action == 'play':
        title = params.get('title', '')
        url = params.get('url', '')

        if title and url:
            play_movie(title, url)
            sys.exit()
        else:
            xbmcgui.Dialog().notification(
                "Error",
                "Title or URL is missing for movie playback.",
                xbmcgui.NOTIFICATION_ERROR
            )
            xbmcplugin.endOfDirectory(addon_handle)

    elif action is None:
        movies_folder_item = xbmcgui.ListItem('[COLOR white]One[/COLOR][COLOR FFD4AF37]Click Movies[/COLOR]')
        movies_folder_item.setArt({
            'icon': os.path.join(ICONS_PATH, 'movie.png'),
            'fanart': FANART_PATH
        })

        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=show_movies",
            movies_folder_item,
            isFolder=True
        )

        xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'show_movies':
        all_movies_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]All Movies[/COLOR]')
        all_movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'allmovie.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_movies&page=1", all_movies_folder_item, isFolder=True)

        fourk_movies_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]4K Movies[/COLOR]')
        fourk_movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, '4k.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_4k_movies&page=1", fourk_movies_folder_item, isFolder=True)

        categories_folder_item = xbmcgui.ListItem('[COLOR FFD4AF37]Categories[/COLOR]')
        categories_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultFolder.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_categories&page=1", categories_folder_item, isFolder=True)

        search_item = xbmcgui.ListItem("[COLOR FFD4AF37]Search[/COLOR]")
        search_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=open_search", search_item, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_movies':
        movie_titles = read_movie_list(file_path)
        genre = params.get('genre')
        category = params.get('category')
        page = int(params.get('page', 1))
        list_movies(movie_titles, genre, page, category)

    elif action == 'list_years':
        page = int(params.get('page', 1))
        list_years(page)
   
    elif action == 'list_movies_by_year':
        year = params.get('year')
        page = int(params.get('page', 1))
        if year:
            list_movies_by_year(year, page)
        else:
            xbmcgui.Dialog().notification("Error", "No year specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_genres':
        page = int(params.get('page', 1))
        list_genres(page)

    elif action == 'list_categories':
        page = int(params.get('page', 1))
        list_categories(page)

    elif action == 'list_movies_by_category':
        category = params.get('category')
        page = int(params.get('page', 1))
        if category:
            list_movies_by_category(category, page)
        else:
            xbmcgui.Dialog().notification("Error", "No category specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_movies_by_genre':
        genre = params.get('genre')
        page = int(params.get('page', 1))
        if genre:
            list_movies_by_genre(genre, page)
        else:
            xbmcgui.Dialog().notification("Error", "No genre specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_4k_movies':
        page = int(params.get('page', 1))
        list_4k_movies(page)
        
    elif action == 'open_search':
       xbmc.log("Executing 'open_search' action.", level=xbmc.LOGINFO)
       search_term = get_user_input()
       if search_term:
        dialog = xbmcgui.DialogProgress()
        dialog.create("Searching...", f"Finding Movies for '{search_term}'...")
        thread = threading.Thread(target=list_search, args=(search_term, dialog, 1))
        thread.start()
       else:
           xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_search':
        search_term = params.get('search_term')
        page = int(params.get('page', 1))
        if search_term:
            dialog = xbmcgui.DialogProgress()
            dialog.create("Searching for Movies", f"Please wait while we find '{search_term}' (Page {page})...")
            thread = threading.Thread(target=list_search, args=(search_term, dialog, page))
            thread.start()
        else:
            xbmcgui.Dialog().notification("Error", "No search term specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)
            
    else:
        log(f"Main Router: Unhandled action or initial entry point. Action: '{action}'", level=xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(addon_handle)