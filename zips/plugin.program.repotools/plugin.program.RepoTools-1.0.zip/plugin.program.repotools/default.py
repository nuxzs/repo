import re
import os
import gzip
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon


ADDON = xbmcaddon.Addon()

TITLE = "[B][COLOR mediumpurple]CorpTeam Repo[/COLOR] [COLOR white]Tools[/COLOR][/B]"
ADDONS_PATH = xbmcvfs.translatePath("special://home/addons/")


CATEGORY_ORDER = [
    "Video add-ons",
    "Music add-ons",
    "Picture add-ons",
    "Program add-ons",
    "Services",
    "Repositories",
    "Skins",
    "Subtitles",
    "Context menus",
    "Script modules",
    "Libraries",
    "Other add-ons"
]


# ============================================================
# SETTINGS
# ============================================================

def get_setting_bool(setting_id, default=False):
    try:
        value = ADDON.getSetting(setting_id).lower()
        if value == "":
            return default
        return value == "true"
    except Exception:
        return default


def get_setting_int(setting_id, default=0):
    try:
        value = ADDON.getSetting(setting_id)
        if value == "":
            return default
        return int(value)
    except Exception:
        return default


def get_page_size():
    # settings.xml enum:
    # 0 = 10, 1 = 20, 2 = 30, 3 = 40, 4 = 50
    value = ADDON.getSetting("page_size")

    if value == "0":
        return 10
    if value == "1":
        return 20
    if value == "2":
        return 30
    if value == "3":
        return 40
    if value == "4":
        return 50

    return 20


def get_timeout():
    timeout = get_setting_int("health_check_timeout", 15)

    if timeout < 5:
        return 5

    if timeout > 60:
        return 60

    return timeout


def setting_show_installed():
    return get_setting_bool("show_installed", True)


def setting_video_only():
    return get_setting_bool("video_only", False)


def setting_enable_colors():
    return get_setting_bool("enable_colors", True)


def setting_compact_mode():
    return get_setting_bool("compact_mode", False)


def setting_show_health():
    return get_setting_bool("show_health", True)


def setting_show_video_status():
    return get_setting_bool("show_video_status", True)


def setting_show_category_counts():
    return get_setting_bool("show_category_counts", True)


def setting_show_repo_status():
    return get_setting_bool("show_repo_status", True)


def setting_close_after_install():
    return get_setting_bool("close_after_install", True)


def setting_confirm_before_install():
    return get_setting_bool("confirm_before_install", True)


def setting_gzip_support():
    return get_setting_bool("gzip_support", True)


def setting_show_failed_sources():
    return get_setting_bool("show_failed_sources", False)


def setting_hide_empty_repos():
    return get_setting_bool("hide_empty_repos", False)


def setting_check_metadata_quality():
    return get_setting_bool("check_metadata_quality", True)


def setting_search_name():
    return get_setting_bool("search_name", True)


def setting_search_id():
    return get_setting_bool("search_id", True)


def setting_search_description():
    return get_setting_bool("search_description", True)


def setting_search_summary():
    return get_setting_bool("search_summary", True)


# ============================================================
# UI HELPERS
# ============================================================

def c(text, color):
    if not setting_enable_colors():
        return text
    return f"[COLOR {color}]{text}[/COLOR]"


def b(text):
    return f"[B]{text}[/B]"


def clean_text(value):
    if value is None:
        return ""
    return str(value).strip()


def addon_is_installed(addon_id):
    if not addon_id:
        return False

    addon_path = os.path.join(ADDONS_PATH, addon_id)
    return os.path.exists(addon_path)


def make_search_text(addon):
    parts = []

    if setting_search_name():
        parts.append(addon.get("name", ""))

    if setting_search_id():
        parts.append(addon.get("id", ""))

    parts.append(addon.get("category", ""))

    if setting_search_summary():
        parts.append(addon.get("summary", ""))

    if setting_search_description():
        parts.append(addon.get("description", ""))

    return " ".join(parts).lower()


# ============================================================
# INSTALL
# ============================================================

def install_addon_and_close(addon):
    addon_id = addon["id"]
    addon_name = addon["name"]

    if addon_is_installed(addon_id):
        xbmcgui.Dialog().ok(
            TITLE,
            f"{addon_name}\n\nThis add-on is already installed."
        )
        return

    if setting_confirm_before_install():
        confirm = xbmcgui.Dialog().yesno(
            TITLE,
            f"Install this add-on?\n\n{addon_name}"
        )

        if not confirm:
            return

    try:
        xbmc.executebuiltin(f"InstallAddon({addon_id})")

        xbmcgui.Dialog().notification(
            "Repo Tools",
            f"Install started: {addon_name}",
            xbmcgui.NOTIFICATION_INFO,
            4000
        )

        if setting_close_after_install():
            raise SystemExit

    except SystemExit:
        raise

    except Exception as e:
        xbmc.log(f"[CorpTeam Repo Tools] Install error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            TITLE,
            "Kodi could not start the install."
        )


# ============================================================
# REPOSITORY SCAN
# ============================================================

def get_installed_repos():
    repos = []

    if not os.path.exists(ADDONS_PATH):
        return repos

    for folder in os.listdir(ADDONS_PATH):
        if not folder.startswith("repository."):
            continue

        addon_xml = os.path.join(ADDONS_PATH, folder, "addon.xml")

        repo_name = folder
        repo_id = folder
        repo_urls = []

        try:
            tree = ET.parse(addon_xml)
            root = tree.getroot()

            repo_name = clean_text(root.get("name")) or folder
            repo_id = clean_text(root.get("id")) or folder

            for ext in root.findall("extension"):
                if clean_text(ext.get("point")) == "xbmc.addon.repository":
                    for info in ext.findall(".//info"):
                        if info is not None and info.text:
                            url = clean_text(info.text)

                            if url and url not in repo_urls:
                                repo_urls.append(url)

        except Exception as e:
            xbmc.log(
                f"[CorpTeam Repo Tools] Repo read error {folder}: {e}",
                xbmc.LOGERROR
            )

        repos.append({
            "folder": folder,
            "id": repo_id,
            "name": repo_name,
            "urls": repo_urls
        })

    repos.sort(key=lambda x: x["name"].lower())
    return repos


def download_xml_to_memory(url):
    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Kodi CorpTeam Repo Tools"
            }
        )

        with urllib.request.urlopen(req, timeout=get_timeout()) as response:
            data = response.read()

        if setting_gzip_support():
            if url.lower().endswith(".gz") or data[:2] == b"\x1f\x8b":
                data = gzip.decompress(data)

        return data.decode("utf-8", errors="ignore"), None

    except Exception as e:
        xbmc.log(
            f"[CorpTeam Repo Tools] XML read error: {e}",
            xbmc.LOGERROR
        )
        return None, str(e)


# ============================================================
# ADDON PARSER
# ============================================================

def detect_category(addon):
    addon_id = clean_text(addon.get("id")).lower()

    if addon_id.startswith("skin."):
        return "Skins"

    if addon_id.startswith("script.module."):
        return "Script modules"

    if addon_id.startswith("repository."):
        return "Repositories"

    if addon_id.startswith("service."):
        return "Services"

    if addon_id.startswith("plugin.video."):
        return "Video add-ons"

    if addon_id.startswith("plugin.audio.") or addon_id.startswith("plugin.music."):
        return "Music add-ons"

    if addon_id.startswith("plugin.image.") or addon_id.startswith("plugin.picture."):
        return "Picture add-ons"

    for ext in addon.findall("extension"):
        point = clean_text(ext.get("point")).lower()

        if point == "xbmc.gui.skin":
            return "Skins"

        if point == "xbmc.python.module":
            return "Script modules"

        if point == "xbmc.addon.repository":
            return "Repositories"

        if point == "xbmc.service":
            return "Services"

        if point == "xbmc.subtitle.module":
            return "Subtitles"

        if point == "kodi.context.item":
            return "Context menus"

        if point == "xbmc.python.pluginsource":
            provides = ext.find("provides")
            provide_text = clean_text(
                provides.text if provides is not None else ""
            ).lower()

            if "video" in provide_text:
                return "Video add-ons"

            if "audio" in provide_text or "music" in provide_text:
                return "Music add-ons"

            if "image" in provide_text or "picture" in provide_text:
                return "Picture add-ons"

            return "Program add-ons"

        if point == "xbmc.python.script":
            return "Program add-ons"

    return "Other add-ons"


def read_metadata(addon):
    summary = ""
    description = ""

    metadata = addon.find("extension[@point='xbmc.addon.metadata']")

    if metadata is not None:
        for s in metadata.findall("summary"):
            if s.text:
                summary = clean_text(s.text)
                break

        for d in metadata.findall("description"):
            if d.text:
                description = clean_text(d.text)
                break

    return summary, description


def get_metadata_health(addon_id, addon_name, addon_version, category, summary, description):
    if not setting_check_metadata_quality():
        return "OK"

    score = 0

    if addon_id:
        score += 1

    if addon_name:
        score += 1

    if addon_version:
        score += 1

    if category != "Other add-ons":
        score += 1

    if summary or description:
        score += 1

    if score >= 5:
        return "GOOD"

    if score >= 3:
        return "OK"

    return "LIMITED"


def get_video_test_status(addon):
    if addon["category"] != "Video add-ons":
        return "Not video"

    if addon_is_installed(addon["id"]):
        return "Installed"

    if addon["health"] == "GOOD":
        return "Listed / likely OK"

    if addon["health"] == "OK":
        return "Listed / unknown"

    return "Weak metadata"


def parse_repo_xml(xml_text, repo):
    addons = []

    def parse_addon_node(addon):
        addon_id = clean_text(addon.get("id"))
        addon_name = clean_text(addon.get("name"))
        addon_version = clean_text(addon.get("version"))

        if not addon_id:
            return None

        category = detect_category(addon)
        summary, description = read_metadata(addon)

        if not addon_name:
            addon_name = addon_id

        health = get_metadata_health(
            addon_id,
            addon_name,
            addon_version,
            category,
            summary,
            description
        )

        item = {
            "id": addon_id,
            "name": addon_name,
            "version": addon_version,
            "category": category,
            "summary": summary,
            "description": description,
            "health": health,
            "installed": addon_is_installed(addon_id),
            "repo_name": repo["name"],
            "repo_id": repo["id"]
        }

        item["video_status"] = get_video_test_status(item)
        return item

    try:
        text = xml_text.strip()

        try:
            root = ET.fromstring(text)

            if root.tag == "addon":
                addon_nodes = [root]
            else:
                addon_nodes = root.findall(".//addon")

            for addon in addon_nodes:
                item = parse_addon_node(addon)
                if item:
                    addons.append(item)

        except Exception:
            # Fallback for big / messy addons.xml files.
            blocks = re.findall(
                r'<addon\b[^>]*>.*?</addon>',
                text,
                flags=re.DOTALL | re.IGNORECASE
            )

            for block in blocks:
                try:
                    addon = ET.fromstring(block)
                    item = parse_addon_node(addon)
                    if item:
                        addons.append(item)
                except Exception:
                    continue

            single_tags = re.findall(
                r'<addon\b[^>]*/>',
                text,
                flags=re.DOTALL | re.IGNORECASE
            )

            for tag in single_tags:
                try:
                    addon = ET.fromstring(tag)
                    item = parse_addon_node(addon)
                    if item:
                        addons.append(item)
                except Exception:
                    continue

    except Exception as e:
        xbmc.log(
            f"[CorpTeam Repo Tools] Parse error: {e}",
            xbmc.LOGERROR
        )

    return addons


def dedupe_addons(addons):
    unique = {}

    for addon in addons:
        key = addon["id"]

        if key not in unique:
            unique[key] = addon

    final_addons = list(unique.values())
    final_addons.sort(key=lambda x: x["name"].lower())

    return final_addons


def filter_addons_by_settings(addons):
    results = addons

    if not setting_show_installed():
        results = [a for a in results if not addon_is_installed(a["id"])]

    if setting_video_only():
        results = [a for a in results if a["category"] == "Video add-ons"]

    return results


def load_repo_addons_quiet(repo):
    if not repo["urls"]:
        return [], [f"{repo['name']} has no repository data source."]

    all_addons = []
    errors = []

    for url in repo["urls"]:
        xml_text, error = download_xml_to_memory(url)

        if not xml_text:
            errors.append("A repository source failed.")
            continue

        parsed = parse_repo_xml(xml_text, repo)
        all_addons.extend(parsed)

        del xml_text

    return dedupe_addons(all_addons), errors


def load_repo_addons_with_progress(repo):
    if not repo["urls"]:
        return [], [f"{repo['name']} has no repository data source."]

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, f"Loading {repo['name']}...")

    all_addons = []
    errors = []

    total = len(repo["urls"])

    for index, url in enumerate(repo["urls"]):
        if progress.iscanceled():
            break

        percent = int(((index + 1) / total) * 100)

        progress.update(
            percent,
            f"Reading repository data...\nSource {index + 1} of {total}"
        )

        xml_text, error = download_xml_to_memory(url)

        if not xml_text:
            errors.append("A repository source failed.")
            continue

        parsed = parse_repo_xml(xml_text, repo)
        all_addons.extend(parsed)

        del xml_text

    progress.close()

    return dedupe_addons(all_addons), errors


# ============================================================
# MENU / SEARCH
# ============================================================

def get_categories_from_addons(addons):
    found = {}

    for addon in addons:
        category = addon["category"]
        found[category] = found.get(category, 0) + 1

    ordered = []

    for category in CATEGORY_ORDER:
        if category in found:
            ordered.append((category, found[category]))

    for category, count in found.items():
        if category not in CATEGORY_ORDER:
            ordered.append((category, count))

    return ordered


def choose_repo():
    repos = get_installed_repos()

    if setting_hide_empty_repos():
        repos = [r for r in repos if r["urls"]]

    if not repos:
        xbmcgui.Dialog().ok(
            TITLE,
            "No installed repositories found."
        )
        return None

    labels = []

    for repo in repos:
        if repo["urls"]:
            labels.append(f"{c('●', 'lime')} {b(repo['name'])}")
        else:
            labels.append(
                f"{c('●', 'red')} {b(repo['name'])} {c('[No Data]', 'orange')}"
            )

    labels.append(c("← Back", "gray"))

    selected = xbmcgui.Dialog().select("Choose Repository", labels)

    if selected == -1 or selected == len(labels) - 1:
        return None

    return repos[selected]


def search_all_repositories():
    repos = get_installed_repos()

    if setting_hide_empty_repos():
        repos = [r for r in repos if r["urls"]]

    if not repos:
        xbmcgui.Dialog().ok(
            TITLE,
            "No installed repositories found."
        )
        return

    keyboard = xbmc.Keyboard("", "Search add-ons")
    keyboard.doModal()

    if not keyboard.isConfirmed():
        return

    query = keyboard.getText().strip()

    if not query:
        return

    q = query.lower()
    results = []

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Searching repositories...")

    total = len(repos)

    for index, repo in enumerate(repos):
        if progress.iscanceled():
            break

        percent = int(((index + 1) / total) * 100)

        progress.update(
            percent,
            f"Searching...\n{repo['name']}"
        )

        addons, errors = load_repo_addons_quiet(repo)

        for addon in addons:
            search_text = make_search_text(addon)

            if q in search_text:
                results.append(addon)

    progress.close()

    results = filter_addons_by_settings(results)

    if not results:
        xbmcgui.Dialog().ok(
            "No Results",
            f"No add-ons found for:\n\n{query}"
        )
        return

    results.sort(key=lambda x: (x["repo_name"].lower(), x["name"].lower()))
    show_paged_addon_results(results, f"Search Results: {query}")


def search_loaded_addons(addons, title):
    keyboard = xbmc.Keyboard("", "Search add-ons")
    keyboard.doModal()

    if not keyboard.isConfirmed():
        return

    query = keyboard.getText().strip()

    if not query:
        return

    q = query.lower()
    results = []

    for addon in addons:
        if q in make_search_text(addon):
            results.append(addon)

    results = filter_addons_by_settings(results)

    if not results:
        xbmcgui.Dialog().ok(
            "No Results",
            f"No add-ons found for:\n\n{query}"
        )
        return

    show_paged_addon_results(results, title)


def repo_browser():
    repo = choose_repo()

    if not repo:
        return

    addons, errors = load_repo_addons_with_progress(repo)

    if not addons:
        xbmcgui.Dialog().ok(
            "Repository Problem",
            f"{repo['name']}\n\n"
            "No add-on data was found.\n\n"
            "This repository may be offline, blocked, empty, or missing valid metadata."
        )
        return

    while True:
        categories = get_categories_from_addons(addons)

        labels = [
            c("🔎 Search in this repository", "cyan")
        ]

        for category, count in categories:
            if setting_show_category_counts():
                labels.append(
                    f"{c('■', 'gold')} {category} {c('[' + str(count) + ']', 'gray')}"
                )
            else:
                labels.append(f"{c('■', 'gold')} {category}")

        if setting_show_repo_status():
            labels.append(c("🛠 Repository status", "lightblue"))

        labels.append(c("← Back", "gray"))

        selected = xbmcgui.Dialog().select(repo["name"], labels)

        if selected == -1 or selected == len(labels) - 1:
            break

        if selected == 0:
            search_loaded_addons(addons, f"Search {repo['name']}")
            continue

        status_index = len(labels) - 2 if setting_show_repo_status() else -999

        if selected == status_index:
            show_repo_status_menu(repo, addons, errors)
            continue

        category_index = selected - 1

        if category_index < 0 or category_index >= len(categories):
            continue

        category_name = categories[category_index][0]
        category_addons = [
            a for a in addons if a["category"] == category_name
        ]

        category_addons = filter_addons_by_settings(category_addons)

        show_paged_addon_results(category_addons, category_name)


# ============================================================
# ADDON LIST / DETAILS
# ============================================================

def show_paged_addon_results(results, title):
    if not results:
        xbmcgui.Dialog().ok(
            TITLE,
            "No add-ons found."
        )
        return

    results.sort(key=lambda x: x["name"].lower())

    page = 0

    while True:
        page_size = get_page_size()
        total = len(results)
        start = page * page_size
        end = min(start + page_size, total)
        page_items = results[start:end]

        labels = []

        for addon in page_items:
            if addon_is_installed(addon["id"]):
                state = c("[Installed]", "lime")
            else:
                state = c("[Available]", "cyan")

            if addon["health"] == "GOOD":
                health = c("GOOD", "lime")
            elif addon["health"] == "OK":
                health = c("OK", "gold")
            else:
                health = c("LIMITED", "orange")

            if setting_compact_mode():
                labels.append(f"{b(addon['name'])} {state}")
                continue

            if addon["category"] == "Video add-ons" and setting_show_video_status():
                video_status = addon.get("video_status", "Unknown")

                if video_status == "Installed":
                    video = c("Installed", "lime")
                elif video_status == "Listed / likely OK":
                    video = c("Likely OK", "lime")
                elif video_status == "Listed / unknown":
                    video = c("Unknown", "gold")
                else:
                    video = c("Weak", "orange")

                if setting_show_health():
                    labels.append(
                        f"{b(addon['name'])} {state} {c('•', 'gray')} {health} {c('• Video:', 'gray')} {video}"
                    )
                else:
                    labels.append(
                        f"{b(addon['name'])} {state} {c('• Video:', 'gray')} {video}"
                    )

            else:
                if setting_show_health():
                    labels.append(
                        f"{b(addon['name'])} {state} {c('•', 'gray')} {health}"
                    )
                else:
                    labels.append(
                        f"{b(addon['name'])} {state}"
                    )

        if end < total:
            labels.append(c("Next Page →", "cyan"))

        if page > 0:
            labels.append(c("← Previous Page", "cyan"))

        labels.append(c("← Back", "gray"))

        selected = xbmcgui.Dialog().select(
            f"{title}  ({start + 1}-{end} of {total})",
            labels
        )

        if selected == -1:
            break

        back_index = len(labels) - 1

        if selected == back_index:
            break

        next_exists = end < total
        prev_exists = page > 0

        if next_exists and selected == len(page_items):
            page += 1
            continue

        if prev_exists:
            prev_index = len(page_items) + (1 if next_exists else 0)

            if selected == prev_index:
                page -= 1
                continue

        if selected < len(page_items):
            addon_action_menu(page_items[selected])


def addon_action_menu(addon):
    while True:
        installed_now = addon_is_installed(addon["id"])

        if installed_now:
            options = [
                c("Already installed", "lime"),
                "Add-on details",
                c("← Back", "gray")
            ]
        else:
            options = [
                c("Install add-on", "cyan"),
                "Add-on details",
                c("← Back", "gray")
            ]

        selected = xbmcgui.Dialog().select(addon["name"], options)

        if selected == -1 or selected == 2:
            break

        if selected == 0:
            if installed_now:
                xbmcgui.Dialog().ok(
                    TITLE,
                    f"{addon['name']}\n\nThis add-on is already installed."
                )
            else:
                install_addon_and_close(addon)

        elif selected == 1:
            show_addon_info(addon)


def show_addon_info(addon):
    installed = "Yes" if addon_is_installed(addon["id"]) else "No"

    if addon["category"] == "Video add-ons":
        video_note = (
            "\n\nVideo check:\n"
            f"{addon.get('video_status', 'Unknown')}\n\n"
            "Real stream testing requires the add-on to be installed and opened in Kodi."
        )
    else:
        video_note = ""

    info = (
        f"Name:\n{addon['name']}\n\n"
        f"ID:\n{addon['id']}\n\n"
        f"Version:\n{addon['version'] or 'Unknown'}\n\n"
        f"Category:\n{addon['category']}\n\n"
        f"Installed:\n{installed}\n\n"
        f"Metadata:\n{addon['health']}\n\n"
        f"Repository:\n{addon['repo_name']}\n\n"
        f"Summary:\n{addon['summary'] or 'No summary available.'}\n\n"
        f"Description:\n{addon['description'] or 'No description available.'}"
        f"{video_note}"
    )

    xbmcgui.Dialog().textviewer(addon["name"], info)


# ============================================================
# HEALTH CHECK
# ============================================================

def check_single_repo_health(repo):
    result = {
        "repo": repo,
        "status": "BAD",
        "status_color": "red",
        "message": "",
        "total_addons": 0,
        "video_addons": 0,
        "video_installed": 0,
        "video_likely_ok": 0,
        "video_unknown": 0,
        "program_addons": 0,
        "repo_addons": 0,
        "skin_addons": 0,
        "working_sources": 0,
        "failed_sources": 0,
        "addons": [],
        "errors": []
    }

    if not repo["urls"]:
        result["message"] = "No repository data source found."
        return result

    for url in repo["urls"]:
        xml_text, error = download_xml_to_memory(url)

        if not xml_text:
            result["failed_sources"] += 1
            result["errors"].append("A source failed.")
            continue

        addons = parse_repo_xml(xml_text, repo)
        del xml_text

        if addons:
            result["working_sources"] += 1
            result["addons"].extend(addons)
        else:
            result["failed_sources"] += 1
            result["errors"].append("A source loaded but returned no add-ons.")

    result["addons"] = dedupe_addons(result["addons"])
    result["total_addons"] = len(result["addons"])

    for addon in result["addons"]:
        if addon["category"] == "Video add-ons":
            result["video_addons"] += 1

            status = addon.get("video_status", "")

            if status == "Installed":
                result["video_installed"] += 1
            elif status == "Listed / likely OK":
                result["video_likely_ok"] += 1
            else:
                result["video_unknown"] += 1

        elif addon["category"] == "Program add-ons":
            result["program_addons"] += 1

        elif addon["category"] == "Repositories":
            result["repo_addons"] += 1

        elif addon["category"] == "Skins":
            result["skin_addons"] += 1

    if result["total_addons"] > 0 and result["failed_sources"] == 0:
        result["status"] = "GOOD"
        result["status_color"] = "lime"
        result["message"] = "Repository data works."
    elif result["total_addons"] > 0 and result["failed_sources"] > 0:
        result["status"] = "PARTIAL"
        result["status_color"] = "gold"
        result["message"] = "Some sources work, some failed."
    else:
        result["status"] = "BAD"
        result["status_color"] = "red"
        result["message"] = "No usable add-on data found."

    return result


def check_all_repositories():
    repos = get_installed_repos()

    if setting_hide_empty_repos():
        repos = [r for r in repos if r["urls"]]

    if not repos:
        xbmcgui.Dialog().ok(
            TITLE,
            "No installed repositories found."
        )
        return

    progress = xbmcgui.DialogProgress()
    progress.create("Repository Health Check", "Checking repositories...")

    health_results = []
    total = len(repos)

    for index, repo in enumerate(repos):
        if progress.iscanceled():
            break

        percent = int(((index + 1) / total) * 100)

        progress.update(
            percent,
            f"Checking...\n{repo['name']}"
        )

        result = check_single_repo_health(repo)
        health_results.append(result)

    progress.close()

    show_repo_health_list(health_results)


def show_repo_health_list(health_results):
    if not health_results:
        xbmcgui.Dialog().ok("Repository Health Check", "No results.")
        return

    health_results.sort(key=lambda x: x["repo"]["name"].lower())

    page = 0

    while True:
        page_size = get_page_size()
        total = len(health_results)
        start = page * page_size
        end = min(start + page_size, total)
        page_items = health_results[start:end]

        labels = []

        for item in page_items:
            if setting_show_health():
                status = c(item["status"], item["status_color"])
            else:
                status = ""

            name = b(item["repo"]["name"])

            if setting_compact_mode():
                labels.append(f"{status} {name}")
            else:
                labels.append(
                    f"{status}  {name}  "
                    f"{c('Add-ons:', 'gray')} {item['total_addons']}  "
                    f"{c('Video:', 'gray')} {item['video_addons']}"
                )

        if end < total:
            labels.append(c("Next Page →", "cyan"))

        if page > 0:
            labels.append(c("← Previous Page", "cyan"))

        labels.append(c("← Back", "gray"))

        selected = xbmcgui.Dialog().select(
            f"Repository Health  ({start + 1}-{end} of {total})",
            labels
        )

        if selected == -1:
            break

        back_index = len(labels) - 1

        if selected == back_index:
            break

        next_exists = end < total
        prev_exists = page > 0

        if next_exists and selected == len(page_items):
            page += 1
            continue

        if prev_exists:
            prev_index = len(page_items) + (1 if next_exists else 0)

            if selected == prev_index:
                page -= 1
                continue

        if selected < len(page_items):
            show_repo_health_menu(page_items[selected])


def show_repo_health_menu(item):
    repo = item["repo"]

    while True:
        status = c(item["status"], item["status_color"])

        options = [
            f"{c('Status:', 'gray')} {status}",
            f"{c('Add-ons found:', 'gray')} {item['total_addons']}",
            f"{c('Video add-ons:', 'gray')} {item['video_addons']}",
            f"{c('Video likely OK:', 'gray')} {item['video_likely_ok']}",
            f"{c('Video unknown:', 'gray')} {item['video_unknown']}",
            f"{c('Working sources:', 'gray')} {item['working_sources']}",
            f"{c('Failed sources:', 'gray')} {item['failed_sources']}",
            c("Show video add-ons", "cyan"),
            c("Show all add-ons", "gold"),
            c("← Back", "gray")
        ]

        if setting_show_failed_sources() and item["errors"]:
            options.insert(7, c("Show source problems", "orange"))

        selected = xbmcgui.Dialog().select(repo["name"], options)

        if selected == -1:
            break

        back_index = len(options) - 1

        if selected == back_index:
            break

        # Info rows do nothing.
        if selected in [0, 1, 2, 3, 4, 5, 6]:
            continue

        has_error_button = setting_show_failed_sources() and item["errors"]

        if has_error_button and selected == 7:
            xbmcgui.Dialog().textviewer(
                "Source Problems",
                "\n\n".join(item["errors"])
            )
            continue

        video_index = 8 if has_error_button else 7
        all_index = 9 if has_error_button else 8

        if selected == video_index:
            video_addons = [
                a for a in item["addons"]
                if a["category"] == "Video add-ons"
            ]

            video_addons = filter_addons_by_settings(video_addons)

            show_paged_addon_results(
                video_addons,
                f"{repo['name']} - Video add-ons"
            )

        elif selected == all_index:
            all_addons = filter_addons_by_settings(item["addons"])

            show_paged_addon_results(
                all_addons,
                f"{repo['name']} - All add-ons"
            )


def show_repo_status_menu(repo, addons, errors):
    health_item = check_single_repo_health(repo)

    health_item["addons"] = addons
    health_item["total_addons"] = len(addons)

    show_repo_health_menu(health_item)


# ============================================================
# MAIN
# ============================================================

def main_menu():
    options = [
        c("🔎 Search Add-ons", "cyan"),
        c("📦 Browse Repositories", "gold"),
        c("🛠 Repository Health Check", "lightblue"),
        c("⚙ Settings", "mediumpurple"),
        c("Exit", "gray")
    ]

    while True:
        selected = xbmcgui.Dialog().select(TITLE, options)

        if selected == -1 or selected == 4:
            break

        if selected == 0:
            search_all_repositories()

        elif selected == 1:
            repo_browser()

        elif selected == 2:
            check_all_repositories()

        elif selected == 3:
            ADDON.openSettings()


main_menu()