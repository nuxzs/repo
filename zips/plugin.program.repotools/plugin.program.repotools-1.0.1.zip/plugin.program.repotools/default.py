import re
import os
import gzip
import json
import time
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from urllib.parse import urljoin

import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon


ADDON = xbmcaddon.Addon()

TITLE = "[B][COLOR mediumpurple]CorpTeam Repo[/COLOR] [COLOR white]Tools[/COLOR][/B]"
ADDON_NAME = "CorpTeam Repo Tools"
ADDONS_PATH = xbmcvfs.translatePath("special://home/addons/")
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
NOTES_FILE = os.path.join(PROFILE_PATH, "repo_tools_notes.json")
CACHE_FILE = os.path.join(PROFILE_PATH, "repo_tools_cache.json")
USER_AGENT = "Kodi CorpTeam Repo Tools"

CATEGORY_ORDER = [
    "Video add-ons",
    "Music add-ons",
    "Picture add-ons",
    "Program add-ons",
    "Services",
    "Repositories",
    "Skins",
    "Subtitles",
    "Context menus",
    "Script modules",
    "Libraries",
    "Other add-ons"
]

VIDEO_POINTS = ["xbmc.python.pluginsource"]
REPO_POINT = "xbmc.addon.repository"
METADATA_POINT = "xbmc.addon.metadata"


# ============================================================
# SETTINGS
# ============================================================

def get_setting_bool(setting_id, default=False):
    try:
        value = ADDON.getSetting(setting_id).lower()
        if value == "":
            return default
        return value == "true"
    except Exception:
        return default


def get_setting_int(setting_id, default=0):
    try:
        value = ADDON.getSetting(setting_id)
        if value == "":
            return default
        return int(value)
    except Exception:
        return default


def get_page_size():
    # settings.xml enum:
    # 0 = 10, 1 = 20, 2 = 30, 3 = 40, 4 = 50
    value = ADDON.getSetting("page_size")

    if value == "0":
        return 10
    if value == "1":
        return 20
    if value == "2":
        return 30
    if value == "3":
        return 40
    if value == "4":
        return 50

    return 20


def get_timeout():
    timeout = get_setting_int("health_check_timeout", 15)

    if timeout < 5:
        return 5

    if timeout > 60:
        return 60

    return timeout


def setting_show_installed():
    return get_setting_bool("show_installed", True)


def setting_video_only():
    return get_setting_bool("video_only", False)


def setting_enable_colors():
    return get_setting_bool("enable_colors", True)


def setting_compact_mode():
    return get_setting_bool("compact_mode", False)


def setting_show_health():
    return get_setting_bool("show_health", True)


def setting_show_video_status():
    return get_setting_bool("show_video_status", True)


def setting_show_category_counts():
    return get_setting_bool("show_category_counts", True)


def setting_show_repo_status():
    return get_setting_bool("show_repo_status", True)


def setting_close_after_install():
    return get_setting_bool("close_after_install", True)


def setting_confirm_before_install():
    return get_setting_bool("confirm_before_install", True)


def setting_gzip_support():
    return get_setting_bool("gzip_support", True)


def setting_show_failed_sources():
    return get_setting_bool("show_failed_sources", False)


def setting_hide_empty_repos():
    return get_setting_bool("hide_empty_repos", False)


def setting_check_metadata_quality():
    return get_setting_bool("check_metadata_quality", True)


def setting_search_name():
    return get_setting_bool("search_name", True)


def setting_search_id():
    return get_setting_bool("search_id", True)


def setting_search_description():
    return get_setting_bool("search_description", True)


def setting_search_summary():
    return get_setting_bool("search_summary", True)


def setting_debug_mode():
    return get_setting_bool("debug_mode", False)


def setting_deep_zip_check():
    return get_setting_bool("deep_zip_check", False)


def setting_show_quality_score():
    return get_setting_bool("show_quality_score", True)


def setting_show_repo_name_in_search():
    return get_setting_bool("show_repo_name_in_search", True)


def setting_enable_notes():
    return get_setting_bool("enable_notes", True)


def setting_cache_repo_results():
    return get_setting_bool("cache_repo_results", False)


def setting_cache_minutes():
    minutes = get_setting_int("cache_minutes", 30)
    if minutes < 1:
        return 1
    if minutes > 1440:
        return 1440
    return minutes


# ============================================================
# UI / TEXT HELPERS
# ============================================================

def c(text, color):
    if not setting_enable_colors():
        return str(text)
    return f"[COLOR {color}]{text}[/COLOR]"


def b(text):
    return f"[B]{text}[/B]"


def clean_text(value):
    if value is None:
        return ""
    return str(value).strip()


def strip_color(text):
    text = re.sub(r"\[/?COLOR[^\]]*\]", "", str(text or ""), flags=re.IGNORECASE)
    text = re.sub(r"\[/?B\]", "", text, flags=re.IGNORECASE)
    return text


def safe_title(text, max_len=90):
    text = clean_text(text)
    text = re.sub(r"\s+", " ", text)
    if len(text) > max_len:
        return text[:max_len - 3].rstrip() + "..."
    return text


def status_label(status):
    status = clean_text(status).upper()
    if status in ("GOOD", "OK", "INSTALLED", "READY"):
        return c(f"[{status}]", "lime")
    if status in ("PARTIAL", "UNKNOWN", "LIMITED", "WARN"):
        return c(f"[{status}]", "gold")
    return c(f"[{status or 'BAD'}]", "red")


def log_debug(message, level=xbmc.LOGINFO):
    if setting_debug_mode():
        try:
            xbmc.log(f"[{ADDON_NAME}] {message}", level)
        except Exception:
            pass


def log_error(message):
    try:
        xbmc.log(f"[{ADDON_NAME}] {message}", xbmc.LOGERROR)
    except Exception:
        pass


def ensure_profile_dir():
    try:
        if not xbmcvfs.exists(PROFILE_PATH):
            xbmcvfs.mkdirs(PROFILE_PATH)
    except Exception:
        try:
            os.makedirs(PROFILE_PATH, exist_ok=True)
        except Exception:
            pass


def read_json_file(path, fallback):
    try:
        if not os.path.exists(path):
            return fallback
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return fallback


def write_json_file(path, data):
    ensure_profile_dir()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def addon_is_installed(addon_id):
    if not addon_id:
        return False

    addon_path = os.path.join(ADDONS_PATH, addon_id)
    return os.path.exists(addon_path)


def addon_local_path(addon_id):
    return os.path.join(ADDONS_PATH, addon_id)


def make_search_text(addon):
    parts = []

    if setting_search_name():
        parts.append(addon.get("name", ""))

    if setting_search_id():
        parts.append(addon.get("id", ""))

    parts.append(addon.get("category", ""))

    if setting_search_summary():
        parts.append(addon.get("summary", ""))

    if setting_search_description():
        parts.append(addon.get("description", ""))

    parts.append(addon.get("repo_name", ""))
    parts.append(addon.get("provider", ""))

    return " ".join(parts).lower()


def open_text(title, text):
    xbmcgui.Dialog().textviewer(title, text)


# ============================================================
# NETWORK HELPERS
# ============================================================

def build_request(url, method=None):
    headers = {"User-Agent": USER_AGENT}
    if method:
        try:
            return urllib.request.Request(url, headers=headers, method=method)
        except TypeError:
            return urllib.request.Request(url, headers=headers)
    return urllib.request.Request(url, headers=headers)


def download_xml_to_memory(url):
    try:
        req = build_request(url)

        with urllib.request.urlopen(req, timeout=get_timeout()) as response:
            data = response.read()

        if setting_gzip_support():
            if url.lower().endswith(".gz") or data[:2] == b"\x1f\x8b":
                data = gzip.decompress(data)

        return data.decode("utf-8", errors="ignore"), None

    except Exception as e:
        log_error(f"XML read error: {e}")
        return None, str(e)


def check_url_exists(url, timeout=None):
    timeout = timeout or get_timeout()
    if not url:
        return False, "Missing URL"

    try:
        req = build_request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as response:
            code = getattr(response, "status", response.getcode())
            if 200 <= int(code) < 400:
                return True, f"HTTP {code}"
            return False, f"HTTP {code}"
    except Exception as head_error:
        try:
            req = build_request(url)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                code = getattr(response, "status", response.getcode())
                if 200 <= int(code) < 400:
                    return True, f"HTTP {code}"
                return False, f"HTTP {code}"
        except Exception as get_error:
            return False, str(get_error or head_error)


def normalize_base_url(url):
    url = clean_text(url)
    if not url:
        return ""
    if not url.endswith("/"):
        url += "/"
    return url


def build_zip_url(addon, repo=None):
    datadir = clean_text(addon.get("repo_datadir"))
    if not datadir and repo:
        datadirs = repo.get("datadirs", [])
        datadir = datadirs[0] if datadirs else ""
    if not datadir:
        return ""

    datadir = normalize_base_url(datadir)
    addon_id = addon.get("id", "")
    version = addon.get("version", "")
    if not addon_id or not version:
        return ""

    return urljoin(datadir, f"{addon_id}/{addon_id}-{version}.zip")


# ============================================================
# INSTALL
# ============================================================

def install_addon_and_close(addon):
    addon_id = addon["id"]
    addon_name = addon["name"]

    if addon_is_installed(addon_id):
        xbmcgui.Dialog().ok(
            TITLE,
            f"{addon_name}\n\nThis add-on is already installed."
        )
        return

    if setting_confirm_before_install():
        details = [
            f"Install this add-on?",
            "",
            addon_name,
            addon_id,
            f"Version: {addon.get('version') or 'Unknown'}",
            f"Repository: {addon.get('repo_name') or 'Unknown'}"
        ]
        confirm = xbmcgui.Dialog().yesno(TITLE, "\n".join(details))

        if not confirm:
            return

    try:
        xbmc.executebuiltin(f"InstallAddon({addon_id})")

        xbmcgui.Dialog().notification(
            "Repo Tools",
            f"Install started: {addon_name}",
            xbmcgui.NOTIFICATION_INFO,
            4000
        )

        if setting_close_after_install():
            raise SystemExit

    except SystemExit:
        raise

    except Exception as e:
        log_error(f"Install error: {e}")
        xbmcgui.Dialog().ok(
            TITLE,
            "Kodi could not start the install."
        )


# ============================================================
# REPOSITORY SCAN
# ============================================================

def get_installed_repos():
    repos = []

    if not os.path.exists(ADDONS_PATH):
        return repos

    for folder in os.listdir(ADDONS_PATH):
        if not folder.startswith("repository."):
            continue

        addon_xml = os.path.join(ADDONS_PATH, folder, "addon.xml")

        repo_name = folder
        repo_id = folder
        repo_urls = []
        checksum_urls = []
        datadirs = []

        try:
            tree = ET.parse(addon_xml)
            root = tree.getroot()

            repo_name = clean_text(root.get("name")) or folder
            repo_id = clean_text(root.get("id")) or folder

            for ext in root.findall("extension"):
                if clean_text(ext.get("point")) == REPO_POINT:
                    for info in ext.findall(".//info"):
                        if info is not None and info.text:
                            url = clean_text(info.text)
                            if url and url not in repo_urls:
                                repo_urls.append(url)
                    for checksum in ext.findall(".//checksum"):
                        if checksum is not None and checksum.text:
                            url = clean_text(checksum.text)
                            if url and url not in checksum_urls:
                                checksum_urls.append(url)
                    for datadir in ext.findall(".//datadir"):
                        if datadir is not None and datadir.text:
                            url = clean_text(datadir.text)
                            if url and url not in datadirs:
                                datadirs.append(url)

        except Exception as e:
            log_error(f"Repo read error {folder}: {e}")

        repos.append({
            "folder": folder,
            "id": repo_id,
            "name": repo_name,
            "urls": repo_urls,
            "checksums": checksum_urls,
            "datadirs": datadirs,
            "addon_xml": addon_xml
        })

    repos.sort(key=lambda x: x["name"].lower())
    return repos


# ============================================================
# ADDON PARSER
# ============================================================

def detect_category(addon):
    addon_id = clean_text(addon.get("id")).lower()

    if addon_id.startswith("skin."):
        return "Skins"

    if addon_id.startswith("script.module."):
        return "Script modules"

    if addon_id.startswith("repository."):
        return "Repositories"

    if addon_id.startswith("service."):
        return "Services"

    if addon_id.startswith("plugin.video."):
        return "Video add-ons"

    if addon_id.startswith("plugin.audio.") or addon_id.startswith("plugin.music."):
        return "Music add-ons"

    if addon_id.startswith("plugin.image.") or addon_id.startswith("plugin.picture."):
        return "Picture add-ons"

    for ext in addon.findall("extension"):
        point = clean_text(ext.get("point")).lower()

        if point == "xbmc.gui.skin":
            return "Skins"

        if point == "xbmc.python.module":
            return "Script modules"

        if point == REPO_POINT:
            return "Repositories"

        if point == "xbmc.service":
            return "Services"

        if point == "xbmc.subtitle.module":
            return "Subtitles"

        if point == "kodi.context.item":
            return "Context menus"

        if point == "xbmc.python.pluginsource":
            provides = ext.find("provides")
            provide_text = clean_text(provides.text if provides is not None else "").lower()

            if "video" in provide_text:
                return "Video add-ons"

            if "audio" in provide_text or "music" in provide_text:
                return "Music add-ons"

            if "image" in provide_text or "picture" in provide_text:
                return "Picture add-ons"

            return "Program add-ons"

        if point == "xbmc.python.script":
            return "Program add-ons"

    return "Other add-ons"


def read_metadata(addon):
    summary = ""
    description = ""
    disclaimer = ""
    license_text = ""
    news = ""
    assets = {}

    metadata = addon.find("extension[@point='xbmc.addon.metadata']")

    if metadata is not None:
        for s in metadata.findall("summary"):
            if s.text:
                summary = clean_text(s.text)
                break

        for d in metadata.findall("description"):
            if d.text:
                description = clean_text(d.text)
                break

        for d in metadata.findall("disclaimer"):
            if d.text:
                disclaimer = clean_text(d.text)
                break

        for l in metadata.findall("license"):
            if l.text:
                license_text = clean_text(l.text)
                break

        for n in metadata.findall("news"):
            if n.text:
                news = clean_text(n.text)
                break

        assets_node = metadata.find("assets")
        if assets_node is not None:
            for child in list(assets_node):
                if child.text:
                    assets[child.tag] = clean_text(child.text)

    return summary, description, disclaimer, license_text, news, assets


def read_extensions(addon):
    ext_data = []
    provides_text = ""
    plugin_library = ""

    for ext in addon.findall("extension"):
        point = clean_text(ext.get("point"))
        library = clean_text(ext.get("library"))
        provides = ext.find("provides")
        provides_value = clean_text(provides.text if provides is not None else "")

        if point == "xbmc.python.pluginsource":
            plugin_library = library
            provides_text = provides_value

        ext_data.append({
            "point": point,
            "library": library,
            "provides": provides_value
        })

    return ext_data, provides_text, plugin_library


def read_requires(addon):
    imports = []
    requires = addon.find("requires")
    if requires is None:
        return imports

    for imp in requires.findall("import"):
        imports.append({
            "addon": clean_text(imp.get("addon")),
            "version": clean_text(imp.get("version")),
            "optional": clean_text(imp.get("optional"))
        })
    return imports


def get_required_python(imports):
    for item in imports:
        if item.get("addon") == "xbmc.python":
            return item.get("version", "")
    return ""


def version_tuple(version):
    parts = re.findall(r"\d+", clean_text(version))
    return tuple(int(p) for p in parts[:4]) if parts else tuple()


def get_metadata_health(addon_id, addon_name, addon_version, category, summary, description):
    if not setting_check_metadata_quality():
        return "OK"

    score = 0

    if addon_id:
        score += 1

    if addon_name:
        score += 1

    if addon_version:
        score += 1

    if category != "Other add-ons":
        score += 1

    if summary or description:
        score += 1

    if score >= 5:
        return "GOOD"

    if score >= 3:
        return "OK"

    return "LIMITED"


def get_video_quality(addon):
    score = 0
    warnings = []
    reasons = []

    addon_id = addon.get("id", "")
    category = addon.get("category", "")
    provides = addon.get("provides", "").lower()
    plugin_library = addon.get("plugin_library", "")
    python_version = addon.get("python_version", "")
    summary = addon.get("summary", "")
    description = addon.get("description", "")
    assets = addon.get("assets", {}) or {}

    if category == "Video add-ons":
        score += 20
        reasons.append("Detected as video add-on")
    else:
        warnings.append("Not detected as video category")

    if addon_id.startswith("plugin.video."):
        score += 15
        reasons.append("ID uses plugin.video prefix")
    elif category == "Video add-ons":
        warnings.append("Video add-on without plugin.video prefix")

    if "video" in provides:
        score += 15
        reasons.append("Provides video")
    elif category == "Video add-ons":
        warnings.append("Missing provides=video metadata")

    if plugin_library:
        score += 10
        reasons.append(f"Plugin entry: {plugin_library}")
    elif category == "Video add-ons":
        warnings.append("Missing plugin library entry")

    if python_version:
        score += 10
        reasons.append(f"Requires xbmc.python {python_version}")
    else:
        warnings.append("Missing xbmc.python requirement")

    if summary:
        score += 5
    else:
        warnings.append("Missing summary")

    if description:
        score += 5
    else:
        warnings.append("Missing description")

    if assets.get("icon") or assets.get("icon.png"):
        score += 5
    else:
        warnings.append("No icon asset in metadata")

    if assets.get("fanart") or assets.get("fanart.jpg"):
        score += 5
    else:
        warnings.append("No fanart asset in metadata")

    if addon.get("version"):
        score += 10
    else:
        warnings.append("Missing version")

    if score >= 80:
        grade = "GOOD"
    elif score >= 55:
        grade = "OK"
    elif score >= 35:
        grade = "LIMITED"
    else:
        grade = "BAD"

    return {
        "score": min(score, 100),
        "grade": grade,
        "warnings": warnings,
        "reasons": reasons
    }


def get_video_test_status(addon):
    if addon["category"] != "Video add-ons":
        return "Not video"

    if addon_is_installed(addon["id"]):
        return "Installed"

    quality = addon.get("video_quality", {})
    grade = quality.get("grade") or addon.get("health")

    if grade == "GOOD":
        return "Listed / likely OK"

    if grade == "OK":
        return "Listed / unknown"

    return "Weak metadata"


def parse_repo_xml(xml_text, repo):
    addons = []

    def parse_addon_node(addon):
        addon_id = clean_text(addon.get("id"))
        addon_name = clean_text(addon.get("name"))
        addon_version = clean_text(addon.get("version"))
        provider = clean_text(addon.get("provider-name"))

        if not addon_id:
            return None

        category = detect_category(addon)
        summary, description, disclaimer, license_text, news, assets = read_metadata(addon)
        extensions, provides, plugin_library = read_extensions(addon)
        imports = read_requires(addon)
        python_version = get_required_python(imports)

        if not addon_name:
            addon_name = addon_id

        health = get_metadata_health(
            addon_id,
            addon_name,
            addon_version,
            category,
            summary,
            description
        )

        item = {
            "id": addon_id,
            "name": addon_name,
            "version": addon_version,
            "provider": provider,
            "category": category,
            "summary": summary,
            "description": description,
            "disclaimer": disclaimer,
            "license": license_text,
            "news": news,
            "assets": assets,
            "extensions": extensions,
            "provides": provides,
            "plugin_library": plugin_library,
            "requires": imports,
            "python_version": python_version,
            "health": health,
            "installed": addon_is_installed(addon_id),
            "repo_name": repo["name"],
            "repo_id": repo["id"],
            "repo_folder": repo.get("folder", ""),
            "repo_datadir": (repo.get("datadirs") or [""])[0] if repo.get("datadirs") else "",
            "repo_info_url": (repo.get("urls") or [""])[0] if repo.get("urls") else ""
        }

        item["zip_url"] = build_zip_url(item, repo)
        item["video_quality"] = get_video_quality(item)
        item["video_status"] = get_video_test_status(item)
        return item

    try:
        text = xml_text.strip()

        try:
            root = ET.fromstring(text)

            if root.tag == "addon":
                addon_nodes = [root]
            else:
                addon_nodes = root.findall(".//addon")

            for addon in addon_nodes:
                item = parse_addon_node(addon)
                if item:
                    addons.append(item)

        except Exception:
            # Fallback for big / messy addons.xml files.
            blocks = re.findall(
                r'<addon\b[^>]*>.*?</addon>',
                text,
                flags=re.DOTALL | re.IGNORECASE
            )

            for block in blocks:
                try:
                    addon = ET.fromstring(block)
                    item = parse_addon_node(addon)
                    if item:
                        addons.append(item)
                except Exception:
                    continue

            single_tags = re.findall(
                r'<addon\b[^>]*/>',
                text,
                flags=re.DOTALL | re.IGNORECASE
            )

            for tag in single_tags:
                try:
                    addon = ET.fromstring(tag)
                    item = parse_addon_node(addon)
                    if item:
                        addons.append(item)
                except Exception:
                    continue

    except Exception as e:
        log_error(f"Parse error: {e}")

    return addons


def dedupe_addons(addons):
    unique = {}

    for addon in addons:
        key = addon["id"]

        if key not in unique:
            unique[key] = addon
            continue

        old = unique[key]
        if version_tuple(addon.get("version")) > version_tuple(old.get("version")):
            unique[key] = addon

    final_addons = list(unique.values())
    final_addons.sort(key=lambda x: x["name"].lower())

    return final_addons


def filter_addons_by_settings(addons):
    results = addons

    if not setting_show_installed():
        results = [a for a in results if not addon_is_installed(a["id"])]

    if setting_video_only():
        results = [a for a in results if a["category"] == "Video add-ons"]

    return results


def cache_key_for_repo(repo):
    return repo.get("id", repo.get("name", ""))


def load_cache():
    return read_json_file(CACHE_FILE, {})


def save_cache(data):
    try:
        write_json_file(CACHE_FILE, data)
    except Exception as e:
        log_debug(f"Cache save failed: {e}")


def load_repo_addons_quiet(repo):
    if not repo["urls"]:
        return [], [f"{repo['name']} has no repository data source."]

    if setting_cache_repo_results():
        cache = load_cache()
        key = cache_key_for_repo(repo)
        cached = cache.get(key)
        if cached and time.time() - cached.get("time", 0) < setting_cache_minutes() * 60:
            return cached.get("addons", []), cached.get("errors", [])

    all_addons = []
    errors = []

    for url in repo["urls"]:
        xml_text, error = download_xml_to_memory(url)

        if not xml_text:
            if setting_debug_mode():
                errors.append(f"Source failed: {url}\n{error}")
            else:
                errors.append("A repository source failed.")
            continue

        parsed = parse_repo_xml(xml_text, repo)
        all_addons.extend(parsed)

        del xml_text

    all_addons = dedupe_addons(all_addons)

    if setting_cache_repo_results():
        cache = load_cache()
        cache[cache_key_for_repo(repo)] = {
            "time": time.time(),
            "addons": all_addons,
            "errors": errors
        }
        save_cache(cache)

    return all_addons, errors


def load_repo_addons_with_progress(repo):
    if not repo["urls"]:
        return [], [f"{repo['name']} has no repository data source."]

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, f"Loading {repo['name']}...")

    all_addons = []
    errors = []

    total = len(repo["urls"])

    for index, url in enumerate(repo["urls"]):
        if progress.iscanceled():
            break

        percent = int(((index + 1) / total) * 100)

        progress.update(
            percent,
            f"Reading repository data...\nSource {index + 1} of {total}"
        )

        xml_text, error = download_xml_to_memory(url)

        if not xml_text:
            if setting_debug_mode():
                errors.append(f"Source failed: {url}\n{error}")
            else:
                errors.append("A repository source failed.")
            continue

        parsed = parse_repo_xml(xml_text, repo)
        all_addons.extend(parsed)

        del xml_text

    progress.close()

    return dedupe_addons(all_addons), errors


# ============================================================
# NOTES / SAVED LIST
# ============================================================

def load_notes():
    data = read_json_file(NOTES_FILE, {})
    if not isinstance(data, dict):
        return {}
    return data


def save_notes(notes):
    write_json_file(NOTES_FILE, notes)


def get_note(addon_id):
    return clean_text(load_notes().get(addon_id, ""))


def set_note_for_addon(addon):
    if not setting_enable_notes():
        xbmcgui.Dialog().ok(TITLE, "Notes are disabled in settings.")
        return

    notes = load_notes()
    current = notes.get(addon["id"], "")
    keyboard = xbmc.Keyboard(current, f"Note for {addon['name']}")
    keyboard.doModal()

    if not keyboard.isConfirmed():
        return

    text = keyboard.getText().strip()
    if text:
        notes[addon["id"]] = text
    else:
        notes.pop(addon["id"], None)

    save_notes(notes)
    xbmcgui.Dialog().notification("Repo Tools", "Note saved", xbmcgui.NOTIFICATION_INFO, 2500)


def show_notes_list():
    notes = load_notes()
    if not notes:
        xbmcgui.Dialog().ok("Notes", "No saved notes yet.")
        return

    lines = []
    for addon_id in sorted(notes.keys()):
        lines.append(f"{addon_id}\n{notes[addon_id]}\n")

    open_text("Saved Add-on Notes", "\n".join(lines))


def clear_all_notes():
    if not xbmcgui.Dialog().yesno("Notes", "Delete all saved notes?"):
        return
    save_notes({})
    xbmcgui.Dialog().notification("Repo Tools", "Notes cleared", xbmcgui.NOTIFICATION_INFO, 2500)


# ============================================================
# MENU / SEARCH
# ============================================================

def get_categories_from_addons(addons):
    found = {}

    for addon in addons:
        category = addon["category"]
        found[category] = found.get(category, 0) + 1

    ordered = []

    for category in CATEGORY_ORDER:
        if category in found:
            ordered.append((category, found[category]))

    for category, count in found.items():
        if category not in CATEGORY_ORDER:
            ordered.append((category, count))

    return ordered


def choose_repo():
    repos = get_installed_repos()

    if setting_hide_empty_repos():
        repos = [r for r in repos if r["urls"]]

    if not repos:
        xbmcgui.Dialog().ok(
            TITLE,
            "No installed repositories found."
        )
        return None

    labels = []

    for repo in repos:
        if repo["urls"]:
            data_state = c("[DATA]", "lime")
            extra = ""
        else:
            data_state = c("[NO DATA]", "red")
            extra = c(" - no addons.xml source", "orange")
        labels.append(f"{data_state} {b(repo['name'])}{extra}")

    labels.append(c("Back", "gray"))

    selected = xbmcgui.Dialog().select("Choose Repository", labels)

    if selected == -1 or selected == len(labels) - 1:
        return None

    return repos[selected]


def search_all_repositories():
    repos = get_installed_repos()

    if setting_hide_empty_repos():
        repos = [r for r in repos if r["urls"]]

    if not repos:
        xbmcgui.Dialog().ok(
            TITLE,
            "No installed repositories found."
        )
        return

    keyboard = xbmc.Keyboard("", "Search add-ons")
    keyboard.doModal()

    if not keyboard.isConfirmed():
        return

    query = keyboard.getText().strip()

    if not query:
        return

    q = query.lower()
    results = []

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Searching repositories...")

    total = len(repos)

    for index, repo in enumerate(repos):
        if progress.iscanceled():
            break

        percent = int(((index + 1) / total) * 100)

        progress.update(
            percent,
            f"Searching...\n{repo['name']}"
        )

        addons, errors = load_repo_addons_quiet(repo)

        for addon in addons:
            search_text = make_search_text(addon)

            if q in search_text:
                results.append(addon)

    progress.close()

    results = filter_addons_by_settings(results)

    if not results:
        xbmcgui.Dialog().ok(
            "No Results",
            f"No add-ons found for:\n\n{query}"
        )
        return

    results.sort(key=lambda x: (x["repo_name"].lower(), x["name"].lower()))
    show_paged_addon_results(results, f"Search Results: {query}")


def search_loaded_addons(addons, title):
    keyboard = xbmc.Keyboard("", "Search add-ons")
    keyboard.doModal()

    if not keyboard.isConfirmed():
        return

    query = keyboard.getText().strip()

    if not query:
        return

    q = query.lower()
    results = []

    for addon in addons:
        if q in make_search_text(addon):
            results.append(addon)

    results = filter_addons_by_settings(results)

    if not results:
        xbmcgui.Dialog().ok(
            "No Results",
            f"No add-ons found for:\n\n{query}"
        )
        return

    show_paged_addon_results(results, title)


def show_top_video_addons(addons, title):
    video_addons = [a for a in addons if a.get("category") == "Video add-ons"]
    video_addons.sort(key=lambda x: (-int(x.get("video_quality", {}).get("score", 0)), x["name"].lower()))
    show_paged_addon_results(video_addons, title)


def repo_browser():
    repo = choose_repo()

    if not repo:
        return

    addons, errors = load_repo_addons_with_progress(repo)

    if not addons:
        xbmcgui.Dialog().ok(
            "Repository Problem",
            f"{repo['name']}\n\n"
            "No add-on data was found.\n\n"
            "This repository may be offline, blocked, empty, or missing valid metadata."
        )
        return

    while True:
        categories = get_categories_from_addons(addons)

        labels = [
            c("Search in this repository", "cyan"),
            c("Best video add-ons by quality", "lime"),
            c("Video add-on checker", "lightblue")
        ]

        for category, count in categories:
            if setting_show_category_counts():
                labels.append(
                    f"{c('[CAT]', 'gold')} {category} {c('[' + str(count) + ']', 'gray')}"
                )
            else:
                labels.append(f"{c('[CAT]', 'gold')} {category}")

        if setting_show_repo_status():
            labels.append(c("Repository status", "lightblue"))

        labels.append(c("Back", "gray"))

        selected = xbmcgui.Dialog().select(repo["name"], labels)

        if selected == -1 or selected == len(labels) - 1:
            break

        if selected == 0:
            search_loaded_addons(addons, f"Search {repo['name']}")
            continue

        if selected == 1:
            show_top_video_addons(addons, f"{repo['name']} - Best Video Add-ons")
            continue

        if selected == 2:
            show_video_checker_results(addons, f"{repo['name']} - Video Checker")
            continue

        status_index = len(labels) - 2 if setting_show_repo_status() else -999

        if selected == status_index:
            show_repo_status_menu(repo, addons, errors)
            continue

        category_index = selected - 3

        if category_index < 0 or category_index >= len(categories):
            continue

        category_name = categories[category_index][0]
        category_addons = [a for a in addons if a["category"] == category_name]
        category_addons = filter_addons_by_settings(category_addons)

        show_paged_addon_results(category_addons, category_name)


# ============================================================
# ADDON LIST / DETAILS
# ============================================================

def addon_label(addon):
    if addon_is_installed(addon["id"]):
        state = c("[Installed]", "lime")
    else:
        state = c("[Available]", "cyan")

    if addon["health"] == "GOOD":
        health = c("GOOD", "lime")
    elif addon["health"] == "OK":
        health = c("OK", "gold")
    else:
        health = c("LIMITED", "orange")

    note = ""
    if setting_enable_notes() and get_note(addon["id"]):
        note = c(" [Note]", "mediumpurple")

    if setting_compact_mode():
        return f"{b(addon['name'])} {state}{note}"

    parts = [b(safe_title(addon["name"], 55)), state]

    if setting_show_health():
        parts.append(health)

    if addon["category"] == "Video add-ons" and setting_show_video_status():
        video_status = addon.get("video_status", "Unknown")

        if video_status == "Installed":
            video = c("Installed", "lime")
        elif video_status == "Listed / likely OK":
            video = c("Likely OK", "lime")
        elif video_status == "Listed / unknown":
            video = c("Unknown", "gold")
        else:
            video = c("Weak", "orange")

        parts.append(f"Video: {video}")

    if setting_show_quality_score() and addon.get("category") == "Video add-ons":
        score = addon.get("video_quality", {}).get("score", 0)
        parts.append(c(f"Score: {score}", "lightblue"))

    if setting_show_repo_name_in_search():
        parts.append(c(addon.get("repo_name", ""), "gray"))

    return " - ".join([p for p in parts if p]) + note


def show_paged_addon_results(results, title):
    if not results:
        xbmcgui.Dialog().ok(
            TITLE,
            "No add-ons found."
        )
        return

    results.sort(key=lambda x: x["name"].lower())

    page = 0

    while True:
        page_size = get_page_size()
        total = len(results)
        start = page * page_size
        end = min(start + page_size, total)
        page_items = results[start:end]

        labels = [addon_label(addon) for addon in page_items]

        if end < total:
            labels.append(c("Next Page", "cyan"))

        if page > 0:
            labels.append(c("Previous Page", "cyan"))

        labels.append(c("Back", "gray"))

        selected = xbmcgui.Dialog().select(
            f"{title}  ({start + 1}-{end} of {total})",
            labels
        )

        if selected == -1:
            break

        back_index = len(labels) - 1

        if selected == back_index:
            break

        next_exists = end < total
        prev_exists = page > 0

        if next_exists and selected == len(page_items):
            page += 1
            continue

        if prev_exists:
            prev_index = len(page_items) + (1 if next_exists else 0)

            if selected == prev_index:
                page -= 1
                continue

        if selected < len(page_items):
            addon_action_menu(page_items[selected])


def addon_action_menu(addon):
    while True:
        installed_now = addon_is_installed(addon["id"])

        options = []
        if installed_now:
            options.append(c("Already installed", "lime"))
        else:
            options.append(c("Install add-on", "cyan"))

        options.extend([
            "Add-on details",
            "Video quality details" if addon.get("category") == "Video add-ons" else "Metadata quality details",
            "Check install package",
            "Add or edit note",
            "Show note",
            c("Back", "gray")
        ])

        selected = xbmcgui.Dialog().select(addon["name"], options)

        if selected == -1 or selected == len(options) - 1:
            break

        if selected == 0:
            if installed_now:
                xbmcgui.Dialog().ok(
                    TITLE,
                    f"{addon['name']}\n\nThis add-on is already installed."
                )
            else:
                install_addon_and_close(addon)

        elif selected == 1:
            show_addon_info(addon)

        elif selected == 2:
            show_video_quality_info(addon)

        elif selected == 3:
            show_package_check(addon)

        elif selected == 4:
            set_note_for_addon(addon)

        elif selected == 5:
            note = get_note(addon["id"])
            xbmcgui.Dialog().ok("Saved Note", note or "No note saved for this add-on.")


def show_addon_info(addon):
    installed = "Yes" if addon_is_installed(addon["id"]) else "No"

    if addon["category"] == "Video add-ons":
        video_note = (
            "\n\nVideo check:\n"
            f"{addon.get('video_status', 'Unknown')}\n"
            f"Quality score: {addon.get('video_quality', {}).get('score', 0)}/100\n\n"
            "RepoTools can check metadata and package readiness. "
            "Real stream playback still requires the add-on to be installed and opened in Kodi."
        )
    else:
        video_note = ""

    debug = ""
    if setting_debug_mode():
        debug = (
            "\n\nDebug details:\n"
            f"Repo ID: {addon.get('repo_id', '')}\n"
            f"Repo info URL: {addon.get('repo_info_url', '')}\n"
            f"Repo datadir: {addon.get('repo_datadir', '')}\n"
            f"Expected ZIP: {addon.get('zip_url', '')}\n"
            f"Plugin library: {addon.get('plugin_library', '')}\n"
            f"Provides: {addon.get('provides', '')}\n"
            f"Python: {addon.get('python_version', '')}\n"
        )

    note = get_note(addon["id"])
    note_text = f"\n\nSaved note:\n{note}" if note else ""

    info = (
        f"Name:\n{addon['name']}\n\n"
        f"ID:\n{addon['id']}\n\n"
        f"Version:\n{addon['version'] or 'Unknown'}\n\n"
        f"Provider:\n{addon.get('provider') or 'Unknown'}\n\n"
        f"Category:\n{addon['category']}\n\n"
        f"Installed:\n{installed}\n\n"
        f"Metadata:\n{addon['health']}\n\n"
        f"Repository:\n{addon['repo_name']}\n\n"
        f"Summary:\n{addon['summary'] or 'No summary available.'}\n\n"
        f"Description:\n{addon['description'] or 'No description available.'}"
        f"{video_note}"
        f"{note_text}"
        f"{debug}"
    )

    open_text(addon["name"], info)


def show_video_quality_info(addon):
    quality = addon.get("video_quality", {}) or {}
    warnings = quality.get("warnings", []) or []
    reasons = quality.get("reasons", []) or []

    lines = [
        addon.get("name", ""),
        addon.get("id", ""),
        "",
        f"Category: {addon.get('category', '')}",
        f"Video status: {addon.get('video_status', 'Unknown')}",
        f"Quality grade: {quality.get('grade', addon.get('health', 'Unknown'))}",
        f"Quality score: {quality.get('score', 0)}/100",
        "",
        "Good signs:"
    ]

    if reasons:
        lines.extend([f"- {r}" for r in reasons])
    else:
        lines.append("- No strong video metadata signs found.")

    lines.append("")
    lines.append("Warnings:")
    if warnings:
        lines.extend([f"- {w}" for w in warnings])
    else:
        lines.append("- No major metadata warnings.")

    if setting_debug_mode():
        lines.extend([
            "",
            "Debug:",
            f"Extension provides: {addon.get('provides', '')}",
            f"Plugin library: {addon.get('plugin_library', '')}",
            f"Requires: {json.dumps(addon.get('requires', []), ensure_ascii=False)}"
        ])

    open_text("Video Quality Details", "\n".join(lines))


def show_package_check(addon):
    zip_url = addon.get("zip_url", "")

    lines = [
        addon.get("name", ""),
        addon.get("id", ""),
        "",
        "Install package check:",
    ]

    if not zip_url:
        lines.append("[WARN] Could not build expected ZIP URL. Repository may not expose datadir metadata.")
    else:
        lines.append(f"Expected ZIP URL:\n{zip_url}\n")
        if setting_deep_zip_check():
            ok, msg = check_url_exists(zip_url)
            lines.append(f"ZIP reachable: {'Yes' if ok else 'No'} - {msg}")
        else:
            lines.append("ZIP reachability check is disabled. Enable Deep ZIP/package check in settings.")

    lines.extend([
        "",
        "Local installed check:",
    ])

    if addon_is_installed(addon["id"]):
        local = check_installed_addon_structure(addon["id"])
        lines.extend(local["lines"])
    else:
        lines.append("Not installed locally.")

    open_text("Package Check", "\n".join(lines))


# ============================================================
# VIDEO CHECKER / INSTALLED CHECKER
# ============================================================

def show_video_checker_results(addons, title="Video Add-on Checker"):
    video_addons = [a for a in addons if a.get("category") == "Video add-ons"]
    if not video_addons:
        xbmcgui.Dialog().ok(title, "No video add-ons found.")
        return

    video_addons.sort(key=lambda x: (-int(x.get("video_quality", {}).get("score", 0)), x["name"].lower()))
    show_paged_addon_results(video_addons, title)


def check_installed_addon_structure(addon_id):
    path = addon_local_path(addon_id)
    lines = []
    score = 0
    status = "BAD"

    if not os.path.exists(path):
        return {"status": "BAD", "score": 0, "lines": ["[BAD] Add-on folder is missing."]}

    checks = [
        ("addon.xml", os.path.join(path, "addon.xml"), 25),
        ("default.py", os.path.join(path, "default.py"), 20),
        ("icon.png", os.path.join(path, "icon.png"), 10),
        ("fanart.jpg", os.path.join(path, "fanart.jpg"), 10),
        ("resources folder", os.path.join(path, "resources"), 5),
    ]

    for name, check_path, points in checks:
        if os.path.exists(check_path):
            lines.append(f"[OK] {name}")
            score += points
        else:
            lines.append(f"[WARN] Missing {name}")

    addon_xml = os.path.join(path, "addon.xml")
    if os.path.exists(addon_xml):
        try:
            root = ET.parse(addon_xml).getroot()
            xml_id = clean_text(root.get("id"))
            if xml_id == addon_id:
                lines.append("[OK] addon.xml ID matches folder name")
                score += 10
            else:
                lines.append(f"[BAD] addon.xml ID mismatch: {xml_id}")

            category = detect_category(root)
            if category == "Video add-ons" or addon_id.startswith("plugin.video."):
                lines.append("[OK] detected as video add-on")
                score += 10

            imports = read_requires(root)
            if get_required_python(imports):
                lines.append("[OK] xbmc.python requirement exists")
                score += 10
            else:
                lines.append("[WARN] Missing xbmc.python requirement")
        except Exception as e:
            lines.append(f"[BAD] addon.xml parse failed: {e}")

    score = min(score, 100)
    if score >= 80:
        status = "GOOD"
    elif score >= 55:
        status = "OK"
    elif score >= 30:
        status = "LIMITED"

    return {"status": status, "score": score, "lines": lines}


def show_installed_addons_tools():
    while True:
        options = [
            c("Check installed video add-ons", "lightblue"),
            c("Check all installed add-ons", "gold"),
            c("Search installed add-ons", "cyan"),
            c("Back", "gray")
        ]
        selected = xbmcgui.Dialog().select("Installed Add-ons Tools", options)
        if selected == -1 or selected == 3:
            break
        if selected == 0:
            show_installed_addons_report(video_only=True)
        elif selected == 1:
            show_installed_addons_report(video_only=False)
        elif selected == 2:
            search_installed_addons()


def read_installed_addon(addon_id):
    addon_xml = os.path.join(addon_local_path(addon_id), "addon.xml")
    try:
        root = ET.parse(addon_xml).getroot()
        fake_repo = {"name": "Installed Add-ons", "id": "local", "folder": "local", "urls": [], "datadirs": []}
        return parse_repo_xml(ET.tostring(root, encoding="unicode"), fake_repo)[0]
    except Exception:
        return {
            "id": addon_id,
            "name": addon_id,
            "version": "",
            "category": "Other add-ons",
            "summary": "",
            "description": "",
            "health": "LIMITED",
            "installed": True,
            "repo_name": "Installed Add-ons",
            "repo_id": "local",
            "video_quality": {"score": 0, "grade": "BAD", "warnings": ["Could not parse addon.xml"], "reasons": []},
            "video_status": "Weak metadata"
        }


def get_installed_addons(video_only=False):
    items = []
    if not os.path.exists(ADDONS_PATH):
        return items

    for folder in os.listdir(ADDONS_PATH):
        path = os.path.join(ADDONS_PATH, folder)
        if not os.path.isdir(path):
            continue
        if video_only and not folder.startswith("plugin.video."):
            continue
        item = read_installed_addon(folder)
        if video_only and item.get("category") != "Video add-ons" and not folder.startswith("plugin.video."):
            continue
        items.append(item)

    items.sort(key=lambda x: x["name"].lower())
    return items


def show_installed_addons_report(video_only=False):
    items = get_installed_addons(video_only=video_only)
    if not items:
        xbmcgui.Dialog().ok("Installed Add-ons", "No installed add-ons found.")
        return

    show_paged_addon_results(items, "Installed Video Add-ons" if video_only else "Installed Add-ons")


def search_installed_addons():
    items = get_installed_addons(video_only=False)
    search_loaded_addons(items, "Search Installed Add-ons")


# ============================================================
# HEALTH CHECK
# ============================================================

def check_single_repo_health(repo):
    result = {
        "repo": repo,
        "status": "BAD",
        "status_color": "red",
        "message": "",
        "total_addons": 0,
        "video_addons": 0,
        "video_installed": 0,
        "video_likely_ok": 0,
        "video_unknown": 0,
        "program_addons": 0,
        "repo_addons": 0,
        "skin_addons": 0,
        "working_sources": 0,
        "failed_sources": 0,
        "checksum_ok": 0,
        "checksum_failed": 0,
        "datadir_ok": 0,
        "datadir_failed": 0,
        "addons": [],
        "errors": []
    }

    if not repo["urls"]:
        result["message"] = "No repository data source found."
        return result

    for url in repo["urls"]:
        xml_text, error = download_xml_to_memory(url)

        if not xml_text:
            result["failed_sources"] += 1
            result["errors"].append(f"Info source failed: {url}\n{error}" if setting_debug_mode() else "A source failed.")
            continue

        addons = parse_repo_xml(xml_text, repo)
        del xml_text

        if addons:
            result["working_sources"] += 1
            result["addons"].extend(addons)
        else:
            result["failed_sources"] += 1
            result["errors"].append(f"Source loaded but returned no add-ons: {url}" if setting_debug_mode() else "A source loaded but returned no add-ons.")

    if setting_deep_zip_check():
        for checksum_url in repo.get("checksums", []):
            ok, msg = check_url_exists(checksum_url)
            if ok:
                result["checksum_ok"] += 1
            else:
                result["checksum_failed"] += 1
                result["errors"].append(f"Checksum failed: {checksum_url}\n{msg}" if setting_debug_mode() else "A checksum source failed.")

        for datadir in repo.get("datadirs", []):
            ok, msg = check_url_exists(datadir)
            if ok:
                result["datadir_ok"] += 1
            else:
                result["datadir_failed"] += 1
                result["errors"].append(f"Datadir failed: {datadir}\n{msg}" if setting_debug_mode() else "A datadir source failed.")

    result["addons"] = dedupe_addons(result["addons"])
    result["total_addons"] = len(result["addons"])

    for addon in result["addons"]:
        if addon["category"] == "Video add-ons":
            result["video_addons"] += 1

            status = addon.get("video_status", "")

            if status == "Installed":
                result["video_installed"] += 1
            elif status == "Listed / likely OK":
                result["video_likely_ok"] += 1
            else:
                result["video_unknown"] += 1

        elif addon["category"] == "Program add-ons":
            result["program_addons"] += 1

        elif addon["category"] == "Repositories":
            result["repo_addons"] += 1

        elif addon["category"] == "Skins":
            result["skin_addons"] += 1

    source_problem = result["failed_sources"] > 0 or result["checksum_failed"] > 0 or result["datadir_failed"] > 0

    if result["total_addons"] > 0 and not source_problem:
        result["status"] = "GOOD"
        result["status_color"] = "lime"
        result["message"] = "Repository data works."
    elif result["total_addons"] > 0 and source_problem:
        result["status"] = "PARTIAL"
        result["status_color"] = "gold"
        result["message"] = "Some sources work, some failed."
    else:
        result["status"] = "BAD"
        result["status_color"] = "red"
        result["message"] = "No usable add-on data found."

    return result


def check_all_repositories():
    repos = get_installed_repos()

    if setting_hide_empty_repos():
        repos = [r for r in repos if r["urls"]]

    if not repos:
        xbmcgui.Dialog().ok(
            TITLE,
            "No installed repositories found."
        )
        return

    progress = xbmcgui.DialogProgress()
    progress.create("Repository Health Check", "Checking repositories...")

    health_results = []
    total = len(repos)

    for index, repo in enumerate(repos):
        if progress.iscanceled():
            break

        percent = int(((index + 1) / total) * 100)

        progress.update(
            percent,
            f"Checking...\n{repo['name']}"
        )

        result = check_single_repo_health(repo)
        health_results.append(result)

    progress.close()

    show_repo_health_list(health_results)


def show_repo_health_list(health_results):
    if not health_results:
        xbmcgui.Dialog().ok("Repository Health Check", "No results.")
        return

    health_results.sort(key=lambda x: x["repo"]["name"].lower())

    page = 0

    while True:
        page_size = get_page_size()
        total = len(health_results)
        start = page * page_size
        end = min(start + page_size, total)
        page_items = health_results[start:end]

        labels = []

        for item in page_items:
            status = status_label(item["status"]) if setting_show_health() else ""
            name = b(item["repo"]["name"])

            if setting_compact_mode():
                labels.append(f"{status} {name}")
            else:
                labels.append(
                    f"{status} {name} - "
                    f"{c('Add-ons:', 'gray')} {item['total_addons']} - "
                    f"{c('Video:', 'gray')} {item['video_addons']} - "
                    f"{c('Sources:', 'gray')} {item['working_sources']}/{item['working_sources'] + item['failed_sources']}"
                )

        if end < total:
            labels.append(c("Next Page", "cyan"))

        if page > 0:
            labels.append(c("Previous Page", "cyan"))

        labels.append(c("Back", "gray"))

        selected = xbmcgui.Dialog().select(
            f"Repository Health  ({start + 1}-{end} of {total})",
            labels
        )

        if selected == -1:
            break

        back_index = len(labels) - 1

        if selected == back_index:
            break

        next_exists = end < total
        prev_exists = page > 0

        if next_exists and selected == len(page_items):
            page += 1
            continue

        if prev_exists:
            prev_index = len(page_items) + (1 if next_exists else 0)

            if selected == prev_index:
                page -= 1
                continue

        if selected < len(page_items):
            show_repo_health_menu(page_items[selected])


def show_repo_health_menu(item):
    repo = item["repo"]

    while True:
        status = c(item["status"], item["status_color"])

        options = [
            f"{c('Status:', 'gray')} {status}",
            f"{c('Add-ons found:', 'gray')} {item['total_addons']}",
            f"{c('Video add-ons:', 'gray')} {item['video_addons']}",
            f"{c('Video likely OK:', 'gray')} {item['video_likely_ok']}",
            f"{c('Video unknown:', 'gray')} {item['video_unknown']}",
            f"{c('Working info sources:', 'gray')} {item['working_sources']}",
            f"{c('Failed info sources:', 'gray')} {item['failed_sources']}",
        ]

        if setting_deep_zip_check():
            options.extend([
                f"{c('Checksum OK:', 'gray')} {item['checksum_ok']}",
                f"{c('Checksum failed:', 'gray')} {item['checksum_failed']}",
                f"{c('Datadir OK:', 'gray')} {item['datadir_ok']}",
                f"{c('Datadir failed:', 'gray')} {item['datadir_failed']}",
            ])

        if setting_show_failed_sources() and item["errors"]:
            options.append(c("Show source problems", "orange"))

        options.extend([
            c("Show best video add-ons", "lime"),
            c("Show video add-ons", "cyan"),
            c("Show all add-ons", "gold"),
            c("Full text report", "lightblue"),
            c("Back", "gray")
        ])

        selected = xbmcgui.Dialog().select(repo["name"], options)

        if selected == -1:
            break

        back_index = len(options) - 1

        if selected == back_index:
            break

        label = strip_color(options[selected]).lower()

        if label.startswith("status:") or "add-ons found:" in label or "video add-ons:" in label or "working" in label or "failed" in label or "checksum" in label or "datadir" in label:
            continue

        if "show source problems" in label:
            open_text("Source Problems", "\n\n".join(item["errors"]))
            continue

        if "best video" in label:
            show_top_video_addons(item["addons"], f"{repo['name']} - Best Video Add-ons")
            continue

        if "show video add-ons" in label:
            video_addons = [a for a in item["addons"] if a["category"] == "Video add-ons"]
            video_addons = filter_addons_by_settings(video_addons)
            show_paged_addon_results(video_addons, f"{repo['name']} - Video add-ons")
            continue

        if "show all add-ons" in label:
            all_addons = filter_addons_by_settings(item["addons"])
            show_paged_addon_results(all_addons, f"{repo['name']} - All add-ons")
            continue

        if "full text report" in label:
            show_repo_text_report(item)
            continue


def show_repo_text_report(item):
    repo = item["repo"]
    lines = [
        repo.get("name", ""),
        repo.get("id", ""),
        "",
        f"Status: {item['status']}",
        f"Message: {item['message']}",
        f"Add-ons: {item['total_addons']}",
        f"Video add-ons: {item['video_addons']}",
        f"Program add-ons: {item['program_addons']}",
        f"Repositories: {item['repo_addons']}",
        f"Skins: {item['skin_addons']}",
        f"Working info sources: {item['working_sources']}",
        f"Failed info sources: {item['failed_sources']}",
        "",
        "Repository sources:"
    ]
    for url in repo.get("urls", []):
        lines.append(f"- {url}")
    lines.append("")
    lines.append("Datadirs:")
    for url in repo.get("datadirs", []):
        lines.append(f"- {url}")
    lines.append("")
    lines.append("Checksums:")
    for url in repo.get("checksums", []):
        lines.append(f"- {url}")

    if item.get("errors"):
        lines.append("")
        lines.append("Problems:")
        for err in item["errors"]:
            lines.append(f"- {err}")

    if setting_debug_mode():
        lines.append("")
        lines.append("Debug add-on IDs:")
        for addon in item.get("addons", [])[:200]:
            lines.append(f"- {addon.get('id')} {addon.get('version')} {addon.get('category')}")

    open_text("Repository Report", "\n".join(lines))


def show_repo_status_menu(repo, addons, errors):
    health_item = check_single_repo_health(repo)

    health_item["addons"] = addons
    health_item["total_addons"] = len(addons)
    health_item["errors"].extend(errors or [])

    show_repo_health_menu(health_item)


# ============================================================
# EXTRA TOOLS
# ============================================================

def show_video_tools():
    while True:
        options = [
            c("Check video add-ons in one repository", "lightblue"),
            c("Search video add-ons in all repositories", "cyan"),
            c("Show best video add-ons from all repositories", "lime"),
            c("Back", "gray")
        ]
        selected = xbmcgui.Dialog().select("Video Add-on Tools", options)
        if selected == -1 or selected == 3:
            break
        if selected == 0:
            repo = choose_repo()
            if repo:
                addons, errors = load_repo_addons_with_progress(repo)
                show_video_checker_results(addons, f"{repo['name']} - Video Checker")
        elif selected == 1:
            old = ADDON.getSetting("video_only")
            try:
                ADDON.setSetting("video_only", "true")
            except Exception:
                pass
            search_all_repositories()
            try:
                ADDON.setSetting("video_only", old)
            except Exception:
                pass
        elif selected == 2:
            show_best_video_all_repos()


def show_best_video_all_repos():
    repos = get_installed_repos()
    if setting_hide_empty_repos():
        repos = [r for r in repos if r["urls"]]
    if not repos:
        xbmcgui.Dialog().ok(TITLE, "No installed repositories found.")
        return

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Finding best video add-ons...")
    all_video = []
    total = len(repos)

    for index, repo in enumerate(repos):
        if progress.iscanceled():
            break
        progress.update(int(((index + 1) / total) * 100), f"Scanning...\n{repo['name']}")
        addons, errors = load_repo_addons_quiet(repo)
        all_video.extend([a for a in addons if a.get("category") == "Video add-ons"])

    progress.close()
    all_video = dedupe_addons(all_video)
    all_video.sort(key=lambda x: (-int(x.get("video_quality", {}).get("score", 0)), x["name"].lower()))
    show_paged_addon_results(all_video, "Best Video Add-ons")


def tools_menu():
    while True:
        options = [
            c("Video add-on tools", "lightblue"),
            c("Installed add-on tools", "gold"),
            c("Saved notes", "mediumpurple"),
            c("Clear repo cache", "orange"),
            c("Back", "gray")
        ]
        selected = xbmcgui.Dialog().select("RepoTools Extra Tools", options)
        if selected == -1 or selected == 4:
            break
        if selected == 0:
            show_video_tools()
        elif selected == 1:
            show_installed_addons_tools()
        elif selected == 2:
            show_notes_menu()
        elif selected == 3:
            clear_repo_cache()


def show_notes_menu():
    while True:
        options = [
            c("Show saved notes", "mediumpurple"),
            c("Clear saved notes", "orange"),
            c("Back", "gray")
        ]
        selected = xbmcgui.Dialog().select("Saved Notes", options)
        if selected == -1 or selected == 2:
            break
        if selected == 0:
            show_notes_list()
        elif selected == 1:
            clear_all_notes()


def clear_repo_cache():
    if not os.path.exists(CACHE_FILE):
        xbmcgui.Dialog().ok("Cache", "No cache file found.")
        return
    if not xbmcgui.Dialog().yesno("Cache", "Clear saved repository cache?"):
        return
    try:
        os.remove(CACHE_FILE)
        xbmcgui.Dialog().notification("Repo Tools", "Cache cleared", xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception as e:
        xbmcgui.Dialog().ok("Cache", f"Could not clear cache:\n{e}")


# ============================================================
# MAIN
# ============================================================

def main_menu():
    options = [
        c("Search Add-ons", "cyan"),
        c("Browse Repositories", "gold"),
        c("Repository Health Check", "lightblue"),
        c("Extra Tools", "lime"),
        c("Settings", "mediumpurple"),
        c("Exit", "gray")
    ]

    while True:
        selected = xbmcgui.Dialog().select(TITLE, options)

        if selected == -1 or selected == 5:
            break

        if selected == 0:
            search_all_repositories()

        elif selected == 1:
            repo_browser()

        elif selected == 2:
            check_all_repositories()

        elif selected == 3:
            tools_menu()

        elif selected == 4:
            ADDON.openSettings()


main_menu()
