import xbmc
import xbmcgui
import xbmcplugin
import urllib.parse
import requests
import sys
import os
import re
import json  # Import the json module
import tv_functions
import time
import threading # Import threading for search
# Addon info
addon_handle = int(sys.argv[1])
addon_id = 'plugin.video.GoldVault'  # Change this to your addon's ID

# Configuration options
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
EXTRA_HEADERS = {}
PROXY = None

# It's crucial to get it within the Kodi environment.
def get_tmdb_api_key():
    """Gets the TMDB API key from addon settings or uses a fallback."""
    try:
        # This will only work when running within Kodi
        if 'xbmc' in sys.modules:
            return xbmc.addon.Addon().getSetting('tmdb_api_key') or 'f0bbe0dc0bd0742a6ff38a7d6106f128'  # Fallback
        else:
            return  'f0bbe0dc0bd0742a6ff38a7d6106f128'
    except Exception as e:
        # Handle the error gracefully, provide a message, and use the fallback.
        print(f"Error getting TMDB API key: {e}")
        return 'f0bbe0dc0bd0742a6ff38a7d6106f128'  # Fallback

TMDB_API_KEY = get_tmdb_api_key()
# Path to your text file.  Make sure this is correct!
# UPDATED: GENRES_FILE_PATH to point to the 'resources' folder
GENRES_FILE_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'genres.json')
MOVIE_DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'movies_chcac.json')
file_path = os.path.join(os.path.dirname(__file__), 'movie_list.json')
# Path to the icons folder
ICONS_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'images', 'icons')
FANART_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'images', 'fanart.jpg') #added fanart path
# Declare the cache variable globally and initialize it
CACHED_PREPROCESSED_MOVIES_DATA = None

def log(message, level=xbmc.LOGINFO):
    """Logs messages to the Kodi log file."""
    xbmc.log(f'[{addon_id}] {message}', level=level)

def read_movie_data():
    """
    Reads the preprocessed movie data from MOVIE_DATA_FILE (movies_chcac.json).
    Caches the data in memory to avoid re-reading the file for every request.
    """
    global CACHED_PREPROCESSED_MOVIES_DATA
    if CACHED_PREPROCESSED_MOVIES_DATA is not None:
        log("Using cached preprocessed movie data.", level=xbmc.LOGDEBUG)
        return CACHED_PREPROCESSED_MOVIES_DATA

    log(f"Reading preprocessed movie data from: {MOVIE_DATA_FILE}", level=xbmc.LOGDEBUG)
    try:
        with open(MOVIE_DATA_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            CACHED_PREPROCESSED_MOVIES_DATA = data # Cache the data
            log(f"Successfully loaded and cached {len(data)} movies from {MOVIE_DATA_FILE}.", level=xbmc.LOGINFO)
            return data
    except FileNotFoundError:
        log(f"Error: Preprocessed movie data file not found: {MOVIE_DATA_FILE}. Please run generate_movie_data_cache.py.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Movie data file not found. Run generator script.", xbmcgui.NOTIFICATION_ERROR)
        return {}
    except json.JSONDecodeError as e:
        log(f"Error decoding JSON from {MOVIE_DATA_FILE}: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", f"Bad movie data file: {e}", xbmcgui.NOTIFICATION_ERROR)
        return {}
    except Exception as e:
        log(f"An unexpected error occurred while reading {MOVIE_DATA_FILE}: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", f"Failed to read movie data: {e}", xbmcgui.NOTIFICATION_ERROR)
        return {}

def read_movie_list(file_path):
    """Reads movie titles and URLs from a JSON file."""
    movie_titles = {} # This will store {title: full_movie_dict}
    try:
        log(f"Reading movie list from: {file_path}", level=xbmc.LOGDEBUG)
        with open(file_path, 'r', encoding='utf-8') as f:
            movie_data = json.load(f)  # Load the entire JSON structure

        if "movies" in movie_data:
            for movie in movie_data["movies"]:
                if "title" in movie and "url" in movie:
                    # Store the entire movie dictionary, including 'is_4k'
                    movie_titles[movie["title"]] = movie
                    log(f"Found movie: Title: {movie['title']}, URL: {movie['url']}, is_4k: {movie.get('is_4k', False)}", level=xbmc.LOGDEBUG)
                else:
                    log(f"Skipping movie with missing title or URL: {movie}", level=xbmc.LOGWARNING)
        else:
            log(f"Warning: 'movies' key not found in JSON file: {file_path}", level=xbmc.LOGWARNING)

    except FileNotFoundError:
        error_message = f"File not found. Check path:"
        log(error_message, level=xbmc.LOGERROR)
        return {}
    except json.JSONDecodeError:
        error_message = f"Error decoding JSON.  Invalid JSON format: {file_path}"
        log(error_message, level=xbmc.LOGERROR)
        return {}
    except Exception as e:
        error_message = f"Error reading file: {e}"
        log(error_message, level=xbmc.LOGERROR)
        return {}
    log(f"Read {len(movie_titles)} movies from file.", level=xbmc.LOGDEBUG)
    return movie_titles


def get_movie_details(title):
    """Fetches movie details from TMDB using the title."""
    if not TMDB_API_KEY:
        log("TMDB API key is missing.  Please configure it in the addon settings.", level=xbmc.LOGERROR)
        return {}

    search_url = f"https://api.themoviedb.org/3/search/movie?api_key={TMDB_API_KEY}&query={urllib.parse.quote_plus(title)}"
    try:
        start_time = time.time()
        log(f"Fetching TMDB search url: {search_url}", level=xbmc.LOGDEBUG) #DEBUG
        response = requests.get(search_url)
        response.raise_for_status()  # Raise an exception for bad status codes
        end_time = time.time()
        log(f"TMDB search response status: {response.status_code}, time taken: {end_time - start_time:.2f} seconds", level=xbmc.LOGDEBUG) #DEBUG
        data = response.json()
        log(f"TMDB search response data: {data}", level=xbmc.LOGDEBUG) #DEBUG

        if data and data['results']:
            movie_id = data['results'][0]['id']
            details_url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key={TMDB_API_KEY}"
            start_time = time.time()
            log(f"Fetching TMDB details url: {details_url}", level=xbmc.LOGDEBUG) #DEBUG
            details_response = requests.get(details_url)
            details_response.raise_for_status()
            end_time = time.time()
            log(f"TMDB details response status: {details_response.status_code}, time taken: {end_time - start_time:.2f} seconds", level=xbmc.LOGDEBUG) #DEBUG
            movie_details = details_response.json()
            log(f"TMDB details response data: {movie_details}", level=xbmc.LOGDEBUG) #DEBUG
            return movie_details
        else:
            log(f"Movie not found on TMDB: {title}", level=xbmc.LOGWARNING)
            return {}

    except requests.exceptions.RequestException as e:
        log(f"TMDB API error: {e}", level=xbmc.LOGERROR)
        return None
    except json.JSONDecodeError:
        log("Error decoding JSON from TMDB API", level=xbmc.LOGERROR)
        return None
    except KeyError as e:
        log(f"KeyError: {e}.  Check the TMDB API response format.", level=xbmc.LOGERROR)
        return None
    except Exception as e:
        log(f"An unexpected error occurred: {e}", level=xbmc.LOGERROR)
        return None
    
def is_movie_4k(movie_details):
    """
    Determines if a movie is 4K based on the 'is_4k' field in movie_details.

    Args:
        movie_details (dict): The dictionary of movie details (can be from local JSON or TMDB).

    Returns:
        bool: True if the movie is 4K, False otherwise.
    """
    # Directly check the 'is_4k' field from your local JSON or TMDB response
    return movie_details.get('is_4k', False)

def list_movies(movie_titles, genre=None, page=1):
    """Lists the movies in Kodi with pagination and genre filtering."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page

    all_local_movies_data = sorted(movie_titles.values(), key=lambda x: x.get('title', ''))
    
    filtered_local_movies_by_genre = []
    if genre:
        for movie_data in all_local_movies_data:
            temp_movie_details_for_genre_check = get_movie_details(movie_data.get('title'))
            details_for_genre_check = temp_movie_details_for_genre_check if temp_movie_details_for_genre_check else movie_data

            if details_for_genre_check and genre.lower() in [g['name'].lower() for g in details_for_genre_check.get('genres', [])]:
                filtered_local_movies_by_genre.append(movie_data)
    else:
        filtered_local_movies_by_genre = all_local_movies_data

    total_movies_for_pagination = len(filtered_local_movies_by_genre)

    paged_local_movies_slice = filtered_local_movies_by_genre[start_index:end_index]

    movies_to_display = []
    for movie_data in paged_local_movies_slice:
        title = movie_data.get('title')
        url = movie_data.get('url')

        if not title or not url:
            log(f"Skipping malformed movie entry in local list: {movie_data}", level=xbmc.LOGWARNING)
            continue

        tmdb_details = get_movie_details(title) 
        
        # FIX: Ensure local 'is_4k' is preserved by starting with movie_data
        movie_details_for_display = movie_data.copy() 
        if tmdb_details:
            movie_details_for_display.update(tmdb_details)

        movies_to_display.append((title, url, movie_details_for_display))

    for title, url, movie_details in movies_to_display:
        display_title = title
         # Add year to the display title with color
        release_date = movie_details.get('release_date')
        if release_date and len(release_date) >= 4:
            year = release_date.split('-')[0]
            display_title = f"{display_title} [COLOR grey]({year})[/COLOR]" # Changed format
            
        log(f"Processing movie: '{title}'. Details for 4K check: {movie_details.get('is_4k', 'N/A')}", level=xbmc.LOGDEBUG)

        if is_movie_4k(movie_details):
            display_title += " [COLOR gold]4K[/COLOR]"

        list_item = xbmcgui.ListItem(display_title)

        poster_path = movie_details.get('poster_path')
        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'banner': poster_url,
                'clearart': poster_url,
                'clearlogo': poster_url,
                'landscape': poster_url,
            })
            list_item.setProperty('media_type', 'movie')
            list_item.setProperty('is_playable', 'true')
        else:
            default_poster_path = os.path.join(ICONS_PATH, 'DefaultVideo.png')
            list_item.setArt({'thumb': default_poster_path, 'poster': default_poster_path})

        video_info = list_item.getVideoInfoTag()
        video_info.setPlot(movie_details.get('overview', ''))
        video_info.setYear(int(movie_details.get('release_date', '').split('-')[0]) if movie_details.get('release_date') else 0)
        video_info.setRating(float(movie_details.get('vote_average', 0)))
        genres = [g['name'] for g in movie_details.get('genres', [])]
        video_info.setGenres(genres)
        video_info.setTitle(movie_details.get('title', ''))
        video_info.setMediaType('movie')

        runtime_minutes = movie_details.get('runtime', 0)
        total_seconds = runtime_minutes * 60
        video_info.setDuration(total_seconds)

        list_item.setInfo('video', video_info)

        plot = movie_details.get('overview', '')
        genre_str = ", ".join(genres)
        list_item.setProperty('genre', genre_str)
        list_item.setProperty('plot', plot)

        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item)

    total_pages = (total_movies_for_pagination + items_per_page - 1) // items_per_page
    
    if page > 1:
        prev_page_item = xbmcgui.ListItem("[COLOR gold]Previous Page >>[/COLOR]")
        prev_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'previous.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies&genre={urllib.parse.quote_plus(str(genre) if genre else '')}&page={page - 1}",
            prev_page_item,
            isFolder=True,
        )

    if page < total_pages:
        next_page_item = xbmcgui.ListItem("[COLOR gold]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies&genre={urllib.parse.quote_plus(str(genre) if genre else '')}&page={page + 1}",
            next_page_item,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(addon_handle)

def list_movies_by_genre(genre, page=1):
    """
    Lists movies belonging to a specific genre with pagination.
    Uses movies_chcac.json for filtering, but fetches details from TMDB API for display.
    """
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    log(f"list_movies_by_genre: Listing movies for genre: {genre}, Page: {page}. Fetching details from TMDB.", level=xbmc.LOGINFO)

    all_movies_data_from_cache = read_movie_data() # Use movies_chcac.json for initial list and filter
    filtered_movies_by_genre = []

    for movie_data_from_cache in all_movies_data_from_cache.values():
        movie_genres_from_cache = movie_data_from_cache.get('genres', [])
        # Check if the requested genre (case-insensitive) is in the movie's genre list from cache
        if genre.lower() in [g.lower() for g in movie_genres_from_cache if g]:
            filtered_movies_by_genre.append(movie_data_from_cache)

    sorted_movies = sorted(filtered_movies_by_genre, key=lambda x: x.get('title', '').lower())
    total_movies_in_genre = len(sorted_movies)

    paged_movies_slice = sorted_movies[start_index:start_index + items_per_page]
    log(f"list_movies_by_genre: Found {total_movies_in_genre} total movies for genre '{genre}'. Displaying {len(paged_movies_slice)} on page {page}.", level=xbmc.LOGINFO)

    for movie_data_from_cache in paged_movies_slice:
        title = movie_data_from_cache.get('title')
        url = movie_data_from_cache.get('url')

        if not title or not url:
            log(f"Skipping malformed movie entry for genre filter: {movie_data_from_cache}", level=xbmc.LOGWARNING)
            continue
        
        tmdb_details = get_movie_details(title) # Fetch details live from TMDB API
        
        display_title = title
        is_4k = movie_data_from_cache.get('is_4k', False) # Use is_4k from cached data
        if is_4k:
            display_title += " [COLOR gold]4K[/COLOR]"

        list_item = xbmcgui.ListItem(display_title)
        
        if tmdb_details:
            # Set Art (poster, fanart) from live TMDB details
            poster_path = tmdb_details.get('poster_path')
            tmdb_fanart_path = tmdb_details.get('backdrop_path')
            fanart_to_use = f"https://image.tmdb.org/t/p/original/{tmdb_fanart_path}" if tmdb_fanart_path else FANART_PATH

            if poster_path:
                poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
                list_item.setArt({
                    'thumb': poster_url,
                    'poster': poster_url,
                    'banner': poster_url,
                    'clearart': poster_url,
                    'clearlogo': poster_url,
                    'fanart': fanart_to_use
                })
            else: # Fallback for poster if not found
                list_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultVideo.png'), 'fanart': fanart_to_use})

            # Set Info from live TMDB details
            video_info = list_item.getVideoInfoTag()
            video_info.setPlot(tmdb_details.get('overview', ''))
            release_date = tmdb_details.get('release_date')
            if release_date and len(release_date) >= 4:
                try:
                    year_val = int(release_date.split('-')[0])
                    video_info.setYear(year_val)
                    # ADDED: Add year to display title in gray
                    display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]" 
                except ValueError:
                    log(f"Could not parse year from release_date: {release_date}", level=xbmc.LOGWARNING)
            video_info.setRating(tmdb_details.get('vote_average', 0.0))
            genres_tmdb = tmdb_details.get('genres', []) # These are dicts with 'id' and 'name'
            genre_names = [g['name'] for g in genres_tmdb if 'name' in g]
            video_info.setGenres(genre_names)
            video_info.setTitle(tmdb_details.get('title', ''))
            video_info.setDuration(tmdb_details.get('runtime', 0) * 60) # Runtime in minutes, convert to seconds
            
            list_item.setInfo('video', video_info)

            # Set Properties for skinning
            list_item.setProperty('genre', ", ".join(genre_names))
            list_item.setProperty('plot', tmdb_details.get('overview', ''))
            list_item.setProperty('is_4k', 'true' if is_4k else 'false')

            # Update list_item title with year, as it might have changed
            list_item.setLabel(display_title)

        else: # Fallback if no TMDB details are found at all
            log(f"No TMDB details found for '{title}'. Using basic info and default art.", level=xbmc.LOGWARNING)
            list_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultVideo.png'), 'fanart': FANART_PATH})
            # Use basic info from cache if available, including year if present
            cached_year = movie_data_from_cache.get('year')
            if cached_year:
                display_title = f"{display_title} [COLOR grey]({cached_year})[/COLOR]"
                list_item.setLabel(display_title)
                list_item.setInfo('video', {'title': title, 'plot': movie_data_from_cache.get('overview', ''), 'year': cached_year})
            else:
                list_item.setInfo('video', {'title': title, 'plot': movie_data_from_cache.get('overview', '')})
            list_item.setProperty('is_4k', 'true' if is_4k else 'false')

        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_movies_in_genre + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_movies_by_genre&genre={urllib.parse.quote_plus(genre)}&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR gold]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)
        log(f"Added Next Page link for genre {genre}, page {page + 1}", level=xbmc.LOGDEBUG)

    xbmcplugin.endOfDirectory(addon_handle)

def list_genres(page=1):
    """
    Lists available movie genres with pagination, reading from movies_chcac.json.
    """
    xbmcplugin.setContent(addon_handle, 'genres')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    all_movies_data = read_movie_data()
    unique_genres = set()
    for movie_data in all_movies_data.values():
        genres = movie_data.get('genres')
        if genres:
            for genre_name in genres:
                if genre_name:
                    unique_genres.add(genre_name)

    sorted_genres = sorted(list(unique_genres)) # Sort genres alphabetically
    total_genres = len(sorted_genres)

    paged_genres_slice = sorted_genres[start_index:start_index + items_per_page]

    for genre in paged_genres_slice:
        list_item = xbmcgui.ListItem(f"[COLOR gold]{genre}[/COLOR]")
        
        # NEW: Dynamically generate icon name based on genre
        icon_name = f"genre_{genre.lower().replace(' ', '_')}.png"
        genre_icon_path = os.path.join(ICONS_PATH, icon_name)
        
        # Check if the specific genre icon exists, otherwise use a default
        if os.path.exists(genre_icon_path):
            icon_to_use = genre_icon_path
        else:
            icon_to_use = os.path.join(ICONS_PATH, 'DefaultFolder.png') # Fallback icon

        list_item.setArt({'icon': icon_to_use, 'fanart': FANART_PATH})
        
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies_by_genre&genre={urllib.parse.quote_plus(genre)}&page=1",
            list_item,
            isFolder=True
        )

    total_pages = (total_genres + items_per_page - 1) // items_per_page
    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_genres&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR gold]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_4k_movies(page=1):
    """Lists only 4K movies in Kodi with pagination, reading 'is_4k' from movie_list.json and fetching other details live from TMDB."""
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page
    end_index = start_index + items_per_page

    log(f"list_4k_movies: Calling read_movie_list from {file_path}", level=xbmc.LOGDEBUG)
    all_movies_from_file = read_movie_list(file_path) # This reads from movie_list.json
    log(f"list_4k_movies: Read {len(all_movies_from_file)} movies from movie_list.json.", level=xbmc.LOGDEBUG)
    
    filtered_4k_movies_titles = []
    for title, movie_data in all_movies_from_file.items():
        # Check the is_4k flag from the movie_list.json data
        log(f"list_4k_movies: Checking '{title}'. is_4k in movie_data: {movie_data.get('is_4k', 'Not Found')}", level=xbmc.LOGDEBUG)
        if is_movie_4k(movie_data):
            log(f"list_4k_movies: Adding '{title}' to 4K list (is_4k is True).", level=xbmc.LOGDEBUG)
            filtered_4k_movies_titles.append(title)
    
    # Sort titles for consistent pagination
    filtered_4k_movies_titles.sort()
    
    total_4k_movies = len(filtered_4k_movies_titles)

    # Get the slice of 4K movie titles for the current page
    paged_4k_movie_titles_slice = filtered_4k_movies_titles[start_index:end_index]
    log(f"list_4k_movies: Found {total_4k_movies} total 4K movies. Displaying {len(paged_4k_movie_titles_slice)} on page {page}.", level=xbmc.LOGINFO)

    for title in paged_4k_movie_titles_slice:
        # Retrieve full details for display from TMDB.
        log(f"list_4k_movies: Attempting to get TMDB details for '{title}'.", level=xbmc.LOGDEBUG)
        tmdb_details = get_movie_details(title) # Fetch details live from TMDB
        log(f"list_4k_movies: TMDB details for '{title}': {tmdb_details is not None}", level=xbmc.LOGDEBUG)
        
        # Combine local movie_list.json data (for URL, is_4k) with TMDB details
        movie_details = all_movies_from_file.get(title, {}).copy() # Start with local data
        if tmdb_details:
            movie_details.update(tmdb_details) # Overlay with TMDB data

        if not movie_details:
            log(f"Could not get details for 4K movie '{title}' for display. Skipping.", level=xbmc.LOGWARNING)
            continue
        display_title = title
        # Add year to the display title with color
        release_date = movie_details.get('release_date')
        if release_date and len(release_date) >= 4:
            year = release_date.split('-')[0]
            display_title = f"{display_title} [COLOR grey]({year})[/COLOR]" # Changed format
           
        display_title += " [COLOR gold]4K[/COLOR]"    
        list_item = xbmcgui.ListItem(display_title)

        poster_path = movie_details.get('poster_path')
        if poster_path:
            poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
            list_item.setArt({
                'thumb': poster_url,
                'poster': poster_url,
                'banner': poster_url,
                'clearart': poster_url,
                'clearlogo': poster_url,
                'landscape': poster_url,
            })
            list_item.setProperty('media_type', 'movie')
            list_item.setProperty('is_playable', 'true')
        else:
            default_poster_path = os.path.join(ICONS_PATH, 'DefaultVideo.png')
            list_item.setArt({'thumb': default_poster_path, 'poster': default_poster_path})

        video_info = list_item.getVideoInfoTag()
        video_info.setPlot(movie_details.get('overview', ''))
        video_info.setYear(int(movie_details.get('release_date', '').split('-')[0]) if movie_details.get('release_date') else 0)
        video_info.setRating(float(movie_details.get('vote_average', 0)))
        genres = [g['name'] for g in movie_details.get('genres', [])]
        video_info.setGenres(genres)
        video_info.setTitle(movie_details.get('title', ''))
        video_info.setMediaType('movie')

        runtime_minutes = movie_details.get('runtime', 0)
        total_seconds = runtime_minutes * 60
        video_info.setDuration(total_seconds)

        list_item.setInfo('video', video_info)

        plot = movie_details.get('overview', '')
        genre_str = ", ".join(genres)
        list_item.setProperty('genre', genre_str)
        list_item.setProperty('plot', plot)

        # Ensure we get the URL from the original movie_list.json data
        url_from_file = all_movies_from_file.get(title, {}).get('url', '')
        log(f"list_4k_movies: URL for '{title}': {url_from_file}", level=xbmc.LOGDEBUG)
        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url_from_file)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item)

    total_pages = (total_4k_movies + items_per_page - 1) // items_per_page
    
    if page > 1:
        prev_page_item = xbmcgui.ListItem("[COLOR gold]Previous Page >>[/COLOR]")
        prev_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'previous.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_4k_movies&page={page - 1}",
            prev_page_item,
            isFolder=True,
        )

    if page < total_pages:
        next_page_item = xbmcgui.ListItem("[COLOR gold]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_4k_movies&page={page + 1}",
            next_page_item,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(addon_handle)

def list_movies_by_year(year, page=1):
    """
    Lists movies for a specific year with pagination.
    Uses movies_chcac.json for filtering, but fetches details from TMDB API for display.
    """
    xbmcplugin.setContent(addon_handle, 'movies')
    items_per_page = 50
    start_index = (page - 1) * items_per_page

    log(f"list_movies_by_year: Listing movies for year: {year}, Page: {page}. Fetching details from TMDB.", level=xbmc.LOGINFO)

    # Attempt to convert the 'year' parameter from URL to an integer for robust comparison
    requested_year_int = None
    try:
        requested_year_int = int(year)
    except ValueError:
        log(f"list_movies_by_year: Invalid year parameter received: {year}. Expected a number.", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Invalid year specified.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    all_movies_data_from_cache = read_movie_data() # Use movies_chcac.json for initial list and filter

    filtered_movies = []
    for movie_data_from_cache in all_movies_data_from_cache.values():
        movie_year_from_cache = movie_data_from_cache.get('year')
        
        # Robust comparison: try to convert cached year to int and compare
        try:
            if isinstance(movie_year_from_cache, (int, float)):
                if int(movie_year_from_cache) == requested_year_int:
                    filtered_movies.append(movie_data_from_cache)
            elif isinstance(movie_year_from_cache, str) and movie_year_from_cache.isdigit():
                if int(movie_year_from_cache) == requested_year_int:
                    filtered_movies.append(movie_data_from_cache)
            # Log if the year from cache is present but in an unexpected format
            elif movie_year_from_cache is not None:
                 log(f"list_movies_by_year: Unexpected non-numeric type for movie year in cache: {type(movie_year_from_cache)} value: {movie_year_from_cache}", level=xbmc.LOGWARNING)
        except (ValueError, TypeError):
            log(f"list_movies_by_year: Could not convert cached year '{movie_year_from_cache}' to integer for comparison.", level=xbmc.LOGWARNING)


    sorted_movies = sorted(filtered_movies, key=lambda x: x.get('title', '').lower())
    total_movies_in_year = len(sorted_movies)

    paged_movies_slice = sorted_movies[start_index:start_index + items_per_page]
    log(f"list_movies_by_year: Found {total_movies_in_year} total movies for year '{year}'. Displaying {len(paged_movies_slice)} on page {page}.", level=xbmc.LOGINFO)

    for movie_data_from_cache in paged_movies_slice:
        title = movie_data_from_cache.get('title')
        url = movie_data_from_cache.get('url')

        if not title or not url:
            log(f"Skipping malformed movie entry for year filter: {movie_data_from_cache}", level=xbmc.LOGWARNING)
            continue

        tmdb_details = get_movie_details(title) # Fetch details live from TMDB API

        display_title = title
        is_4k = movie_data_from_cache.get('is_4k', False) # Use is_4k from cached data
        if is_4k:
            display_title += " [COLOR gold]4K[/COLOR]"

        list_item = xbmcgui.ListItem(display_title)

        if tmdb_details:
            # Use poster/fanart URLs from live TMDB details
            poster_path = tmdb_details.get('poster_path')
            tmdb_fanart_path = tmdb_details.get('backdrop_path')
            fanart_to_use = f"https://image.tmdb.org/t/p/original/{tmdb_fanart_path}" if tmdb_fanart_path else FANART_PATH

            if poster_path:
                poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
                list_item.setArt({
                    'thumb': poster_url,
                    'poster': poster_url,
                    'banner': poster_url,
                    'clearart': poster_url,
                    'clearlogo': poster_url,
                    'fanart': fanart_to_use
                })
            else: # Fallback for poster if not found
                list_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultVideo.png'), 'fanart': fanart_to_use})

            video_info = list_item.getVideoInfoTag()
            video_info.setPlot(tmdb_details.get('overview', ''))
            release_date = tmdb_details.get('release_date')
            if release_date and len(release_date) >= 4:
                try:
                    year_val = int(release_date.split('-')[0])
                    video_info.setYear(year_val)
                    # ADDED: Add year to display title in gray
                    display_title = f"{display_title} [COLOR grey]({year_val})[/COLOR]"
                except ValueError:
                    log(f"Could not parse year from release_date: {release_date}", level=xbmc.LOGWARNING)
            video_info.setRating(tmdb_details.get('vote_average', 0.0))
            genres_tmdb = tmdb_details.get('genres', [])
            genre_names = [g['name'] for g in genres_tmdb if 'name' in g]
            video_info.setGenres(genre_names)
            video_info.setTitle(tmdb_details.get('title', ''))
            video_info.setDuration(tmdb_details.get('runtime', 0) * 60)

            list_item.setInfo('video', video_info)

            genre_str = ", ".join(genre_names)
            list_item.setProperty('genre', genre_str)
            list_item.setProperty('plot', tmdb_details.get('overview', ''))
            list_item.setProperty('is_4k', 'true' if is_4k else 'false')

            # Update list_item title with year, as it might have changed
            list_item.setLabel(display_title)

        else: # Fallback if no TMDB details are found at all
            log(f"No TMDB details found for '{title}'. Using basic info and default art.", level=xbmc.LOGWARNING)
            list_item.setArt({'icon': os.path.join(ICONS_PATH, 'DefaultVideo.png'), 'fanart': FANART_PATH})
            # Use basic info from cache if available, including year if present
            cached_year = movie_data_from_cache.get('year')
            if cached_year:
                display_title = f"{display_title} [COLOR grey]({cached_year})[/COLOR]"
                list_item.setLabel(display_title)
                list_item.setInfo('video', {'title': title, 'plot': movie_data_from_cache.get('overview', ''), 'year': cached_year})
            else:
                list_item.setInfo('video', {'title': title, 'plot': movie_data_from_cache.get('overview', '')})
            list_item.setProperty('is_4k', 'true' if is_4k else 'false')


        play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
        xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)

    total_pages = (total_movies_in_year + items_per_page - 1) // items_per_page

    if page < total_pages:
        next_page_url = f"{sys.argv[0]}?action=list_movies_by_year&year={year}&page={page + 1}"
        next_page_item = xbmcgui.ListItem("[COLOR gold]Next Page >>[/COLOR]")
        next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
        xbmcplugin.addDirectoryItem(addon_handle, next_page_url, next_page_item, isFolder=True)
        log(f"Added Next Page link for years, page {page + 1}", level=xbmc.LOGDEBUG)

    xbmcplugin.endOfDirectory(addon_handle)

def list_years(page=1):
    """
    Lists all available movie release years without pagination, reading from movies_chcac.json.
    Each year will be a clickable item.
    """
    xbmcplugin.setContent(addon_handle, 'years')
    log(f"list_years: Listing all available years.", level=xbmc.LOGINFO) # Updated log message

    all_movies_data = read_movie_data() # Read movie data from cache

    unique_years = set()
    for movie_data in all_movies_data.values():
        year = movie_data.get('year')
        if year is not None:
            try:
                unique_years.add(int(year)) # Ensure year is an integer for consistent sorting
            except (ValueError, TypeError):
                log(f"list_years: Skipping invalid year value from cache: {year}", level=xbmc.LOGWARNING)
    
    sorted_years = sorted(list(unique_years), reverse=True) # Sort years from newest to oldest
    total_years = len(sorted_years)

    log(f"list_years: Found {total_years} unique years. Displaying all of them.", level=xbmc.LOGINFO) # Updated log message

    for year_val in sorted_years: # Loop directly over all sorted years
        list_item = xbmcgui.ListItem(f"[COLOR gold]{year_val}[/COLOR]")
        list_item.setArt({'icon': os.path.join(ICONS_PATH, 'years.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(
            addon_handle,
            f"{sys.argv[0]}?action=list_movies_by_year&year={year_val}&page=1", # Each year leads to its movies, starting on page 1
            list_item,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(addon_handle)

def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        cleanedparams = paramstring.rstrip('/?')
        if cleanedparams.startswith('?'):
            cleanedparams = cleanedparams[1:]
        params = cleanedparams.split('&')
        for i in range(len(params)):
            splitparams = params[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = urllib.parse.unquote_plus(splitparams[1])
    return param

##search function 
def get_user_input():
    kb = xbmc.Keyboard('', 'Search for Movies', False)
    kb.doModal()
    
    if kb.isConfirmed():
        return kb.getText()
    else:
        return None

def list_search(search_term, dialog, page=1):
    try:
        xbmc.log(f"Listing search results for: {search_term} (with dialog), Page: {page}", level=xbmc.LOGINFO)

        items_per_page = 50
        start_index = (page - 1) * items_per_page

        movie_titles = read_movie_list(file_path)
        
        all_matched_movies_data = []
        for title, movie_data in movie_titles.items():
            if search_term.lower() in title.lower():
                all_matched_movies_data.append(movie_data)
        
        all_matched_movies_data = sorted(all_matched_movies_data, key=lambda x: x.get('title', ''))
        total_matched_movies = len(all_matched_movies_data)

        paged_matched_movies_slice = all_matched_movies_data[start_index : start_index + items_per_page]

        if not paged_matched_movies_slice and page == 1:
            xbmc.log(f"No movies found for '{search_term}'.  Returning to show_movies.", level=xbmc.LOGDEBUG)
            dialog.close()
            xbmcgui.Dialog().notification("No Results", f"No movies found for '{search_term}'", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action=show_movies)")
            return
        elif not paged_matched_movies_slice and page > 1:
            xbmc.log(f"No more movies found for '{search_term}' on page {page}.", level=xbmc.LOGDEBUG)
            dialog.close()
            xbmcplugin.endOfDirectory(addon_handle)
            return
        
        xbmcplugin.setContent(addon_handle, 'movies')
        xbmc.log(f"Set content type to 'movies'.", level=xbmc.LOGDEBUG)

        count = 0
        progress_step = 100 // len(paged_matched_movies_slice) if len(paged_matched_movies_slice) > 0 else 100

        for movie_data in paged_matched_movies_slice:
            if dialog.iscanceled():
                xbmc.log(f"Search was cancelled by user.", level=xbmc.LOGDEBUG)
                break

            title = movie_data.get('title')
            url = movie_data.get('url')

            tmdb_details = get_movie_details(title)
            # FIX: Ensure local 'is_4k' is preserved by starting with movie_data
            movie_details_for_display = movie_data.copy()
            if tmdb_details:
                movie_details_for_display.update(tmdb_details)
            display_title = title
            # Add year to the display title with color
            release_date = movie_details_for_display.get('release_date')
            if release_date and len(release_date) >= 4:
                year = release_date.split('-')[0]
                display_title = f"{display_title} [COLOR grey]({year})[/COLOR]" # <-- ADD THE CODE HERE
            log(f"Processing search result movie: '{title}'. Details for 4K check: {movie_details_for_display.get('is_4k', 'N/A')}", level=xbmc.LOGDEBUG)

            if is_movie_4k(movie_details_for_display):
                display_title += " [COLOR gold]4K[/COLOR]"

            list_item = xbmcgui.ListItem(display_title)

            if movie_details_for_display:
                poster_path = movie_details_for_display.get('poster_path')
                if poster_path:
                    poster_url = f"https://image.tmdb.org/t/p/original/{poster_path}"
                    list_item.setArt({'thumb': poster_url, 'poster': poster_url})
                else:
                    default_poster_path = os.path.join(ICONS_PATH, 'DefaultVideo.png')
                    list_item.setArt({'thumb': default_poster_path, 'poster': default_poster_path})

                video_info = list_item.getVideoInfoTag()
                video_info.setPlot(movie_details_for_display.get('overview', ''))
                video_info.setYear(int(movie_details_for_display.get('release_date', '').split('-')[0]) if movie_details_for_display.get('release_date') else 0)
                video_info.setRating(float(movie_details_for_display.get('vote_average', 0)))
                genres = [genre_data['name'] for genre_data in movie_details_for_display.get('genres', [])]
                video_info.setGenres(genres)
                video_info.setTitle(movie_details_for_display.get('title', ''))
                video_info.setMediaType('movie')
                runtime_minutes = movie_details_for_display.get('runtime', 0)
                video_info.setDuration(int(runtime_minutes) * 60 if runtime_minutes else 0)

                list_item.setInfo('video', video_info)

            play_url = f"{sys.argv[0]}?action=play&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(url)}"
            xbmcplugin.addDirectoryItem(addon_handle, play_url, list_item, isFolder=False)
            xbmc.log(f"Added item: {title}", level=xbmc.LOGDEBUG)

            count += 1
            dialog.update(min(100, count * progress_step), message=f"Found {count}/{len(paged_matched_movies_slice)} on page {page}")

        dialog.close()

        total_pages = (total_matched_movies + items_per_page - 1) // items_per_page
        
        if page > 1:
            prev_page_item = xbmcgui.ListItem("[COLOR gold]Previous Page >>[/COLOR]")
            prev_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'previous.png')})
            xbmcplugin.addDirectoryItem(
                addon_handle,
                f"{sys.argv[0]}?action=list_search&search_term={urllib.parse.quote_plus(search_term)}&page={page - 1}",
                prev_page_item,
                isFolder=True,
            )

        if page < total_pages:
            next_page_item = xbmcgui.ListItem("[COLOR gold]Next Page >>[/COLOR]")
            next_page_item.setArt({'icon': os.path.join(ICONS_PATH, 'next.png')})
            xbmcplugin.addDirectoryItem(
                addon_handle,
                f"{sys.argv[0]}?action=list_search&search_term={urllib.parse.quote_plus(search_term)}&page={page + 1}",
                next_page_item,
                isFolder=True,
            )

        xbmcplugin.endOfDirectory(addon_handle)
        xbmc.log(f"Finished list_search. endOfDirectory called", level=xbmc.LOGDEBUG)

    except Exception as e:
        xbmc.log(f"Error in list_search: {e}", level=xbmc.LOGERROR)
        dialog.close()
        xbmcplugin.endOfDirectory(addon_handle)
        xbmc.log(f"Finished list_search with error. endOfDirectory called", level=xbmc.LOGERROR) 

def play_movie(title, url):
    """Plays the stream with retry logic and improved error handling."""
    retries = 3
    for attempt in range(retries):
        try:
            list_item = xbmcgui.ListItem(label=title)
            list_item.setProperty('IsPlayable', 'true')
            player = xbmc.Player()
            player.play(url, list_item)

            # Wait for a moment to allow playback to initiate
            for _ in range(10):  # Check for 10 seconds
                xbmc.sleep(1000)  # Sleep for 1 second between checks
                if player.isPlaying():
                    xbmcgui.Dialog().notification("Playing", f"Now playing: {title}", xbmcgui.NOTIFICATION_INFO)
                    return  # Exit if playback is successful

            xbmc.log(f"Playback failed for {url} on attempt {attempt + 1}", level=xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("Playback Failed", f"Attempt {attempt + 1} failed.", xbmcgui.NOTIFICATION_ERROR)

        except Exception as e:
            xbmc.log(f"Error playing {url}: {e}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", f"Error playing stream: {e}", xbmcgui.NOTIFICATION_ERROR)

        if attempt < retries - 1:
            xbmc.sleep(5000)  # Wait 5 seconds before retrying

    xbmcgui.Dialog().notification("Error", f"Failed to play stream after {retries} attempts.", xbmcgui.NOTIFICATION_ERROR)

def router(paramstring):
    """Router function to handle different actions."""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

if __name__ == '__main__':
    params = get_params()
    action = params.get('action')
    
    log(f"Main Router: Action received: {action}, Params: {params}", level=xbmc.LOGINFO)

    # --- Handle Playback Actions First (Both Movies and TV streams now delegate to tv_functions.play_stream) ---
    if action == 'play': 
        title = params.get('title', '')
        url = params.get('url', '')
        if title and url:
            play_movie(title, url) # Calls the new play_movie function defined in main.py
            sys.exit() # IMPORTANT: Exit immediately after attempting playback
        else:
            xbmcgui.Dialog().notification("Error", "Title or URL is missing for movie playback.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle) # Ensure directory ends if error

    # This block handles TV stream playback (delegating to tv_functions.play_stream)
    elif action == 'play_stream':
        title = params.get('title', '') # Get title for TV stream playback
        url = params.get('url', '')
        if title and url:
            log(f"Main Router: Calling tv_functions.play_stream for TV stream URL: '{url}' with title: '{title}'", level=xbmc.LOGINFO)
            tv_functions.play_stream(urllib.parse.unquote_plus(title), urllib.parse.unquote_plus(url)) # Pass title and unquote url
            sys.exit() # IMPORTANT: Exit immediately after resolving URL for playback
        else:
            xbmcgui.Dialog().notification("Error", "No stream URL or title specified for TV playback.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    # --- Handle Directory Listing Actions ---
    elif action is None:
        tv_folder_item = xbmcgui.ListItem('[COLOR gold]Live TV[/COLOR]')
        tv_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'tv.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=show_tv_live", tv_folder_item, isFolder=True)

        movies_folder_item = xbmcgui.ListItem('[COLOR white]One[/COLOR][COLOR gold]Click Movies[/COLOR]')
        movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'movie.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=show_movies", movies_folder_item, isFolder=True)

        xbmcplugin.endOfDirectory(addon_handle)
    
    elif action == 'show_tv_live': # Example action for your Live TV section
        xbmc.log("Executing 'show_tv_live' action. Calling tv_functions.show_main_menu().", level=xbmc.LOGINFO)
        tv_functions.show_main_menu() # This calls the main entry point for your TV functions
        # Important: endOfDirectory here if show_tv_live is a folder listing, not a playback action.
        xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_channels':
        category = params.get('category')
        xbmc.log(f"main.py: Routing 'list_channels' for '{category}' to tv_functions.show_channels_in_category.", level=xbmc.LOGINFO)
        tv_functions.show_channels_in_category(category)

    elif action == 'show_movies':
        all_movies_folder_item = xbmcgui.ListItem('[COLOR gold]All Movies[/COLOR]')
        all_movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'allmovie.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_movies&page=1", all_movies_folder_item, isFolder=True)

        fourk_movies_folder_item = xbmcgui.ListItem('[COLOR gold]4K Movies[/COLOR]')
        fourk_movies_folder_item.setArt({'icon': os.path.join(ICONS_PATH, '4k.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_4k_movies&page=1", fourk_movies_folder_item, isFolder=True)
        
        years_folder_item = xbmcgui.ListItem('[COLOR gold]Years[/COLOR]')
        years_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'years.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_years&page=1", years_folder_item, isFolder=True)

        genres_folder_item = xbmcgui.ListItem('[COLOR gold]Genres[/COLOR]')
        genres_folder_item.setArt({'icon': os.path.join(ICONS_PATH, 'genre.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=list_genres&page=1", genres_folder_item, isFolder=True)

        search_item = xbmcgui.ListItem("[COLOR gold]Search[/COLOR]")
        search_item.setArt({'icon': os.path.join(ICONS_PATH, 'search.png'), 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?action=open_search", search_item, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_movies':
        movie_titles = read_movie_list(file_path)
        genre = params.get('genre')
        page = int(params.get('page', 1))
        list_movies(movie_titles, genre, page)

    elif action == 'list_years':
        page = int(params.get('page', 1))
        list_years(page)
   
    elif action == 'list_movies_by_year':
        year = params.get('year')
        page = int(params.get('page', 1))
        if year:
            list_movies_by_year(year, page)
        else:
            xbmcgui.Dialog().notification("Error", "No year specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_genres':
        page = int(params.get('page', 1))
        list_genres(page)

    elif action == 'list_movies_by_genre':
        genre = params.get('genre')
        page = int(params.get('page', 1))
        if genre:
            list_movies_by_genre(genre, page)
        else:
            xbmcgui.Dialog().notification("Error", "No genre specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_4k_movies':
        page = int(params.get('page', 1))
        list_4k_movies(page)
        
    elif action == 'open_search':
       xbmc.log("Executing 'open_search' action.", level=xbmc.LOGINFO)
       search_term = get_user_input()
       if search_term:
        dialog = xbmcgui.DialogProgress()
        dialog.create("Searching...", f"Finding Movies for '{search_term}'...")
        thread = threading.Thread(target=list_search, args=(search_term, dialog, 1))
        thread.start()
       else:
           xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_search':
        search_term = params.get('search_term')
        page = int(params.get('page', 1))
        if search_term:
            dialog = xbmcgui.DialogProgress()
            dialog.create("Searching for Movies", f"Please wait while we find '{search_term}' (Page {page})...")
            thread = threading.Thread(target=list_search, args=(search_term, dialog, page))
            thread.start()
        else:
            xbmcgui.Dialog().notification("Error", "No search term specified.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle)
            
    else:
        log(f"Main Router: Unhandled action or initial entry point. Action: '{action}'", level=xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(addon_handle)