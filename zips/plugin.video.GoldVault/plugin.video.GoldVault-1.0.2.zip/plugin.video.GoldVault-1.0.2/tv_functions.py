import xbmc
import xbmcgui
import xbmcplugin
import urllib.parse
import os
import re
import sys
import requests       # Still needed for play_stream, but not for icon download here
import zipfile
import time
import shutil         # Make sure shutil is imported for rmtree and move operations
import urllib.request # For urlretrieve
import traceback
# Addon info
addon_handle = int(sys.argv[1])
addon_id = 'plugin.video.GoldVault' # Ensure this matches your addon's ID in addon.xml

# Configuration options for network requests (needed by play_stream and icon download)
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
EXTRA_HEADERS = {}
PROXY = None

# Paths for addon resources
# Path for static folder icons (e.g., sports.png, movies.png, usa_networks.png, default_folder.png)
# These should be bundled with your main addon zip in resources/images/icons/
ICONS_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'images', 'icons')

# Define the path where the downloaded channel icons will be extracted
# This is now forced to be within the addon's local directory (tv_icons)
LOCAL_CHANNEL_ICONS_DIR = os.path.join(os.path.dirname(__file__), 'tv_icons')
# This is the path the script will use to FIND channel icons.
# CHANGED: Explicitly point to the 'tv' subfolder for icon lookup.
CHANNEL_ICONS_PATH = os.path.join(LOCAL_CHANNEL_ICONS_DIR, 'tv')

# Path for the main addon fanart (usually in resources/images/fanart.jpg)
FANART_PATH = os.path.join(os.path.dirname(__file__), 'resources', 'images', 'fanart.jpg')

# NEW: Configuration for the external icon pack download
# IMPORTANT: REPLACE "DRIVE_ID" with your actual Google Drive File ID.
ICON_PACK_DOWNLOAD_URL = "https://download1526.mediafire.com/11giamf5833gMC1Nu_oS4DH9XQOLPHXgIdzn6kYf0PGYwuOKe4yV44BCCyGBfCHbwh6333ql9Jmf4cYIYogPEHec0X63aeAkGZ9_ACn2Q1_GBRQJM_qS8TtRZlOGhiAp-tfyPIP8zyS1Q4z0K7fjslu-swLXMke470yg2aP-RwRz/v0993jm6fw4yjnw/tv_channel_icons.zip"
def read_categories_and_channels(file_path):
    categorized_channels = {}
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            for i in range(len(lines)):
                line = lines[i].strip()
                if line.startswith('#EXTINF:'):
                    match = re.search(r'#EXTINF:-1 group-title="(.*?)"\s*,(.+)', line)
                    if match:
                        group_title = match.group(1).strip()
                        title = match.group(2).strip()

                        if i + 1 < len(lines):
                            url = lines[i + 1].strip()
                            if group_title not in categorized_channels:
                                categorized_channels[group_title] = []
                            categorized_channels[group_title].append((title, url))
                            xbmc.log(f"[GoldVault TV] Added channel: '{title}' to category: '{group_title}'", level=xbmc.LOGINFO)
                        else:
                            xbmc.log(f"[GoldVault TV] Missing URL for channel: '{title}' in category: '{group_title}'", level=xbmc.LOGWARNING)
                    else:
                        xbmc.log(f"[GoldVault TV] Failed to parse EXTINF line: '{line}'", level=xbmc.LOGWARNING)
    except FileNotFoundError:
        xbmc.log(f"[GoldVault TV] File not found: {file_path}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "File not found: " + os.path.basename(file_path), xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        xbmc.log(f"[GoldVault TV] Error reading file {file_path}: {str(e)}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "Error reading channel list: " + str(e), xbmcgui.NOTIFICATION_ERROR)

    xbmc.log(f"[GoldVault TV] Total categories found: {len(categorized_channels)}. Keys found: {list(categorized_channels.keys())}", level=xbmc.LOGINFO)
    return categorized_channels

# NEW: Helper function to check if channel icons are downloaded
def are_channel_icons_downloaded():
    """
    Checks if the channel icon directory (CHANNEL_ICONS_PATH, i.e., tv_icons/tv/)
    exists and contains a default_channel.png as a simple indicator that icons
    have been downloaded and extracted.
    """
    test_icon_path = os.path.join(CHANNEL_ICONS_PATH, 'default_channel.png') # Checks inside the 'tv' subfolder
    dir_exists = os.path.exists(CHANNEL_ICONS_PATH)
    file_exists = os.path.exists(test_icon_path)
    is_downloaded = dir_exists and file_exists

    xbmc.log("[GoldVault TV][IconsCheck] Checking path: " + CHANNEL_ICONS_PATH + ". Dir exists: " + str(dir_exists), level=xbmc.LOGINFO)
    xbmc.log("[GoldVault TV][IconsCheck] Checking file: " + test_icon_path + ". File exists: " + str(file_exists), level=xbmc.LOGINFO)
    xbmc.log("[GoldVault TV][IconsCheck] Final download status: " + str(is_downloaded), level=xbmc.LOGINFO)
    return is_downloaded

# NEW download_and_extract_icons function
def download_and_extract_icons():
    """
    Downloads the external icon pack zip using requests and extracts its contents.
    Ensures icons from a 'tv/' subfolder in the zip are placed into
    LOCAL_CHANNEL_ICONS_DIR/tv/.
    The downloaded zip and temporary extraction folder will be kept for testing.
    All dialogs and notifications are removed.
    """
    xbmc.log("[GoldVault TV] Starting icon download (silent).", level=xbmc.LOGINFO)
    # dialog = xbmcgui.DialogProgress() # REMOVED: No dialog box
    # dialog.create("Downloading Icons") # REMOVED: No dialog box
    # dialog.update(0, "Please wait while TV channel icons are downloaded...") # REMOVED: No dialog box

    download_success = False
    zip_file_path = os.path.join(LOCAL_CHANNEL_ICONS_DIR, "tv_channel_icons.zip")
    temp_extract_dir = os.path.join(LOCAL_CHANNEL_ICONS_DIR, "temp_extract")

    try:
        # Create necessary directories - LOCAL_CHANNEL_ICONS_DIR is NOT deleted here.
        os.makedirs(LOCAL_CHANNEL_ICONS_DIR, exist_ok=True)
        # Ensure temp_extract_dir is clean before extracting
        if os.path.exists(temp_extract_dir):
            xbmc.log("[GoldVault TV] Clearing temporary extraction directory: " + temp_extract_dir, level=xbmc.LOGINFO)
            shutil.rmtree(temp_extract_dir)
        os.makedirs(temp_extract_dir, exist_ok=True)
        
        # Ensure the final destination for icons (tv_icons/tv/) exists
        final_icons_dest_dir = os.path.join(LOCAL_CHANNEL_ICONS_DIR, 'tv')
        os.makedirs(final_icons_dest_dir, exist_ok=True)
        xbmc.log("[GoldVault TV] Ensuring final icon destination exists: " + final_icons_dest_dir, level=xbmc.LOGINFO)


        # Download the file using requests
        xbmc.log("[GoldVault TV] Downloading zip to: " + zip_file_path, level=xbmc.LOGINFO)
        session = requests.Session()
        response = session.get(ICON_PACK_DOWNLOAD_URL, stream=True, timeout=600)
        response.raise_for_status() # Raise an error for bad responses (4xx or 5xx)

        content_type = response.headers.get('Content-Type', '')
        if 'application/zip' not in content_type.lower() and 'application/x-zip-compressed' not in content_type.lower():
            xbmc.log("[GoldVault TV] Downloaded file is not a ZIP type: " + content_type, level=xbmc.LOGERROR)
            # xbmcgui.Dialog().notification("Download Failed", "Downloaded file is not a ZIP. Check URL.", xbmcgui.NOTIFICATION_ERROR) # REMOVED: No notification
            return False

        total_size = int(response.headers.get('content-length', 0))
        
        with open(zip_file_path, 'wb') as f:
            downloaded_size = 0
            for chunk in response.iter_content(chunk_size=8192):
                # if dialog.iscanceled(): # REMOVED: No dialog box
                #     xbmc.log("[GoldVault TV] Download cancelled by user.", level=xbmc.LOGWARNING)
                #     xbmcgui.Dialog().notification("Download Cancelled", "Icon download was cancelled.", xbmcgui.NOTIFICATION_INFO) # REMOVED: No notification
                #     return False
                if chunk:
                    f.write(chunk)
                    downloaded_size += len(chunk)
                    percent = int(downloaded_size * 100 / total_size) if total_size > 0 else 0
                    
                    # Use old-style % formatting for dialog.update message (percent, message)
                    # downloaded_mb = downloaded_size / (1024*1024) # REMOVED: No dialog box
                    # total_mb = total_size / (1024*1024) # REMOVED: No dialog box
                    # progress_message = "Downloaded: %.2f MB / %.2f MB" % (downloaded_mb, total_mb) # REMOVED: No dialog box
                    # dialog.update(percent, progress_message) # REMOVED: No dialog box

        # Check if the downloaded file is empty/incomplete
        if total_size == 0 and downloaded_size == 0:
            xbmc.log("[GoldVault TV] Downloaded file is empty.", level=xbmc.LOGERROR)
            # xbmcgui.Dialog().notification("Download Failed", "Downloaded file is empty. Check URL.", xbmcgui.NOTIFICATION_ERROR) # REMOVED: No notification
            return False

        xbmc.log("[GoldVault TV] Download complete. Extracting " + zip_file_path, level=xbmc.LOGINFO)
        # dialog.update(100, "Extracting Icons...") # REMOVED: No dialog box

        # Extract the ZIP file
        try:
            with zipfile.ZipFile(zip_file_path, 'r') as z:
                xbmc.log("[GoldVault TV] Attempting to extract zip contents to: " + temp_extract_dir, level=xbmc.LOGINFO)
                z.extractall(temp_extract_dir)
                xbmc.log("[GoldVault TV] Zip extraction completed successfully.", level=xbmc.LOGINFO)
        except zipfile.BadZipFile:
            xbmc.log("[GoldVault TV] ERROR: Downloaded file is a Bad Zip File during extraction.", level=xbmc.LOGERROR)
            # xbmcgui.Dialog().notification("Extraction Failed", "Downloaded file is corrupted or not a valid ZIP.", xbmcgui.NOTIFICATION_ERROR) # REMOVED: No notification
            return False
        except Exception as e:
            xbmc.log("[GoldVault TV] ERROR: Unexpected error during zip extraction: " + str(e), level=xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), level=xbmc.LOGERROR) # Log full traceback
            # xbmcgui.Dialog().notification("Extraction Failed", "An error occurred during extraction.", xbmcgui.NOTIFICATION_ERROR) # REMOVED: No notification
            return False

        # Move PNGs to final destination (handling 'tv/' subfolder in extracted content)
        extracted_root_contents = os.listdir(temp_extract_dir)
        source_icon_dir = temp_extract_dir # Default source if no 'tv' subfolder
        
        # Check if a 'tv' folder exists within the extracted content's root
        if 'tv' in extracted_root_contents and os.path.isdir(os.path.join(temp_extract_dir, 'tv')):
            xbmc.log("[GoldVault TV] 'tv/' folder found in extracted zip. Moving contents.", level=xbmc.LOGINFO)
            source_icon_dir = os.path.join(temp_extract_dir, 'tv')
        else:
            xbmc.log("[GoldVault TV] 'tv/' folder NOT found in extracted zip. Assuming icons at root.", level=xbmc.LOGINFO)

        for item in os.listdir(source_icon_dir):
            if item.lower().endswith('.png'):
                src = os.path.join(source_icon_dir, item)
                dest = os.path.join(final_icons_dest_dir, item) 
                shutil.move(src, dest)

        xbmc.log("[GoldVault TV] Icons moved to final location: " + final_icons_dest_dir, level=xbmc.LOGINFO)
        download_success = True
        
        # Verify default_channel.png exists after extraction (from previous turn)
        default_icon_check_path = os.path.join(final_icons_dest_dir, 'default_channel.png')
        if os.path.exists(default_icon_check_path):
            xbmc.log("[GoldVault TV][Extraction] 'default_channel.png' FOUND at: " + default_icon_check_path, level=xbmc.LOGINFO)
        else:
            xbmc.log("[GoldVault TV][Extraction] WARNING: 'default_channel.png' NOT FOUND at: " + default_icon_check_path + " after extraction.", level=xbmc.LOGWARNING)
            xbmc.log("[GoldVault TV][Extraction] Contents of final_icons_dest_dir: " + str(os.listdir(final_icons_dest_dir)), level=xbmc.LOGINFO)
        
        # Additional debug line as requested for this exact point
        xbmc.log("[GoldVault TV] Debug check point: Just before exception block. download_success is " + str(download_success), level=xbmc.LOGINFO)

    except Exception as e:
        xbmc.log("[GoldVault TV] An unexpected error occurred: " + str(e), level=xbmc.LOGERROR)
        xbmc.log(traceback.format_exc(), level=xbmc.LOGERROR) # Log full traceback for general errors
        # xbmcgui.Dialog().notification("Download Failed", "An error occurred during download or extraction: " + str(e), xbmcgui.NOTIFICATION_ERROR) # REMOVED: No notification
        return False
    finally:
        # NEW: Remove the downloaded zip file
        if zip_file_path and os.path.exists(zip_file_path):
            os.remove(zip_file_path)
            xbmc.log("[GoldVault TV] Cleaned up downloaded zip file: " + zip_file_path, level=xbmc.LOGINFO)
        else:
            xbmc.log("[GoldVault TV] No zip file to clean up or path is invalid.", level=xbmc.LOGDEBUG)

        # NEW: Remove the temporary extraction directory
        if temp_extract_dir and os.path.exists(temp_extract_dir):
            shutil.rmtree(temp_extract_dir)
            xbmc.log("[GoldVault TV] Cleaned up temporary extraction directory: " + temp_extract_dir, level=xbmc.LOGINFO)
        else:
            xbmc.log("[GoldVault TV] No temporary extraction directory to clean up or path is invalid.", level=xbmc.LOGDEBUG)
        
        # No dialog to close here, as all dialogs were removed previously.
        # pass # No need for pass anymore since there's active code
    if download_success:
        xbmc.log("[GoldVault TV] TV channel icons downloaded and installed successfully (silent).", level=xbmc.LOGINFO)
        # xbmcgui.Dialog().notification("Success", "TV channel icons downloaded and installed!", xbmcgui.NOTIFICATION_INFO) # REMOVED: No notification
    else:
        xbmc.log("[GoldVault TV] TV channel icons could not be downloaded (silent failure).", level=xbmc.LOGERROR)
        # xbmcgui.Dialog().notification("Error", "TV channel icons could not be downloaded.", xbmcgui.NOTIFICATION_ERROR) # REMOVED: No notification
    return download_success
# Modified show_main_menu to include a download option
def show_main_menu():
    """Displays the main categories as folders for the Live TV section."""
    xbmcplugin.setPluginFanart(addon_handle, image=FANART_PATH)

    # Automatically check and download icons if not already present
    if not are_channel_icons_downloaded():
        xbmc.log("[GoldVault TV] Channel icons not found locally. Initiating automatic download.", level=xbmc.LOGINFO)
        download_success = download_and_extract_icons()  # Call download function
        if not download_success:
            xbmcgui.Dialog().notification("Info", "[COLOR gold]TV Could Not Load Please Update/Reinstall Your Addon.[/COLOR]", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(addon_handle)
            return  # Exit function if download failed
        else:
            xbmc.log("[GoldVault TV] Automatic icon download completed successfully.", level=xbmc.LOGINFO)

    # File path to the text file (assumed to be in the main addon directory)
    file_path = os.path.join(os.path.dirname(__file__), 'tv_list.txt')
    xbmc.log("[GoldVault TV] show_main_menu: Attempting to read from: " + file_path, level=xbmc.LOGINFO)

    all_categorized_channels = read_categories_and_channels(file_path)

    if not all_categorized_channels:
        xbmc.log("[GoldVault TV] No categorized channels found.", level=xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Info", "No categorized channels found.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Sort categories alphabetically for consistent display
    sorted_categories = sorted(all_categorized_channels.keys())
    xbmc.log("[GoldVault TV] Sorted categories for main menu: " + str(sorted_categories), level=xbmc.LOGINFO)
    xbmc.log("[GoldVault TV][MainMenu] Will attempt to list categories: " + str(sorted_categories), level=xbmc.LOGINFO)

    # NEW DEBUG: Log the base ICONS_PATH for static category icons
    xbmc.log("[GoldVault TV][MainMenu] Base ICONS_PATH for category folders: " + ICONS_PATH, level=xbmc.LOGINFO)


    for category_name in sorted_categories:
        xbmc.log("[GoldVault TV] Creating folder for category: '" + category_name + "'", level=xbmc.LOGINFO)
        url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'list_channels', 'category': urllib.parse.quote_plus(category_name)}) # Ensure category is quoted for URL
        
        list_item = xbmcgui.ListItem(label=category_name)
        
        # Construct the expected icon filename for the category
        icon_name = category_name.lower().replace(' ', '_') + ".png" # No f-string
        icon_path_specific = os.path.join(ICONS_PATH, icon_name)
        
        category_icon_to_use = icon_path_specific # Start with the specific icon path
        
        # NEW DEBUG: Log the specific icon path being checked
        xbmc.log("[GoldVault TV][MainMenu] Checking for specific icon: " + icon_path_specific, level=xbmc.LOGDEBUG)

        if not os.path.exists(category_icon_to_use):
            category_icon_to_use = os.path.join(ICONS_PATH, 'default_folder.png')
            xbmc.log("[GoldVault TV][MainMenu] No specific icon found for category '" + category_name + "'. Using default: " + category_icon_to_use, level=xbmc.LOGWARNING)
            # NEW DEBUG: Verify if default_folder.png actually exists
            if not os.path.exists(category_icon_to_use):
                xbmc.log("[GoldVault TV][MainMenu] ERROR: Default folder icon NOT FOUND at: " + category_icon_to_use, level=xbmc.LOGERROR)
        else:
            xbmc.log("[GoldVault TV][MainMenu] Found specific icon for category '" + category_name + "': " + category_icon_to_use, level=xbmc.LOGDEBUG)
        
        # NEW DEBUG: Log the final icon path that will be used for the list item
        xbmc.log("[GoldVault TV][MainMenu] Final icon selected for '" + category_name + "': " + category_icon_to_use, level=xbmc.LOGDEBUG)

        list_item.setArt({'icon': category_icon_to_use, 'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

# Modified show_channels_in_category to ensure icons are present
def show_channels_in_category(category_name):
    """Displays channels within a specific category."""
    xbmcplugin.setPluginFanart(addon_handle, image=FANART_PATH)

    # NEW: Check if icons are downloaded before trying to list channels with icons
    if not are_channel_icons_downloaded():
        xbmcgui.Dialog().notification("Info", "Please download TV channel icons first.", xbmcgui.NOTIFICATION_INFO)
        # Add a "Back" item or simply end the directory
        xbmcplugin.endOfDirectory(addon_handle)
        return # Exit the function

    # Ensure the category name is stripped of any potential whitespace for accurate lookup
    category_name = urllib.parse.unquote_plus(category_name).strip()

    # File path to the text file (assumed to be in the main addon directory)
    file_path = os.path.join(os.path.dirname(__file__), 'tv_list.txt')
    # CHANGED: Simplified xbmc.log
    xbmc.log("[GoldVault TV] show_channels_in_category: Attempting to read from: " + file_path, level=xbmc.LOGINFO)

    all_categorized_channels = read_categories_and_channels(file_path)

    # Debug logs to verify received category name and available keys
    # CHANGED: Simplified xbmc.log
    xbmc.log("[GoldVault TV] show_channels_in_category: Received category_name: '" + category_name + "'", level=xbmc.LOGINFO)
    # CHANGED: Simplified xbmc.log
    xbmc.log("[GoldVault TV] show_channels_in_category: Available category keys from read_categories_and_channels: " + str(list(all_categorized_channels.keys())), level=xbmc.LOGINFO)

    channels = all_categorized_channels.get(category_name, [])
    # CHANGED: Simplified xbmc.log
    xbmc.log("[GoldVault TV] Channels found in category '" + category_name + "': " + str(len(channels)) + " channels.", level=xbmc.LOGINFO)
    
    if not channels:
        xbmcgui.Dialog().notification("Info", "No channels found in '" + category_name + "'.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Define common *icon filename* suffixes that might exist on the icon file.
    # We will try appending these to the normalized channel title.
    # Order matters: more specific/common ones first to find the best match.
    COMMON_ICON_SUFFIXES_TO_TRY = [
        # Country/Region codes (common ones first)
        '-us', '-uk', '-in', '-hd', '-fhd', '-uhd', '-4k', '-sd', # Quality indicators often combined with country
        '-live', '-stream', '-channel', # Common type indicators
        
        # Other country/region codes from the GitHub repo's structure
        '-au', '-ca', '-de', '-fr', '-es', '-it', '-jp', '-cn', '-mx', '-br', '-ar',
        '-za', '-ae', '-sa', '-eg', '-pk', '-bd', '-lk', '-ph', '-id', '-my', '-sg',
        '-th', '-vn', '-kr', '-nz', '-ie', '-ch', '-at', '-be', '-nl', '-dk', '-se',
        '-no', '-fi', '-pl', '-cz', '-hu', '-ro', '-gr', '-pt', '-ru', '-ua', '-kz',
        '-tr', '-il', '-jo', '-lb', '-sy', '-kw', '-qa', '-bh', '-om', '-ye', '-iq',
        '-ir', '-af', '-np', '-mm', '-kh', '-la', '-tw', '-hk', '-mo', '-mn', '-kp',
        '-uz', '-tm', '-tj', '-kg', '-az', '-am', '-ge', '-by', '-md', '-lt', '-lv',
        '-ee', '-bg', '-rs', '-hr', '-ba', '-me', '-al', '-mk', '-cy', '-mt', '-is',
        '-fo', '-gl',
        # Add more specific suffixes if you observe them in the GitHub repo's US folder
        # e.g., '-east', '-west', '-plus', '-alt', '-main' if applicable
    ]

    for title, url in channels:
        # CHANGED: Simplified xbmc.log
        xbmc.log("[GoldVault TV] Adding channel: '" + title + "' with URL: '" + url + "'", level=xbmc.LOGINFO)
        list_item = xbmcgui.ListItem(label=title)
        list_item.setProperty('IsPlayable', 'true') # Mark as playable for direct click
        
        # --- CORRECTED CODE FOR CHANNEL ICONS ---
        # 1. Start by converting the original title to lowercase
        temp_title = title.lower()

        # 2. Handle specific symbol replacements first to match your desired icon naming conventions
        #    This is the crucial step for '&' and '+'
        temp_title = temp_title.replace('&', 'and') # Reverted: 'ande' was in previous versions
        temp_title = temp_title.replace('+', 'plus') # Replace '+' with 'plus'
        
        # 3. Replace any sequence of non-alphanumeric characters (except hyphens) with a single hyphen
        normalized_base_title = re.sub(r'[^a-z0-9]+', '-', temp_title) 
        
        # 4. Clean up any leading/trailing hyphens or multiple hyphens that might result
        normalized_base_title = re.sub(r'-+', '-', normalized_base_title).strip('-')

        # Use CHANNEL_ICONS_PATH for individual channel icons (now points to downloaded location)
        icon_to_use = os.path.join(CHANNEL_ICONS_PATH, 'default_channel.png') # Default fallback in downloaded 'tv_icons' folder
        found_icon = False

        # Attempt 1: Try appending common icon suffixes first (most likely match for GitHub repo)
        for suffix in COMMON_ICON_SUFFIXES_TO_TRY:
            channel_icon_name_with_suffix = normalized_base_title + suffix + ".png" # CHANGED: No f-string
            channel_icon_path_with_suffix = os.path.join(CHANNEL_ICONS_PATH, channel_icon_name_with_suffix) # Uses CHANNEL_ICONS_PATH
            if os.path.exists(channel_icon_path_with_suffix):
                icon_to_use = channel_icon_path_with_suffix
                found_icon = True
                # CHANGED: Simplified xbmc.log
                xbmc.log("[GoldVault TV] Found icon with suffix for '" + title + "': " + channel_icon_name_with_suffix, level=xbmc.LOGDEBUG)
                break 

        # Attempt 2: If no suffix match, try a direct match without any suffixes (less likely for this repo, but good fallback)
        if not found_icon:
            channel_icon_name_direct = normalized_base_title + ".png" # CHANGED: No f-string
            channel_icon_path_direct = os.path.join(CHANNEL_ICONS_PATH, channel_icon_name_direct) # Uses CHANNEL_ICONS_PATH
            if os.path.exists(channel_icon_path_direct):
                icon_to_use = channel_icon_path_direct
                found_icon = True
                # CHANGED: Simplified xbmc.log
                xbmc.log("[GoldVault TV] Found direct icon (no suffix) for '" + title + "': " + channel_icon_name_direct, level=xbmc.LOGDEBUG)
        
        if not found_icon:
            # CHANGED: Simplified xbmc.log
            xbmc.log("[GoldVault TV] No specific icon found for '" + title + "' after trying all patterns. Using default.", level=xbmc.LOGDEBUG)
        
        list_item.setArt({'icon': icon_to_use, 'fanart': FANART_PATH})
        # --- END CORRECTED CODE ---
        
        play_url = urllib.parse.quote_plus(url) # URL-encode the stream URL
        # CHANGED: Simplified f-string for URL
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=sys.argv[0] + "?action=play_stream&title=" + urllib.parse.quote_plus(title) + "&url=" + play_url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def play_stream(title, url):
    """
    Plays the given stream URL by resolving it and handing it off to Kodi's player.
    This method ensures Kodi properly takes over playback and closes the directory.
    All dialogs and notifications remain removed.
    """
    xbmc.log(f"[GoldVault TV] Starting playback attempt for '{title}' from URL: {url}", level=xbmc.LOGINFO)
    
    try:
        headers = {
            'User-Agent': USER_AGENT,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive',
            'Referer': url, # Often crucial for streams
            **EXTRA_HEADERS
        }
        proxies = {'http': PROXY, 'https': PROXY} if PROXY else {}

        session = requests.Session()
        # Fetch the actual stream URL, following redirects
        response = session.get(url, headers=headers, allow_redirects=True, stream=True, timeout=30)
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        final_url = response.url
        
        xbmc.log(f"[GoldVault TV] Resolved stream URL: {final_url}", level=xbmc.LOGINFO)
        xbmc.log(f"[GoldVault TV] Response status code: {response.status_code}", level=xbmc.LOGDEBUG) # Log status code
        xbmc.log(f"[GoldVault TV] Response Content-Type: {response.headers.get('Content-Type', 'N/A')}", level=xbmc.LOGDEBUG)

        list_item = xbmcgui.ListItem(label=title)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setPath(final_url)

        # Attempt to set mimetype from headers or URL extension for better Kodi handling
        content_type = response.headers.get('Content-Type')
        if content_type:
            list_item.setProperty('mimetype', content_type)
            xbmc.log(f"[GoldVault TV] Set mimetype from headers: {content_type}", level=xbmc.LOGDEBUG)
        else:
            # Fallback to guessing from URL extension for common types like .m3u8, .ts
            if '.m3u' in final_url.lower() or '.m3u8' in final_url.lower():
                list_item.setProperty('mimetype', 'application/x-mpegURL')
                xbmc.log("[GoldVault TV] Guessed mimetype as application/x-mpegURL for .m3u/.m3u8", level=xbmc.LOGDEBUG)
            elif '.ts' in final_url.lower():
                list_item.setProperty('mimetype', 'video/mp2t')
                xbmc.log("[GoldVault TV] Guessed mimetype as video/mp2t for .ts", level=xbmc.LOGDEBUG)
            else:
                xbmc.log("[GoldVault TV] No explicit mimetype from headers or guessed from URL extension.", level=xbmc.LOGDEBUG)
        
        # Explicitly set mediatype for Kodi to understand it's video
        list_item.setInfo('video', {'title': title, 'mediatype': 'video'}) 

        # This is the crucial change: Tell Kodi the URL is resolved
        xbmcplugin.setResolvedUrl(addon_handle, True, list_item)
        xbmc.log(f"[GoldVault TV] Stream URL resolved successfully for '{title}'. Handing off to Kodi player.", level=xbmc.LOGINFO)
        return # Success, Kodi will now handle playback

    except requests.exceptions.RequestException as e:
        xbmc.log(f"[GoldVault TV] Request error resolving stream for '{title}': {e}", level=xbmc.LOGERROR)
        xbmc.log(f"[GoldVault TV] Playback for '{title}' failed due to network/request error.", level=xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem()) # Signal failure to Kodi
    except Exception as e:
        xbmc.log(f"[GoldVault TV] Unexpected error resolving stream for '{title}': {e}", level=xbmc.LOGERROR)
        xbmc.log(traceback.format_exc(), level=xbmc.LOGERROR) # Log full traceback
        xbmc.log(f"[GoldVault TV] Playback for '{title}' failed due to unexpected error.", level=xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem()) # Signal failure to Kodi

    finally:
        pass # No dialogs to close
# This block is now simplified. It only executes if tv_functions.py is run directly,
# but in your intended setup, it will be imported by main.py.
if __name__ == '__main__':
    # This part is mostly for direct testing of tv_functions.py or if it were a standalone addon.
    # In your main addon setup, main.py will import and call functions from this file directly.
    # CHANGED: Simplified xbmc.log
    xbmc.log("[GoldVault TV Router] tv_functions.py executed. sys.argv: " + str(sys.argv), level=xbmc.LOGINFO)
    params = urllib.parse.parse_qs(sys.argv[2][1:])
    action = params.get('action', [''])[0]
    category = urllib.parse.unquote_plus(params.get('category', [''])[0]) # CHANGED: Explicitly unquote the category
    url = params.get('url', [''])[0]
    title = params.get('title', [''])[0]

    # CHANGED: Simplified xbmc.log
    xbmc.log("GoldVault TV Router] Parsed Action: '" + action + "', Category: '" + category + "', URL: '" + url + "', Title: '" + title + "'", level=xbmc.LOGINFO)

    # NEW: Handle the download action
    if action == 'download_tv_icons':
        # CHANGED: Simplified xbmc.log
        xbmc.log("[GoldVault TV Router] Initiating TV icon download...", level=xbmc.LOGINFO)
        download_status = download_and_extract_icons()
        if download_status: # Only refresh if download was successful
            xbmc.executebuiltin("Container.Refresh()") 
        sys.exit() # Exit after handling the action

    # Handle Playback Action
    elif action == 'play_stream' and url:
        # CHANGED: Simplified xbmc.log
        xbmc.log("[GoldVault TV Router] Calling play_stream for URL: '" + url + "' with title: '" + title + "'", level=xbmc.LOGINFO)
        play_stream(urllib.parse.unquote_plus(title), urllib.parse.unquote_plus(url))
        sys.exit()

    # Handle Directory Listing Actions
    elif action == 'list_channels' and category:
        # CHANGED: Simplified xbmc.log
        xbmc.log("[GoldVault TV Router] Calling show_channels_in_category for '" + category + "'", level=xbmc.LOGINFO)
        show_channels_in_category(category)

    else:
        # CHANGED: Simplified xbmc.log
        xbmc.log("[GoldVault TV Router] No specific action or initial entry. Showing main TV menu.", level=xbmc.LOGINFO)
        show_main_menu()